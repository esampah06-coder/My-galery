# PROMPT: Buat Aplikasi Android "Galeri Sortir"

Kamu adalah pengembang Android senior. Buatkan aplikasi Android native sungguhan bernama **Galeri Sortir**. Berikan KODE LENGKAP semua file (jangan disingkat, jangan pakai "dst" atau placeholder), siap di-build menjadi APK, beserta langkah build singkat. Kalau ada bagian yang tidak bisa kamu buat di lingkungan ini, katakan terlebih dulu secara jujur.

Semua teks antarmuka berbahasa Indonesia.

---

## 1. Tujuan aplikasi

Aplikasi untuk menyortir ratusan sampai ribuan gambar hasil generate AI (mis. gambar 3D dari generator) dengan cepat, memakai gestur satu tangan. Setiap gambar hasil bisa dibandingkan dengan **gambar asli** (referensi) yang dipakai untuk membuatnya. Pengguna menyortir: favorit, buang ke sampah, lalu mengekspor hasil yang bagus ke file ZIP.

Aplikasi bekerja **offline sepenuhnya**, semua data tersimpan permanen di HP.

## 2. Teknologi yang diminta

- Kotlin + Jetpack Compose (Material 3), minSdk 26, targetSdk terbaru.
- Room (database), DataStore (pengaturan), Coil (muat gambar/thumbnail).
- Penyimpanan gambar: file di folder internal aplikasi, bukan di dalam database.
- Impor memakai Storage Access Framework (pilih file, pilih folder) dan Photo Picker bila tersedia.
- Proses berat (impor ratusan file, ZIP besar, ekspor) berjalan di background dengan coroutine/WorkManager, ada notifikasi progres, tidak membekukan UI, dan **tidak boleh memuat seluruh ZIP ke RAM**. Baca ZIP dengan streaming (`ZipInputStream`/`ZipFile`) dan tulis ZIP dengan `ZipOutputStream` metode STORED (tanpa kompresi).
- Harus kuat untuk 5.000+ gambar: grid lazy, thumbnail terpisah, tidak ada decode gambar penuh di grid.
- Tema gelap saja. Mendukung potret, landscape, dan tablet.

## 3. Gaya tampilan

- Warna: latar `#0D0F14`, permukaan `#161922`, aksen ungu `#7C6BFF`, teal `#0EE0AC`, pink `#FF4D8D`, teks `#EEF0F6`, teks redup `#8B90A3`, merah hapus `#E11D48`.
- Font: DM Sans (isi), Syne ExtraBold (judul). Sudut membulat 12-20dp.
- Boleh mendesain ulang agar lebih bagus, selama fungsi di bawah tetap utuh.

## 4. Model data

**Item gambar** (satu baris database per gambar):
- `id` unik
- `name` nama file yang ditampilkan (bisa bernomor `_2`, `_3` bila bentrok)
- `originalName` nama file saat diimpor
- `base` nama tanpa ekstensi
- `bk` kunci pasangan (nama asli tanpa ekstensi, huruf kecil)
- `promptNo` nomor prompt (angka setelah kata "prompt" pada nama, 0 bila tidak ada)
- `isOriginal` (true = gambar asli/referensi yang tidak punya hasil, tampil sebagai kartu "Asli")
- `hasOriginal` (true bila hasil ini punya gambar asli yang cocok)
- `favorite`, `trashed`
- flag **sudah dilihat per tab**: `seenGallery`, `seenFav`, `seenLepas`, `seenTrash`
- `addedAt`, `batchId` (satu kali impor), `fileModified` (waktu modifikasi file), `zipTime` dan `zipName` (ZIP asal), `trashedAt`, `lastSeenAt`, `size`, `categoryId`

**Gambar asli yang berpasangan** disimpan terpisah (satu file per kunci `bk`) beserta nama file aslinya, supaya satu gambar asli bisa dipakai banyak hasil.

**Kategori**: `id`, `nama`. Default satu kategori bernama "3D".

Untuk tiap gambar, simpan file penuh dan thumbnail JPEG kualitas 80 dengan sisi terpanjang maksimal 360px.

## 5. Logika impor dan pemasangan pasangan (INTI APLIKASI)

### 5.1 Sumber impor
Tombol "＋" membuka pilihan **jenis**: `Hasil generate`, `Gambar asli`, atau `Campur (otomatis)`. Lalu pilih sumber: **ZIP atau gambar** (multi-pilih), **Folder**, atau **Link (URL)**. Format gambar: PNG, JPG/JPEG, WEBP. File ZIP dibuka dan dibaca isinya (abaikan folder `__MACOSX`, file berawalan titik, dan direktori). Hanya nama file yang dipakai (path folder di dalam ZIP diabaikan). Satu kali impor dihitung satu `batchId`, dan mencatat nama serta waktu ZIP asalnya.

Dua opsi tambahan di dialog impor (tersimpan, default aktif):
1. "Nama yang mengandung 'prompt' dianggap file hasil generate" (untuk mode Campur).
2. "Nama asli yang terpotong di hasil tetap dicocokkan".

Impor ditolak dengan pesan bila impor sebelumnya masih berjalan. Selama impor tampil progres "Mengimpor X/Y...". Minta penyimpanan persisten.

### 5.2 Klasifikasi di mode Campur
- Jika opsi "prompt" aktif: nama mengandung kata "prompt" (tidak peduli besar kecil) = hasil, selainnya = asli.
- Jika nonaktif: hasil bila cocok pola `^(.+)_prompt(\d+)(?:_(\d+))?\.(png|jpe?g|webp)$`, atau namanya diawali nama (kunci) file lain yang dikenal.
- Mode "Hasil" memaksa semua jadi hasil, mode "Asli" memaksa semua jadi asli.

### 5.3 Aturan pasangan
Sebuah hasil dipasangkan ke gambar asli bila **nama hasil diawali kunci asli** (tanpa ekstensi, tidak peduli huruf besar kecil), dengan satu pengecualian: bila kunci asli berakhir angka, karakter sesudahnya di nama hasil tidak boleh angka (agar `foto1` tidak cocok dengan `foto12_prompt3.png`). Bila ada beberapa kunci yang cocok, pakai yang **terpanjang**.

**Pencocokan nama terpotong:** generator sering memotong nama asli yang panjang (±48 karakter) atau yang berisi titik (mis. `com.google...`). Aturan: ambil "stem" hasil = bagian sebelum `_prompt` / `-prompt` / ` prompt` / `prompt`. Stem cocok dengan kunci asli bila: panjang stem ≥ 8, kunci lebih panjang dari stem, kunci diawali stem, dan (panjang stem ≥ 40 ATAU karakter berikutnya di kunci adalah salah satu dari `. - _` atau spasi), dan batas angka tidak dilanggar. Pencocokan ini hanya dipakai bila **kandidatnya tepat satu** (kalau ambigu, jangan dipasangkan).

### 5.4 Urutan pemrosesan
1. **Gambar asli diproses lebih dulu.** Asli yang sudah ada (nama sama atau kunci sudah dikenal) dilewati. Bila ada hasil (di batch ini atau di database) yang cocok, simpan sebagai *asli berpasangan* (tidak muncul sebagai kartu sendiri). Bila tidak ada hasil yang cocok, simpan sebagai kartu **"Asli"** yatim (`isOriginal = true`).
2. **Lalu gambar hasil.** Tiap hasil dicari pasangannya; `hasOriginal = true` bila ketemu, kalau tidak `false` (masuk tab Lepas). Nomor prompt diambil dari angka setelah "prompt".
3. **Pencocokan ulang di akhir:** semua hasil lama yang belum berpasangan dicoba lagi dengan asli yang baru masuk. Kartu "Asli" yatim yang kini punya hasil otomatis dilebur menjadi asli berpasangan lalu kartunya dihapus.

### 5.5 Duplikat
Nama sama **dan ukuran file sama** = duplikat, dilewati. Nama sama tapi ukuran beda = tetap diimpor dengan nama diberi nomor `_2`, `_3`, dst. Duplikat dicek per kategori. Ringkasan akhir impor (toast panjang): jumlah hasil, asli tak berpasangan, duplikat dilewati, yang diberi nomor, yang gagal beserta penyebab (penyimpanan penuh / file tidak terbaca / ZIP tidak bisa dibuka). Bila penyimpanan penuh, hentikan impor dengan rapi.

### 5.6 Impor dari link (URL)
Sheet berisi kolom multi-baris (satu link per baris), tombol "Tempel dari clipboard", "Ambil dan impor", "Buka link pertama di peramban", dan pilihan jenis. Mendukung link langsung gambar/ZIP dan link satu file Google Drive (`/file/d/ID` atau `?id=ID`; bila ada API key Google yang diisi pengguna, pakai Drive API, tersimpan lokal). Link folder Drive tidak didukung (beri pesan jelas). Nama file dari header `Content-Disposition`, kalau tidak ada dari URL, kalau tidak ada dari tipe konten. Tolak bila isinya HTML. Timeout 3 menit. Link yang gagal dikumpulkan dalam daftar beserta alasannya.

## 6. Layar utama

### 6.1 Header
Judul "Galeri Sortir ▾" (ketuk untuk menu kategori) dengan subjudul `Kategori • Tab: N gambar (M baru) • tampil: ...`. Tombol: ⬇ ekspor ZIP, 🧹 bersihkan, ⇅ urutan, ▦ jumlah kolom (2/3/4, siklus), ＋ impor, ☰ menu utama.

### 6.2 Empat tab bawah (dengan badge jumlah)
Pada landscape/tablet, tab pindah menjadi bilah vertikal di kiri.
1. **Galeri** — tidak sampah, tidak favorit, dan (hasil berpasangan, ATAU hasil tanpa asli bila opsi "Hasil tanpa gambar asli" aktif, ATAU kartu Asli bila opsi "Gambar asli tanpa hasil" aktif).
2. **Favorit** — favorit yang tidak di sampah.
3. **Lepas** — yang tidak terhubung: hasil tanpa asli, dan kartu Asli yatim. Punya tampilan: Hasil / Asli / Semua. Otomatis pindah ke Galeri saat pasangannya diimpor. Ada keterangan singkat di atas daftar.
4. **Trash** — gambar yang dibuang.

Semua daftar disaring per **kategori aktif**. Badge menampilkan total dan, kalau ada, jumlah yang belum dilihat.

Ketuk tab yang **sedang aktif** membuka popup opsi tab: (Galeri) toggle "Hasil tanpa gambar asli" dan "Gambar asli tanpa hasil"; (Lepas) pilihan tampilan Hasil/Asli/Semua dengan jumlah; semua tab: "Pilih jumlah tertentu…", filter tampilan (semua / hanya yang baru / hanya yang sudah dilihat), "Ke paling atas".

### 6.3 Grid
- Kolom 2-4 (landscape: dua kali lipat; tablet: lebar kartu otomatis).
- Kartu rasio **3:4**, gambar `crop`, sudut membulat. Di kartu: lencana kiri atas (`P{nomor}` / `Hasil` / `Asli`), titik teal kanan atas bila **belum dilihat**, nama file di bawah dengan gradasi, tombol hati ♡/♥ di kanan bawah (tidak ada di kartu Asli).
- Kartu yang sudah dilihat **memudar** (opasitas 45%) dan, bila opsi aktif, diurutkan ke paling bawah.
- Muat bertahap (48 kartu per tahap), thumbnail dimuat lazy. Pertahankan posisi scroll setelah aksi.
- Pesan kosong yang kontekstual (mis. "Sisanya ada di tab Lepas", "Semua sudah disortir", "Kategori ini kosong").
- Ketuk hati = toggle favorit langsung (getar singkat).

### 6.4 Urutan (sheet)
Nama A-Z, Nama Z-A, Terbaru ditambahkan, Terlama ditambahkan, Nomor prompt, Terakhir dilihat, Waktu gambar (terbaru/terlama dulu), Nama per file ZIP (ZIP terlama/terbaru dulu). Toggle: "Yang sudah dilihat di paling bawah", "Hasil tanpa asli ikut tampil di Galeri", "Asli tanpa hasil ikut tampil di Galeri", pilihan navigasi layar penuh, mode geser bawah. Nama diurutkan secara natural (angka 2 sebelum 10). Pilihan tersimpan.

## 7. Kategori

- Ketuk judul untuk popup daftar kategori dengan jumlah gambar tab aktif. Pilih untuk berpindah.
- "＋ Kategori baru" (maks 20 karakter, nama tidak boleh kosong atau kembar tanpa melihat huruf besar kecil). Membuat kategori baru langsung berpindah ke sana dan ke tab Galeri.
- **Tahan** nama kategori = ganti nama.
- Tombol ✕ hapus hanya muncul untuk kategori yang **kosong** dan bila kategori lebih dari satu; konfirmasi dulu.
- "Pindahkan ke kategori lain" tersedia di layar penuh dan di mode pilih banyak (termasuk membuat kategori baru saat memindah). Saat pindah, status dilihat direset.
- Kategori aktif diingat.

## 8. Pilih banyak

- **Tahan** satu kartu 0,4 detik (getar) = masuk mode pilih, kartu itu terpilih. Lalu ketuk kartu lain untuk memilih/batal, atau **seret ke samping** untuk memilih/membatalkan cepat (mode ikut keadaan kartu pertama). Saat menyeret ke tepi atas/bawah, grid auto-scroll. Kartu terpilih diberi bingkai ungu dan centang.
- Bilah aksi bawah: "N dipilih", **Pindahkan**, **Hapus** (ke Trash, ada Urungkan) — di tab Trash jadi **Pulihkan** dan **Hapus permanen** (konfirmasi) —, **ZIP**, **Tandai** (sudah dilihat / belum dilihat, ada Urungkan), **Jumlah**, **Semua**, ✕.
- **Pilih jumlah tertentu**: input angka (default 250, diingat). Pilih "N pertama dari awal daftar" atau "Tambah N berikutnya setelah pilihan terakhir". Cocok untuk membagi ekspor per 250.
- Mode pilih otomatis keluar bila tab berganti atau pilihan kosong.

## 9. Penampil layar penuh (FITUR TERPENTING)

Ketuk kartu membuka penampil layar penuh hitam, bernavigasi dalam daftar yang sedang tampil (urutan sama dengan grid). Tombol Back sistem menutup penampil dan kembali ke grid dengan posisi terjaga. Saat dibuka, gambar langsung ditandai **sudah dilihat** untuk tab itu dan mencatat `lastSeenAt`. Gambar sebelah dimuat di muka (preload) agar perpindahan instan. Tampilkan: tombol ✕, penghitung `n / total`, teks nama file di bawah (di kartu Asli diberi "• Gambar asli", di hasil "• Prompt N"), strip 7 thumbnail di bawah (opsional, bisa disembunyikan, gambar aktif disorot).

### 9.1 Zoom
Cubit untuk zoom 1x-5x dengan titik fokus di antara dua jari, geser untuk menggeser gambar yang diperbesar (dibatasi tepi gambar), ketuk saat zoom = kembali 1x dengan animasi. Gestur zoom tidak memicu aksi sortir.

### 9.2 Empat mode navigasi (bisa diganti lewat tombol 🧭 atau menu ⋯)
**A. Gestur (default)**
- Ketuk separuh kiri/kanan (area 2/3 bawah) = gambar sebelumnya/berikutnya, dengan ikon panah kilas.
- Ketuk 1/3 bagian atas = tampil/sembunyi teks dan tombol (mode bersih).
- Geser kiri/kanan = pindah gambar (bisa dimatikan di pengaturan); gambar mengikuti jari dengan sedikit rotasi.
- **Geser atas** = favorit (animasi hati besar di tengah, gambar terbang ke atas, lanjut ke berikutnya, toast "Masuk Favorit" + Urungkan). Di tab Favorit = "Keluarkan" dari favorit. Bila sedang melihat asli, geser atas = kembali ke hasil. Kartu Asli tidak bisa difavoritkan (beri pesan).
- **Geser bawah** punya 3 pilihan perilaku (bisa diganti, tersimpan): 
  - *Asli dulu*: geser bawah pertama = tampilkan gambar asli (lencana "ASLI"), geser bawah lagi = buang ke sampah.
  - *Pendek/panjang*: geser pendek = lihat asli, geser panjang (>30% tinggi layar) = sampah.
  - *Langsung hapus (klasik)*.
  Jika hasil tidak punya asli, geser bawah langsung buang. Buang ke sampah meminta konfirmasi (bottom sheet dengan tombol besar; bisa dimatikan; geser bawah lagi di dialog = langsung "Ya"). Toast "Dipindah ke Trash" + Urungkan.
- Selama menggeser tampil label besar di tengah yang membesar-pudar sesuai jarak ("♥ FAVORIT", "👁 ASLI", "🗑 SAMPAH", "↩ HASIL", "↩ KELUARKAN"), dengan warna sesuai aksi. Lepas sebelum ambang = kembali dengan animasi pegas. Ambang: >64px, atau >30px dengan kecepatan >0,6 px/ms.
- Di tab Trash: geser atas = Pulihkan, geser bawah = Hapus permanen (konfirmasi).

**B. Tombol**: hanya tombol di layar (hati, tempat sampah, mata, strip, unduh), tanpa gestur sortir.
**C. Gabungan**: gestur + tombol.
**D. Sortir cepat**: geser kanan = favorit, kiri = sampah, atas = lewati (ke gambar berikutnya; bila sedang melihat asli = kembali ke hasil), bawah = lihat/tutup asli. Ketuk kiri/kanan tetap berpindah. Label aksi tampil saat menyeret.

### 9.3 Tombol di layar (mode Gabungan/Tombol)
Hati (favorit/keluarkan), tempat sampah, **mata 👁** (tahan = intip gambar asli, lepas = kembali; ketuk singkat <0,3 dtk = tetap tampil asli sampai diketuk lagi; redup bila tidak ada asli), tombol strip thumbnail, tombol unduh gambar ini. Di Trash: tombol Pulihkan ↩ dan Hapus permanen ⌫. Pengaturan: ukuran tombol (kecil/sedang/besar), transparansi (jelas/agak/sangat transparan).
**Atur letak tombol**: mode edit di mana tiap tombol bisa diseret bebas ke posisi nyaman (batas 4%-96% layar), garis putus-putus penanda, tombol "Reset" dan "Selesai". Posisi disimpan **terpisah untuk potret dan landscape**.

### 9.4 Lihat gambar asli
Bila hasil punya asli, penampil bisa menampilkan gambar aslinya menggantikan hasil, dengan lencana "ASLI" di tengah atas dan nama file asli di teks bawah. Posisi zoom direset. Bila asli tidak ditemukan, beri pesan "Gambar asli tidak ditemukan" dan kembali.

### 9.5 Menu ⋯ di penampil
Lihat gambar asli / kembali ke hasil, Pindahkan ke kategori lain, Unduh gambar ini, tampilkan/sembunyikan gambar mini, pilihan geser bawah, toggle geser kiri/kanan, toggle konfirmasi sampah, panduan gestur, pilih navigasi. Petunjuk gestur sekali tampil saat pertama membuka penampil per mode.

### 9.6 Aturan setelah aksi
Setelah favorit/sampah/pindah, item dikeluarkan dari daftar penampil dan langsung tampil gambar berikutnya (atau yang sebelumnya bila terakhir) dengan animasi masuk singkat; bila daftar habis, penampil menutup. **Urungkan** mengembalikan item ke posisi semula di daftar. Getar singkat tiap aksi. Mendukung keyboard/remote: panah kiri/kanan, Esc, L = favorit, Delete = sampah.

## 10. Ekspor ZIP

Tombol ⬇ (atau "ZIP" di mode pilih). Sheet pengaturan:
- **Isi**: Hasil saja / Hasil + gambar asli / Gambar asli saja (siklus).
- **Kategori**: kategori aktif atau semua kategori.
- **Hanya yang sudah dilihat** (toggle).
- Cakupan: seluruh isi tab aktif, atau gambar terpilih.
- Pratinjau: "N gambar → M file, K bagian". Gambar asli tidak digandakan bila dipakai banyak hasil (satu kali per kunci).
- **Dibagi bagian maksimal 250 file per ZIP.** Tampilkan satu tombol per bagian ("Unduh bagian 1", dst); tiap bagian dibuat sendiri (tidak semua sekaligus), status "Menyiapkan..." lalu "✓ Bagian n diunduh", dan bisa diulang bila gagal.
- Nama file: `{Tab|Pilihan}_{Kategori|SemuaKategori}_{Hasil|HasilDanAsli|Asli}_{YYYYMMDD}[_bagianN].zip`. Isi ZIP memakai nama file asli gambar.
- Simpan ke folder **Download** (MediaStore) lewat streaming, tanpa menumpuk di RAM. Beri notifikasi selesai.
- Setelah **semua bagian** terunduh (dan isi bukan "Asli saja"), muncul tombol **"Singkirkan dari galeri"**: hapus permanen gambar yang baru diekspor (konfirmasi tegas: pastikan semua ZIP sudah tersimpan, tidak bisa dikembalikan) untuk mengosongkan penyimpanan.
- Unduh satu gambar dari penampil: simpan ke Download dengan nama aslinya.

## 11. Bersihkan massal (tombol 🧹)

- Kosongkan Trash kategori ini (dengan jumlah)
- Bersihkan Lepas kategori ini
- Bersihkan impor terbaru (batch terakhir; **favorit tidak ikut dihapus**; tampilkan waktu batch)
- Bersihkan SEMUA kategori (konfirmasi berlapis dua kali)
Semua meminta konfirmasi dengan jumlahnya, "tidak bisa dikembalikan", dan diblokir saat impor berjalan. Menghapus gambar yang tidak lagi dipakai juga menghapus file asli berpasangannya bila tak ada hasil lain yang memakainya.

## 12. Menu utama ☰

Bagian **Tampilan** (urutan dan tampilan, kolom grid), **Gambar dan data** (impor dari link, ZIP dan unduh, bersihkan, penyimpanan dan ringkasan), **Cadangan** (simpan/pulihkan), **Layar penuh dan bantuan** (navigasi, panduan fitur).

- **Penyimpanan dan ringkasan**: pemakaian penyimpanan aplikasi dan sisa ruang HP, total gambar, dan per kategori: Galeri (baru), Favorit, Lepas, Trash.
- **Cadangan pilihan (.json)**: simpan catatan favorit, sampah, dan status dilihat berdasarkan **nama file + nama kategori** (bukan gambarnya) ke file `GaleriPilihan_YYYYMMDD.json`. **Pulihkan**: baca file itu, buat kategori yang belum ada, terapkan ke gambar yang namanya cocok; catatan untuk gambar yang belum diimpor dilewati. Berguna setelah impor ulang. Tampilkan jumlah catatan yang dipulihkan.
- **Panduan fitur**: ringkasan singkat semua gestur dan fitur.

## 13. Pengaturan yang diingat (DataStore)

Kolom grid, urutan, "dilihat di bawah", opsi tampilkan Lepas/Asli di Galeri, mode Lepas, mode navigasi, mode geser bawah, konfirmasi sampah, geser kiri/kanan, gambar mini, opsi "prompt", opsi nama terpotong, jumlah N pilihan, ukuran dan transparansi tombol, posisi tombol per orientasi, kategori aktif, API key Drive.

## 14. Kualitas dan ketahanan

- Semua perubahan status (favorit, sampah, dilihat) langsung disimpan ke Room.
- Aplikasi tidak boleh crash karena gambar rusak/tidak terbaca; lewati dan laporkan.
- Layar tidak boleh patah saat impor besar; progres tetap jalan walau aplikasi ke background (foreground service/WorkManager).
- Target sentuh minimal 44dp, ramah satu tangan, tanpa jeda terasa saat menggeser gambar (animasi ≤ 150 ms).
- Hormati area aman (notch, bilah navigasi), hormati `prefers-reduced-motion` setara (pengaturan animasi sistem).
- Izin minimal: hanya yang diperlukan (INTERNET untuk impor link, notifikasi). Tidak ada iklan, akun, atau pelacak.

## 15. Hasil yang harus kamu berikan

1. Struktur proyek lengkap dan **semua file** (Gradle, Manifest, semua Kotlin, resource, tema, ikon aplikasi sederhana).
2. Penjelasan singkat arsitektur (layer data, repository, ViewModel, layar Compose).
3. Langkah membuat APK yang bisa diinstal (debug APK dan cara menandatanganinya).
4. Daftar fitur di atas yang belum/tidak bisa kamu implementasikan, kalau ada, beserta alasannya. Jangan diam-diam melewatkan fitur.

Kerjakan bertahap bila terlalu panjang: kirim dulu fondasi (database, impor + pemasangan pasangan, grid, tab), lalu penampil layar penuh, lalu ekspor/bersihkan/cadangan, dan tunggu saya bilang "lanjut" di tiap tahap.

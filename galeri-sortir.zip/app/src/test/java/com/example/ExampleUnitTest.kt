package com.example

import com.example.manager.ImportClassificationType
import com.example.manager.ImportManager
import com.example.util.NaturalOrderComparator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun naturalOrderComparator_sortsNumberNaturally() {
        val list = listOf("foto10.png", "foto2.png", "foto1.png", "foto20.png")
        val sorted = list.sortedWith(NaturalOrderComparator)
        assertEquals(listOf("foto1.png", "foto2.png", "foto10.png", "foto20.png"), sorted)
    }

    @Test
    fun pairingRule_digitBoundary_preventsWrongMatch() {
        // foto1 should not match foto12_prompt1.png because 2 is a digit
        val list = listOf("foto1", "foto12")
        val lowerResult = "foto12_prompt3.png"

        // Longest match starting with key without violating digit boundary
        val matched = list.filter { bk ->
            lowerResult.startsWith(bk) && run {
                val lastChar = bk.last()
                if (lastChar.isDigit()) {
                    val nextIdx = bk.length
                    if (nextIdx < lowerResult.length) !lowerResult[nextIdx].isDigit() else true
                } else true
            }
        }.maxByOrNull { it.length }

        assertEquals("foto12", matched)
    }
}

package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "original_assets")
data class OriginalAssetEntity(
    @PrimaryKey
    val bk: String, // Base key in lowercase
    val originalFileName: String,
    val filePath: String,
    val thumbnailPath: String,
    val size: Long,
    val addedAt: Long = System.currentTimeMillis()
)

package com.example.data.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Ignore
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "images",
    indices = [
        Index(value = ["categoryId"]),
        Index(value = ["bk"]),
        Index(value = ["batchId"]),
        Index(value = ["favorite", "trashed"]),
        Index(value = ["name", "categoryId"])
    ]
)
data class ImageItemEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val originalName: String,
    val base: String,
    val bk: String,
    val promptNo: Int = 0,
    @ColumnInfo(name = "isOriginal")
    val isOriginalCard: Boolean = false,
    @ColumnInfo(name = "hasOriginal")
    val hasOriginalPair: Boolean = false,
    val favorite: Boolean = false,
    val trashed: Boolean = false,
    val seenGallery: Boolean = false,
    val seenFav: Boolean = false,
    val seenLepas: Boolean = false,
    val seenTrash: Boolean = false,
    val addedAt: Long = System.currentTimeMillis(),
    val batchId: Long = 0L,
    val fileModified: Long = 0L,
    val zipTime: Long = 0L,
    val zipName: String = "",
    val trashedAt: Long = 0L,
    val lastSeenAt: Long = 0L,
    val size: Long = 0L,
    val categoryId: Long = 1L,
    val filePath: String = "",
    val thumbnailPath: String = ""
) {
    @get:Ignore
    val isOriginal: Boolean
        get() = isOriginalCard

    @get:Ignore
    val hasOriginal: Boolean
        get() = hasOriginalPair
}

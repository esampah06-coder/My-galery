package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.entity.ImageItemEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ImageItemDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: ImageItemEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<ImageItemEntity>): List<Long>

    @Update
    suspend fun update(item: ImageItemEntity)

    @Update
    suspend fun updateAll(items: List<ImageItemEntity>)

    @Delete
    suspend fun delete(item: ImageItemEntity)

    @Delete
    suspend fun deleteAll(items: List<ImageItemEntity>)

    @Query("SELECT * FROM images WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): ImageItemEntity?

    @Query("SELECT * FROM images WHERE id IN (:ids)")
    suspend fun getByIds(ids: List<Long>): List<ImageItemEntity>

    @Query("SELECT * FROM images WHERE categoryId = :categoryId")
    fun getAllByCategoryFlow(categoryId: Long): Flow<List<ImageItemEntity>>

    @Query("SELECT * FROM images WHERE categoryId = :categoryId")
    suspend fun getAllByCategory(categoryId: Long): List<ImageItemEntity>

    @Query("SELECT * FROM images")
    suspend fun getAllImages(): List<ImageItemEntity>

    @Query("SELECT * FROM images WHERE categoryId = :categoryId AND name = :name AND size = :size LIMIT 1")
    suspend fun findExactDuplicate(categoryId: Long, name: String, size: Long): ImageItemEntity?

    @Query("SELECT name FROM images WHERE categoryId = :categoryId AND (name = :baseName OR name LIKE :prefix)")
    suspend fun getConflictingNames(categoryId: Long, baseName: String, prefix: String): List<String>

    @Query("SELECT * FROM images WHERE isOriginal = 0 AND hasOriginal = 0")
    suspend fun getUnpairedResults(): List<ImageItemEntity>

    @Query("SELECT * FROM images WHERE isOriginal = 1")
    suspend fun getOrphanOriginals(): List<ImageItemEntity>

    @Query("SELECT * FROM images WHERE isOriginal = 1 AND LOWER(bk) = LOWER(:bk)")
    suspend fun getOrphanOriginalsByBk(bk: String): List<ImageItemEntity>

    @Query("SELECT * FROM images WHERE categoryId = :categoryId AND trashed = 0 AND favorite = 0")
    suspend fun getGalleryCandidates(categoryId: Long): List<ImageItemEntity>

    @Query("SELECT * FROM images WHERE categoryId = :categoryId AND trashed = 0 AND favorite = 1")
    suspend fun getFavoriteImages(categoryId: Long): List<ImageItemEntity>

    @Query("SELECT * FROM images WHERE categoryId = :categoryId AND trashed = 0 AND (hasOriginal = 0 OR isOriginal = 1)")
    suspend fun getLepasImages(categoryId: Long): List<ImageItemEntity>

    @Query("SELECT * FROM images WHERE categoryId = :categoryId AND trashed = 1")
    suspend fun getTrashImages(categoryId: Long): List<ImageItemEntity>

    @Query("UPDATE images SET favorite = :favorite WHERE id = :id")
    suspend fun setFavorite(id: Long, favorite: Boolean)

    @Query("UPDATE images SET trashed = :trashed, trashedAt = :trashedAt WHERE id = :id")
    suspend fun setTrashed(id: Long, trashed: Boolean, trashedAt: Long)

    @Query("UPDATE images SET trashed = :trashed, trashedAt = :trashedAt WHERE id IN (:ids)")
    suspend fun setBatchTrashed(ids: List<Long>, trashed: Boolean, trashedAt: Long)

    @Query("UPDATE images SET favorite = :favorite WHERE id IN (:ids)")
    suspend fun setBatchFavorite(ids: List<Long>, favorite: Boolean)

    @Query("UPDATE images SET categoryId = :targetCategoryId, seenGallery = 0, seenFav = 0, seenLepas = 0, seenTrash = 0 WHERE id IN (:ids)")
    suspend fun moveToCategory(ids: List<Long>, targetCategoryId: Long)

    @Query("UPDATE images SET seenGallery = :seen WHERE id = :id")
    suspend fun setSeenGallery(id: Long, seen: Boolean)

    @Query("UPDATE images SET seenFav = :seen WHERE id = :id")
    suspend fun setSeenFav(id: Long, seen: Boolean)

    @Query("UPDATE images SET seenLepas = :seen WHERE id = :id")
    suspend fun setSeenLepas(id: Long, seen: Boolean)

    @Query("UPDATE images SET seenTrash = :seen WHERE id = :id")
    suspend fun setSeenTrash(id: Long, seen: Boolean)

    @Query("UPDATE images SET lastSeenAt = :timestamp WHERE id = :id")
    suspend fun setLastSeenAt(id: Long, timestamp: Long)

    @Query("UPDATE images SET seenGallery = :seen, seenFav = :seen, seenLepas = :seen, seenTrash = :seen WHERE id IN (:ids)")
    suspend fun setBatchSeen(ids: List<Long>, seen: Boolean)

    @Query("SELECT MAX(batchId) FROM images")
    suspend fun getLatestBatchId(): Long?

    @Query("SELECT * FROM images WHERE batchId = :batchId")
    suspend fun getImagesByBatch(batchId: Long): List<ImageItemEntity>

    @Query("DELETE FROM images WHERE categoryId = :categoryId AND trashed = 1")
    suspend fun emptyTrashForCategory(categoryId: Long): Int

    @Query("DELETE FROM images WHERE categoryId = :categoryId AND trashed = 0 AND (hasOriginal = 0 OR isOriginal = 1)")
    suspend fun clearLepasForCategory(categoryId: Long): Int

    @Query("DELETE FROM images WHERE batchId = :batchId AND favorite = 0")
    suspend fun deleteLatestBatchExceptFavorites(batchId: Long): Int

    @Query("DELETE FROM images")
    suspend fun clearAllImages(): Int

    @Query("SELECT COUNT(*) FROM images WHERE bk = :bk AND isOriginal = 0")
    suspend fun countResultsUsingBk(bk: String): Int
}

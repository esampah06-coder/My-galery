package com.example.data.datastore

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "galeri_sortir_settings")

data class AppSettings(
    val gridColumns: Int = 3,
    val sortMode: String = "ADDED_DESC",
    val seenAtBottom: Boolean = false,
    val showLepasInGallery: Boolean = false,
    val showOrphanOriginalInGallery: Boolean = false,
    val lepasFilter: String = "ALL", // ALL, RESULT, ORIGINAL
    val navMode: String = "GESTURE", // GESTURE, BUTTONS, HYBRID, FAST_SORT
    val swipeDownMode: String = "ORIGINAL_FIRST", // ORIGINAL_FIRST, SHORT_LONG, DIRECT_TRASH
    val confirmTrash: Boolean = true,
    val horizontalSwipeEnabled: Boolean = true,
    val showThumbnails: Boolean = true,
    val importTreatPromptAsResult: Boolean = true,
    val importMatchTruncatedNames: Boolean = true,
    val multiSelectCount: Int = 250,
    val buttonSize: String = "MEDIUM", // SMALL, MEDIUM, LARGE
    val buttonTransparency: Float = 0.9f,
    val buttonPositionsPortrait: String = "",
    val buttonPositionsLandscape: String = "",
    val activeCategoryId: Long = 1L,
    val googleDriveApiKey: String = ""
)

class AppSettingsDataStore(private val context: Context) {

    private object Keys {
        val GRID_COLUMNS = intPreferencesKey("grid_columns")
        val SORT_MODE = stringPreferencesKey("sort_mode")
        val SEEN_AT_BOTTOM = booleanPreferencesKey("seen_at_bottom")
        val SHOW_LEPAS_IN_GALLERY = booleanPreferencesKey("show_lepas_in_gallery")
        val SHOW_ORPHAN_ORIGINAL_IN_GALLERY = booleanPreferencesKey("show_orphan_original_in_gallery")
        val LEPAS_FILTER = stringPreferencesKey("lepas_filter")
        val NAV_MODE = stringPreferencesKey("nav_mode")
        val SWIPE_DOWN_MODE = stringPreferencesKey("swipe_down_mode")
        val CONFIRM_TRASH = booleanPreferencesKey("confirm_trash")
        val HORIZONTAL_SWIPE_ENABLED = booleanPreferencesKey("horizontal_swipe_enabled")
        val SHOW_THUMBNAILS = booleanPreferencesKey("show_thumbnails")
        val IMPORT_TREAT_PROMPT_AS_RESULT = booleanPreferencesKey("import_treat_prompt_as_result")
        val IMPORT_MATCH_TRUNCATED_NAMES = booleanPreferencesKey("import_match_truncated_names")
        val MULTI_SELECT_COUNT = intPreferencesKey("multi_select_count")
        val BUTTON_SIZE = stringPreferencesKey("button_size")
        val BUTTON_TRANSPARENCY = floatPreferencesKey("button_transparency")
        val BUTTON_POS_PORTRAIT = stringPreferencesKey("button_pos_portrait")
        val BUTTON_POS_LANDSCAPE = stringPreferencesKey("button_pos_landscape")
        val ACTIVE_CATEGORY_ID = longPreferencesKey("active_category_id")
        val GOOGLE_DRIVE_API_KEY = stringPreferencesKey("google_drive_api_key")
    }

    val settingsFlow: Flow<AppSettings> = context.dataStore.data.map { prefs ->
        AppSettings(
            gridColumns = prefs[Keys.GRID_COLUMNS] ?: 3,
            sortMode = prefs[Keys.SORT_MODE] ?: "ADDED_DESC",
            seenAtBottom = prefs[Keys.SEEN_AT_BOTTOM] ?: false,
            showLepasInGallery = prefs[Keys.SHOW_LEPAS_IN_GALLERY] ?: false,
            showOrphanOriginalInGallery = prefs[Keys.SHOW_ORPHAN_ORIGINAL_IN_GALLERY] ?: false,
            lepasFilter = prefs[Keys.LEPAS_FILTER] ?: "ALL",
            navMode = prefs[Keys.NAV_MODE] ?: "GESTURE",
            swipeDownMode = prefs[Keys.SWIPE_DOWN_MODE] ?: "ORIGINAL_FIRST",
            confirmTrash = prefs[Keys.CONFIRM_TRASH] ?: true,
            horizontalSwipeEnabled = prefs[Keys.HORIZONTAL_SWIPE_ENABLED] ?: true,
            showThumbnails = prefs[Keys.SHOW_THUMBNAILS] ?: true,
            importTreatPromptAsResult = prefs[Keys.IMPORT_TREAT_PROMPT_AS_RESULT] ?: true,
            importMatchTruncatedNames = prefs[Keys.IMPORT_MATCH_TRUNCATED_NAMES] ?: true,
            multiSelectCount = prefs[Keys.MULTI_SELECT_COUNT] ?: 250,
            buttonSize = prefs[Keys.BUTTON_SIZE] ?: "MEDIUM",
            buttonTransparency = prefs[Keys.BUTTON_TRANSPARENCY] ?: 0.9f,
            buttonPositionsPortrait = prefs[Keys.BUTTON_POS_PORTRAIT] ?: "",
            buttonPositionsLandscape = prefs[Keys.BUTTON_POS_LANDSCAPE] ?: "",
            activeCategoryId = prefs[Keys.ACTIVE_CATEGORY_ID] ?: 1L,
            googleDriveApiKey = prefs[Keys.GOOGLE_DRIVE_API_KEY] ?: ""
        )
    }

    suspend fun updateGridColumns(cols: Int) = context.dataStore.edit { it[Keys.GRID_COLUMNS] = cols }
    suspend fun updateSortMode(mode: String) = context.dataStore.edit { it[Keys.SORT_MODE] = mode }
    suspend fun updateSeenAtBottom(enabled: Boolean) = context.dataStore.edit { it[Keys.SEEN_AT_BOTTOM] = enabled }
    suspend fun updateShowLepasInGallery(enabled: Boolean) = context.dataStore.edit { it[Keys.SHOW_LEPAS_IN_GALLERY] = enabled }
    suspend fun updateShowOrphanOriginalInGallery(enabled: Boolean) = context.dataStore.edit { it[Keys.SHOW_ORPHAN_ORIGINAL_IN_GALLERY] = enabled }
    suspend fun updateLepasFilter(filter: String) = context.dataStore.edit { it[Keys.LEPAS_FILTER] = filter }
    suspend fun updateNavMode(mode: String) = context.dataStore.edit { it[Keys.NAV_MODE] = mode }
    suspend fun updateSwipeDownMode(mode: String) = context.dataStore.edit { it[Keys.SWIPE_DOWN_MODE] = mode }
    suspend fun updateConfirmTrash(enabled: Boolean) = context.dataStore.edit { it[Keys.CONFIRM_TRASH] = enabled }
    suspend fun updateHorizontalSwipeEnabled(enabled: Boolean) = context.dataStore.edit { it[Keys.HORIZONTAL_SWIPE_ENABLED] = enabled }
    suspend fun updateShowThumbnails(enabled: Boolean) = context.dataStore.edit { it[Keys.SHOW_THUMBNAILS] = enabled }
    suspend fun updateImportTreatPromptAsResult(enabled: Boolean) = context.dataStore.edit { it[Keys.IMPORT_TREAT_PROMPT_AS_RESULT] = enabled }
    suspend fun updateImportMatchTruncatedNames(enabled: Boolean) = context.dataStore.edit { it[Keys.IMPORT_MATCH_TRUNCATED_NAMES] = enabled }
    suspend fun updateMultiSelectCount(count: Int) = context.dataStore.edit { it[Keys.MULTI_SELECT_COUNT] = count }
    suspend fun updateButtonSize(size: String) = context.dataStore.edit { it[Keys.BUTTON_SIZE] = size }
    suspend fun updateButtonTransparency(transparency: Float) = context.dataStore.edit { it[Keys.BUTTON_TRANSPARENCY] = transparency }
    suspend fun updateButtonPositionsPortrait(pos: String) = context.dataStore.edit { it[Keys.BUTTON_POS_PORTRAIT] = pos }
    suspend fun updateButtonPositionsLandscape(pos: String) = context.dataStore.edit { it[Keys.BUTTON_POS_LANDSCAPE] = pos }
    suspend fun updateActiveCategoryId(id: Long) = context.dataStore.edit { it[Keys.ACTIVE_CATEGORY_ID] = id }
    suspend fun updateGoogleDriveApiKey(key: String) = context.dataStore.edit { it[Keys.GOOGLE_DRIVE_API_KEY] = key }
}

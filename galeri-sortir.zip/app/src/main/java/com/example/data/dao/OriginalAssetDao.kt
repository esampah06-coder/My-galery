package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.entity.OriginalAssetEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface OriginalAssetDao {
    @Query("SELECT * FROM original_assets WHERE bk = :bk LIMIT 1")
    suspend fun getByBk(bk: String): OriginalAssetEntity?

    @Query("SELECT * FROM original_assets")
    suspend fun getAll(): List<OriginalAssetEntity>

    @Query("SELECT * FROM original_assets")
    fun getAllFlow(): Flow<List<OriginalAssetEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(asset: OriginalAssetEntity)

    @Update
    suspend fun update(asset: OriginalAssetEntity)

    @Delete
    suspend fun delete(asset: OriginalAssetEntity)

    @Query("DELETE FROM original_assets WHERE bk = :bk")
    suspend fun deleteByBk(bk: String)

    @Query("SELECT bk FROM original_assets")
    suspend fun getAllBks(): List<String>
}

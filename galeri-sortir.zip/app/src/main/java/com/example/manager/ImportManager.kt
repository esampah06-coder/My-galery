package com.example.manager

import android.content.Context
import android.net.Uri
import android.webkit.MimeTypeMap
import com.example.data.database.AppDatabase
import com.example.data.entity.ImageItemEntity
import com.example.data.entity.OriginalAssetEntity
import com.example.util.FileStorageHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

enum class ImportClassificationType {
    AUTO_MIX,
    FORCE_RESULT,
    FORCE_ORIGINAL
}

data class ImportProgress(
    val isRunning: Boolean = false,
    val current: Int = 0,
    val total: Int = 0,
    val currentFileName: String = "",
    val message: String = ""
)

data class ImportSummary(
    val totalProcessed: Int = 0,
    val resultsImported: Int = 0,
    val orphanOriginalsImported: Int = 0,
    val pairedOriginalsAdded: Int = 0,
    val duplicatesSkipped: Int = 0,
    val renamedCount: Int = 0,
    val failedCount: Int = 0,
    val failureReasons: List<String> = emptyList(),
    val isStorageFull: Boolean = false
)

class ImportManager(
    private val context: Context,
    private val database: AppDatabase
) {
    private val _progress = MutableStateFlow(ImportProgress())
    val progress: StateFlow<ImportProgress> = _progress.asStateFlow()

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(3, TimeUnit.MINUTES)
        .readTimeout(3, TimeUnit.MINUTES)
        .build()

    // Regexp for results like filename_prompt1_2.png
    private val promptRegex = Pattern.compile("^(.+)_prompt(\\d+)(?:_(\\d+))?\\.(png|jpe?g|webp)$", Pattern.CASE_INSENSITIVE)
    private val promptNumberRegex = Pattern.compile("prompt[_-]?(\\d+)", Pattern.CASE_INSENSITIVE)

    fun isImportRunning(): Boolean = _progress.value.isRunning

    data class RawEntry(
        val originalFileName: String,
        val size: Long,
        val modifiedTime: Long,
        val zipName: String,
        val zipTime: Long,
        val openStream: () -> InputStream
    )

    /**
     * Main import function for file entries (from SAF files, folders, or ZIPs)
     */
    suspend fun importEntries(
        entries: List<RawEntry>,
        categoryId: Long,
        type: ImportClassificationType,
        treatPromptAsResult: Boolean,
        matchTruncatedNames: Boolean
    ): ImportSummary = withContext(Dispatchers.IO) {
        if (_progress.value.isRunning) {
            return@withContext ImportSummary(
                failedCount = entries.size,
                failureReasons = listOf("Impor sebelumnya masih berjalan")
            )
        }

        _progress.value = ImportProgress(
            isRunning = true,
            current = 0,
            total = entries.size,
            message = "Menyiapkan impor..."
        )

        var resultsImported = 0
        var orphanOriginalsImported = 0
        var pairedOriginalsAdded = 0
        var duplicatesSkipped = 0
        var renamedCount = 0
        var failedCount = 0
        val failureReasons = mutableListOf<String>()
        var storageFull = false

        val batchId = System.currentTimeMillis()
        val imagesDir = FileStorageHelper.getImagesDir(context)
        val thumbsDir = FileStorageHelper.getThumbnailsDir(context)

        try {
            // Check storage headroom: require at least 15MB free
            if (FileStorageHelper.getAvailableInternalMemoryBytes(context) < 15L * 1024 * 1024) {
                storageFull = true
                failureReasons.add("Penyimpanan HP hampir penuh")
                return@withContext ImportSummary(
                    totalProcessed = 0,
                    failedCount = entries.size,
                    failureReasons = failureReasons,
                    isStorageFull = true
                )
            }

            // Load known keys from database
            val existingAssets = database.originalAssetDao().getAll()
            val knownBkMap = existingAssets.associateBy { it.bk }.toMutableMap()

            // Separate candidates into Originals and Results according to classification
            val originalCandidates = mutableListOf<RawEntry>()
            val resultCandidates = mutableListOf<RawEntry>()

            for (entry in entries) {
                val isResult = classifyEntry(
                    fileName = entry.originalFileName,
                    type = type,
                    treatPromptAsResult = treatPromptAsResult,
                    knownBks = knownBkMap.keys
                )
                if (isResult) {
                    resultCandidates.add(entry)
                } else {
                    originalCandidates.add(entry)
                }
            }

            // Step 1: Process Originals first
            // Prepare map of result basenames in this batch to detect if an original has results
            val batchResultNames = resultCandidates.map { it.originalFileName.lowercase() }

            val newOriginalsSavedThisBatch = mutableMapOf<String, OriginalAssetEntity>()

            for ((index, origEntry) in originalCandidates.withIndex()) {
                if (FileStorageHelper.getAvailableInternalMemoryBytes(context) < 10L * 1024 * 1024) {
                    storageFull = true
                    failureReasons.add("Penyimpanan penuh saat memproses gambar asli")
                    break
                }

                _progress.value = ImportProgress(
                    isRunning = true,
                    current = index + 1,
                    total = entries.size,
                    currentFileName = origEntry.originalFileName,
                    message = "Mengimpor gambar asli ${index + 1}/${entries.size}..."
                )

                val fileName = origEntry.originalFileName
                val base = getBaseName(fileName)
                val bk = base.lowercase()

                // Check if already in originalAssets
                val alreadyExistsInAssets = knownBkMap.containsKey(bk)
                // Check if already in images as orphan original
                val existingOrphan = database.imageItemDao().getOrphanOriginalsByBk(bk)

                if (alreadyExistsInAssets || existingOrphan.isNotEmpty()) {
                    duplicatesSkipped++
                    continue
                }

                // Check if any results match this original (in this batch or in database un-paired)
                val hasMatchInBatch = batchResultNames.any { it.startsWith(bk) }
                val unPairedInDb = database.imageItemDao().getUnpairedResults()
                val hasMatchInDb = unPairedInDb.any { it.name.lowercase().startsWith(bk) }

                // Save image file and thumbnail
                val uniqueFileName = resolveUniqueFileName(fileName, categoryId, origEntry.size)
                if (uniqueFileName == null) {
                    duplicatesSkipped++
                    continue
                }
                if (uniqueFileName != fileName) {
                    renamedCount++
                }

                val imageFile = File(imagesDir, uniqueFileName)
                val thumbFile = File(thumbsDir, "$uniqueFileName.thumb.jpg")

                val writeSuccess = try {
                    origEntry.openStream().use { input ->
                        FileStorageHelper.saveStreamToFile(input, imageFile)
                    }
                    FileStorageHelper.createThumbnail(imageFile, thumbFile)
                } catch (e: Exception) {
                    failedCount++
                    failureReasons.add("Gagal membaca ${origEntry.originalFileName}: ${e.message}")
                    false
                }

                if (!writeSuccess) continue

                val assetEntity = OriginalAssetEntity(
                    bk = bk,
                    originalFileName = fileName,
                    filePath = imageFile.absolutePath,
                    thumbnailPath = thumbFile.absolutePath,
                    size = imageFile.length(),
                    addedAt = System.currentTimeMillis()
                )

                if (hasMatchInBatch || hasMatchInDb) {
                    // Save as paired original asset
                    database.originalAssetDao().insert(assetEntity)
                    knownBkMap[bk] = assetEntity
                    newOriginalsSavedThisBatch[bk] = assetEntity
                    pairedOriginalsAdded++
                } else {
                    // Save as orphan original card in images
                    val orphanCard = ImageItemEntity(
                        name = uniqueFileName,
                        originalName = fileName,
                        base = base,
                        bk = bk,
                        promptNo = 0,
                        isOriginalCard = true,
                        hasOriginalPair = false,
                        favorite = false,
                        trashed = false,
                        addedAt = System.currentTimeMillis(),
                        batchId = batchId,
                        fileModified = origEntry.modifiedTime,
                        zipTime = origEntry.zipTime,
                        zipName = origEntry.zipName,
                        size = imageFile.length(),
                        categoryId = categoryId,
                        filePath = imageFile.absolutePath,
                        thumbnailPath = thumbFile.absolutePath
                    )
                    database.imageItemDao().insert(orphanCard)
                    orphanOriginalsImported++
                    knownBkMap[bk] = assetEntity
                }
            }

            // Step 2: Process Results
            val allKnownBks = (knownBkMap.keys + newOriginalsSavedThisBatch.keys).toList()

            for ((rIndex, resEntry) in resultCandidates.withIndex()) {
                if (storageFull || FileStorageHelper.getAvailableInternalMemoryBytes(context) < 10L * 1024 * 1024) {
                    storageFull = true
                    failureReasons.add("Penyimpanan penuh saat memproses hasil")
                    break
                }

                val currentIdx = originalCandidates.size + rIndex + 1
                _progress.value = ImportProgress(
                    isRunning = true,
                    current = currentIdx,
                    total = entries.size,
                    currentFileName = resEntry.originalFileName,
                    message = "Mengimpor hasil ${currentIdx}/${entries.size}..."
                )

                val fileName = resEntry.originalFileName
                val base = getBaseName(fileName)
                val promptNo = extractPromptNumber(fileName)

                // Match with paired original
                val matchedBk = findBestMatchingOriginalKey(
                    resultName = fileName,
                    knownBks = allKnownBks,
                    matchTruncatedNames = matchTruncatedNames
                )

                val uniqueFileName = resolveUniqueFileName(fileName, categoryId, resEntry.size)
                if (uniqueFileName == null) {
                    duplicatesSkipped++
                    continue
                }
                if (uniqueFileName != fileName) {
                    renamedCount++
                }

                val imageFile = File(imagesDir, uniqueFileName)
                val thumbFile = File(thumbsDir, "$uniqueFileName.thumb.jpg")

                val writeSuccess = try {
                    resEntry.openStream().use { input ->
                        FileStorageHelper.saveStreamToFile(input, imageFile)
                    }
                    FileStorageHelper.createThumbnail(imageFile, thumbFile)
                } catch (e: Exception) {
                    failedCount++
                    failureReasons.add("Gagal membaca ${resEntry.originalFileName}: ${e.message}")
                    false
                }

                if (!writeSuccess) continue

                val itemEntity = ImageItemEntity(
                    name = uniqueFileName,
                    originalName = fileName,
                    base = base,
                    bk = matchedBk ?: "",
                    promptNo = promptNo,
                    isOriginalCard = false,
                    hasOriginalPair = matchedBk != null,
                    favorite = false,
                    trashed = false,
                    addedAt = System.currentTimeMillis(),
                    batchId = batchId,
                    fileModified = resEntry.modifiedTime,
                    zipTime = resEntry.zipTime,
                    zipName = resEntry.zipName,
                    size = imageFile.length(),
                    categoryId = categoryId,
                    filePath = imageFile.absolutePath,
                    thumbnailPath = thumbFile.absolutePath
                )

                database.imageItemDao().insert(itemEntity)
                resultsImported++
            }

            // Step 3: Retroactive re-pairing
            // Match any previously un-paired results with the newly imported originals
            // And merge any orphan original cards that now have results!
            rePairOldResultsAndOrphans(matchTruncatedNames)

        } finally {
            _progress.value = ImportProgress(isRunning = false)
        }

        ImportSummary(
            totalProcessed = entries.size,
            resultsImported = resultsImported,
            orphanOriginalsImported = orphanOriginalsImported,
            pairedOriginalsAdded = pairedOriginalsAdded,
            duplicatesSkipped = duplicatesSkipped,
            renamedCount = renamedCount,
            failedCount = failedCount,
            failureReasons = failureReasons,
            isStorageFull = storageFull
        )
    }

    /**
     * Re-matches un-paired results in database and merges orphan cards that now have results
     */
    private suspend fun rePairOldResultsAndOrphans(matchTruncatedNames: Boolean) {
        val unpairedResults = database.imageItemDao().getUnpairedResults()
        val allAssets = database.originalAssetDao().getAll()
        val orphanOriginals = database.imageItemDao().getOrphanOriginals()

        val allBks = allAssets.map { it.bk }.toMutableSet()

        // First convert any orphan original whose bk now matches a result into an original_asset
        for (orphan in orphanOriginals) {
            val hasResult = unpairedResults.any { it.name.lowercase().startsWith(orphan.bk) }
            if (hasResult) {
                // Save to original_assets
                database.originalAssetDao().insert(
                    OriginalAssetEntity(
                        bk = orphan.bk,
                        originalFileName = orphan.originalName,
                        filePath = orphan.filePath,
                        thumbnailPath = orphan.thumbnailPath,
                        size = orphan.size,
                        addedAt = orphan.addedAt
                    )
                )
                allBks.add(orphan.bk)
                // Delete orphan card from images table
                database.imageItemDao().delete(orphan)
            }
        }

        // Now pair previously unpaired results
        val bkList = allBks.toList()
        for (unpaired in unpairedResults) {
            val matched = findBestMatchingOriginalKey(
                resultName = unpaired.name,
                knownBks = bkList,
                matchTruncatedNames = matchTruncatedNames
            )
            if (matched != null) {
                database.imageItemDao().update(
                    unpaired.copy(
                        bk = matched,
                        hasOriginalPair = true
                    )
                )
            }
        }
    }

    /**
     * Resolves unique file name in category:
     * - Returns null if exact duplicate (same name AND same size)
     * - Returns original name if no clash
     * - Returns name with _2, _3 suffix if name matches but size differs
     */
    private suspend fun resolveUniqueFileName(
        name: String,
        categoryId: Long,
        size: Long
    ): String? {
        val exactDup = database.imageItemDao().findExactDuplicate(categoryId, name, size)
        if (exactDup != null) {
            return null // Skip duplicate
        }

        val ext = getExtension(name)
        val base = getBaseName(name)
        val conflicting = database.imageItemDao().getConflictingNames(categoryId, name, "$base%")
        if (!conflicting.contains(name)) {
            return name
        }

        // Conflict exists with different size: find next available suffix _2, _3, ...
        var counter = 2
        while (true) {
            val candidate = if (ext.isNotEmpty()) "${base}_$counter.$ext" else "${base}_$counter"
            if (!conflicting.contains(candidate)) {
                return candidate
            }
            counter++
        }
    }

    /**
     * Classifies entry into result or original according to section 5.2
     */
    fun classifyEntry(
        fileName: String,
        type: ImportClassificationType,
        treatPromptAsResult: Boolean,
        knownBks: Set<String>
    ): Boolean {
        when (type) {
            ImportClassificationType.FORCE_RESULT -> return true
            ImportClassificationType.FORCE_ORIGINAL -> return false
            ImportClassificationType.AUTO_MIX -> {
                val lower = fileName.lowercase()
                if (treatPromptAsResult) {
                    return lower.contains("prompt")
                }
                if (promptRegex.matcher(fileName).matches()) {
                    return true
                }
                // Check if starts with a known original key
                return knownBks.any { bk ->
                    lower.startsWith(bk) && isDigitBoundaryValid(lower, bk)
                }
            }
        }
    }

    /**
     * Pairing rules from section 5.3:
     * - Result starts with original key (case-insensitive)
     * - If original key ends in a digit, next character in result cannot be a digit
     * - If multiple match, pick the LONGEST
     * - Truncated matching if enabled and unambiguous
     */
    fun findBestMatchingOriginalKey(
        resultName: String,
        knownBks: List<String>,
        matchTruncatedNames: Boolean
    ): String? {
        val lowerResult = resultName.lowercase()

        // 1. Exact prefix matching
        val prefixMatches = knownBks.filter { bk ->
            lowerResult.startsWith(bk) && isDigitBoundaryValid(lowerResult, bk)
        }

        if (prefixMatches.isNotEmpty()) {
            return prefixMatches.maxByOrNull { it.length }
        }

        // 2. Truncated matching
        if (matchTruncatedNames) {
            val stem = extractStem(lowerResult)
            if (stem.length >= 8) {
                val candidates = knownBks.filter { bk ->
                    bk.length > stem.length &&
                            bk.startsWith(stem) &&
                            (stem.length >= 40 || isTruncatedBoundaryValid(bk, stem.length)) &&
                            isDigitBoundaryValid(lowerResult, stem)
                }
                if (candidates.size == 1) {
                    return candidates.first()
                }
            }
        }

        return null
    }

    private fun isDigitBoundaryValid(target: String, key: String): Boolean {
        if (key.isEmpty()) return false
        val lastChar = key.last()
        if (lastChar.isDigit()) {
            val nextCharIdx = key.length
            if (nextCharIdx < target.length) {
                val nextChar = target[nextCharIdx]
                if (nextChar.isDigit()) {
                    return false
                }
            }
        }
        return true
    }

    private fun isTruncatedBoundaryValid(key: String, stemLen: Int): Boolean {
        if (stemLen >= key.length) return false
        val charAfterStem = key[stemLen]
        return charAfterStem == '.' || charAfterStem == '-' || charAfterStem == '_' || charAfterStem == ' '
    }

    private fun extractStem(lowerName: String): String {
        val base = getBaseName(lowerName)
        val patterns = listOf("_prompt", "-prompt", " prompt", "prompt")
        for (p in patterns) {
            val idx = base.indexOf(p)
            if (idx > 0) {
                return base.substring(0, idx)
            }
        }
        return base
    }

    private fun extractPromptNumber(name: String): Int {
        val matcher = promptNumberRegex.matcher(name)
        return if (matcher.find()) {
            matcher.group(1)?.toIntOrNull() ?: 0
        } else {
            0
        }
    }

    private fun getBaseName(fileName: String): String {
        val dotIdx = fileName.lastIndexOf('.')
        return if (dotIdx > 0) fileName.substring(0, dotIdx) else fileName
    }

    private fun getExtension(fileName: String): String {
        val dotIdx = fileName.lastIndexOf('.')
        return if (dotIdx > 0 && dotIdx < fileName.length - 1) fileName.substring(dotIdx + 1) else ""
    }

    /**
     * Reads a ZIP file via streaming ZipInputStream without loading into RAM
     */
    fun parseZipEntries(
        zipInputStream: InputStream,
        zipName: String,
        zipTime: Long
    ): List<RawEntry> {
        val entries = mutableListOf<RawEntry>()
        val tempDir = File(context.cacheDir, "zip_extract_${System.currentTimeMillis()}")
        tempDir.mkdirs()

        try {
            val zis = ZipInputStream(BufferedInputStream(zipInputStream))
            var entry: ZipEntry? = zis.nextEntry
            var fileIdx = 0

            while (entry != null) {
                val name = entry.name
                // Ignore __MACOSX, dot files, and directories
                if (!entry.isDirectory &&
                    !name.contains("__MACOSX") &&
                    !File(name).name.startsWith(".")
                ) {
                    val cleanFileName = File(name).name
                    val ext = getExtension(cleanFileName).lowercase()
                    if (ext in listOf("png", "jpg", "jpeg", "webp")) {
                        val tempFile = File(tempDir, "item_${fileIdx++}_$cleanFileName")
                        FileOutputStream(tempFile).use { fos ->
                            val buffer = ByteArray(8192)
                            var len: Int
                            while (zis.read(buffer).also { len = it } != -1) {
                                fos.write(buffer, 0, len)
                            }
                            fos.flush()
                        }

                        entries.add(
                            RawEntry(
                                originalFileName = cleanFileName,
                                size = tempFile.length(),
                                modifiedTime = entry.time.takeIf { it > 0 } ?: zipTime,
                                zipName = zipName,
                                zipTime = zipTime,
                                openStream = { FileInputStream(tempFile) }
                            )
                        )
                    }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return entries
    }

    /**
     * Downloads files or ZIPs from a list of URLs with streaming and 3-minute timeout
     */
    suspend fun downloadAndImportUrls(
        urls: List<String>,
        categoryId: Long,
        type: ImportClassificationType,
        treatPromptAsResult: Boolean,
        matchTruncatedNames: Boolean,
        googleDriveApiKey: String = ""
    ): ImportSummary = withContext(Dispatchers.IO) {
        val entries = mutableListOf<RawEntry>()
        val failedUrls = mutableListOf<String>()

        for ((idx, rawUrl) in urls.withIndex()) {
            val url = rawUrl.trim()
            if (url.isEmpty()) continue

            _progress.value = ImportProgress(
                isRunning = true,
                current = idx + 1,
                total = urls.size,
                currentFileName = url,
                message = "Mengunduh tautan ${idx + 1}/${urls.size}..."
            )

            try {
                val effectiveUrl = resolveDriveUrl(url, googleDriveApiKey)
                val request = Request.Builder().url(effectiveUrl).build()

                httpClient.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        failedUrls.add("$url: HTTP ${response.code}")
                        return@use
                    }

                    val body = response.body
                    if (body == null) {
                        failedUrls.add("$url: Respon kosong")
                        return@use
                    }

                    val contentType = response.header("Content-Type")?.lowercase() ?: ""
                    if (contentType.contains("text/html")) {
                        failedUrls.add("$url: Konten berupa HTML (bukan file gambar/ZIP)")
                        return@use
                    }

                    val resolvedFileName = resolveFileNameFromResponse(response, url)
                    val ext = getExtension(resolvedFileName).lowercase()

                    val tempFile = File(context.cacheDir, "dl_${System.currentTimeMillis()}_$resolvedFileName")
                    body.byteStream().use { input ->
                        FileOutputStream(tempFile).use { out ->
                            val buf = ByteArray(8192)
                            var r: Int
                            while (input.read(buf).also { r = it } != -1) {
                                out.write(buf, 0, r)
                            }
                            out.flush()
                        }
                    }

                    if (ext == "zip" || contentType.contains("zip")) {
                        val zipEntries = parseZipEntries(
                            FileInputStream(tempFile),
                            zipName = resolvedFileName,
                            zipTime = System.currentTimeMillis()
                        )
                        entries.addAll(zipEntries)
                    } else if (ext in listOf("png", "jpg", "jpeg", "webp")) {
                        entries.add(
                            RawEntry(
                                originalFileName = resolvedFileName,
                                size = tempFile.length(),
                                modifiedTime = System.currentTimeMillis(),
                                zipName = "",
                                zipTime = 0L,
                                openStream = { FileInputStream(tempFile) }
                            )
                        )
                    } else {
                        failedUrls.add("$url: Format file tidak didukung ($resolvedFileName)")
                    }
                }
            } catch (e: Exception) {
                failedUrls.add("$url: ${e.message}")
            }
        }

        if (entries.isEmpty()) {
            _progress.value = ImportProgress(isRunning = false)
            return@withContext ImportSummary(
                totalProcessed = urls.size,
                failedCount = failedUrls.size,
                failureReasons = failedUrls
            )
        }

        val importResult = importEntries(
            entries = entries,
            categoryId = categoryId,
            type = type,
            treatPromptAsResult = treatPromptAsResult,
            matchTruncatedNames = matchTruncatedNames
        )

        importResult.copy(
            failedCount = importResult.failedCount + failedUrls.size,
            failureReasons = importResult.failureReasons + failedUrls
        )
    }

    private fun resolveDriveUrl(url: String, apiKey: String): String {
        // Check for Google Drive folder link
        if (url.contains("/drive/folders/")) {
            throw IllegalArgumentException("Link folder Google Drive tidak didukung. Harap gunakan link file langsung.")
        }

        // Check for /file/d/ID or ?id=ID
        val driveIdPattern = Pattern.compile("(?:/file/d/|\\?id=)([a-zA-Z0-9_-]+)")
        val matcher = driveIdPattern.matcher(url)
        if (matcher.find()) {
            val fileId = matcher.group(1) ?: return url
            return if (apiKey.isNotEmpty()) {
                "https://www.googleapis.com/drive/v3/files/$fileId?alt=media&key=$apiKey"
            } else {
                "https://drive.google.com/uc?export=download&id=$fileId"
            }
        }
        return url
    }

    private fun resolveFileNameFromResponse(response: okhttp3.Response, fallbackUrl: String): String {
        val cd = response.header("Content-Disposition")
        if (cd != null && cd.contains("filename=")) {
            val match = Pattern.compile("filename=[\"']?([^\"';]+)[\"']?").matcher(cd)
            if (match.find()) {
                val fn = match.group(1)?.trim()
                if (!fn.isNullOrEmpty()) return fn
            }
        }

        // Try Uri path
        val uri = Uri.parse(fallbackUrl)
        val lastSegment = uri.lastPathSegment
        if (!lastSegment.isNullOrEmpty() && lastSegment.contains(".")) {
            return lastSegment
        }

        // Fallback from MIME
        val mime = response.header("Content-Type")?.substringBefore(";")?.trim() ?: "image/png"
        val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime) ?: "png"
        return "download_${System.currentTimeMillis()}.$ext"
    }
}

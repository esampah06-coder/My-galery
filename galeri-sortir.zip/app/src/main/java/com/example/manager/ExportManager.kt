package com.example.manager

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.example.data.database.AppDatabase
import com.example.data.entity.ImageItemEntity
import com.example.data.entity.OriginalAssetEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

enum class ExportContentType(val label: String) {
    RESULT_ONLY("Hasil saja"),
    RESULT_AND_ORIGINAL("Hasil + gambar asli"),
    ORIGINAL_ONLY("Gambar asli saja")
}

data class ExportFileItem(
    val entryName: String,
    val sourceFile: File,
    val isOriginal: Boolean = false
)

data class ExportPart(
    val partIndex: Int,
    val totalParts: Int,
    val items: List<ExportFileItem>,
    var status: PartStatus = PartStatus.IDLE,
    var downloadedFileName: String = "",
    var errorMessage: String = ""
)

enum class PartStatus {
    IDLE,
    PREPARING,
    DOWNLOADED,
    FAILED
}

class ExportManager(
    private val context: Context,
    private val database: AppDatabase
) {

    /**
     * Resolves all files to export according to scope, category, content type, and seen status.
     * Prevents duplication of shared original reference images.
     */
    suspend fun prepareExportFiles(
        items: List<ImageItemEntity>,
        contentType: ExportContentType,
        onlySeen: Boolean,
        tabName: String
    ): List<ExportFileItem> = withContext(Dispatchers.IO) {
        val filteredItems = if (onlySeen) {
            when (tabName.lowercase()) {
                "favorit" -> items.filter { it.seenFav }
                "lepas" -> items.filter { it.seenLepas }
                "trash" -> items.filter { it.seenTrash }
                else -> items.filter { it.seenGallery }
            }
        } else {
            items
        }

        val exportList = mutableListOf<ExportFileItem>()
        val includedOriginalBks = mutableSetOf<String>()

        when (contentType) {
            ExportContentType.RESULT_ONLY -> {
                for (item in filteredItems) {
                    if (!item.isOriginal) {
                        val file = File(item.filePath)
                        if (file.exists()) {
                            exportList.add(ExportFileItem(item.originalName, file, false))
                        }
                    }
                }
            }

            ExportContentType.ORIGINAL_ONLY -> {
                // Collect originals corresponding to these items
                for (item in filteredItems) {
                    if (item.isOriginal) {
                        val file = File(item.filePath)
                        if (file.exists() && includedOriginalBks.add(item.bk)) {
                            exportList.add(ExportFileItem(item.originalName, file, true))
                        }
                    } else if (item.hasOriginal && item.bk.isNotEmpty() && includedOriginalBks.add(item.bk)) {
                        val asset = database.originalAssetDao().getByBk(item.bk)
                        if (asset != null) {
                            val file = File(asset.filePath)
                            if (file.exists()) {
                                exportList.add(ExportFileItem(asset.originalFileName, file, true))
                            }
                        }
                    }
                }
            }

            ExportContentType.RESULT_AND_ORIGINAL -> {
                // Results + deduplicated originals
                for (item in filteredItems) {
                    if (!item.isOriginal) {
                        val file = File(item.filePath)
                        if (file.exists()) {
                            exportList.add(ExportFileItem(item.originalName, file, false))
                        }
                    }
                    if (item.hasOriginal && item.bk.isNotEmpty() && includedOriginalBks.add(item.bk)) {
                        val asset = database.originalAssetDao().getByBk(item.bk)
                        if (asset != null) {
                            val file = File(asset.filePath)
                            if (file.exists()) {
                                exportList.add(ExportFileItem(asset.originalFileName, file, true))
                            }
                        }
                    } else if (item.isOriginal && includedOriginalBks.add(item.bk)) {
                        val file = File(item.filePath)
                        if (file.exists()) {
                            exportList.add(ExportFileItem(item.originalName, file, true))
                        }
                    }
                }
            }
        }

        exportList
    }

    /**
     * Splits prepared files into chunks of max 250 files per part
     */
    fun splitIntoParts(files: List<ExportFileItem>, maxPerPart: Int = 250): List<ExportPart> {
        if (files.isEmpty()) return emptyList()
        val chunks = files.chunked(maxPerPart)
        return chunks.mapIndexed { index, chunk ->
            ExportPart(
                partIndex = index + 1,
                totalParts = chunks.size,
                items = chunk
            )
        }
    }

    /**
     * Exports a single part streaming with STORED method directly to user's Download directory
     */
    suspend fun exportPartToDownloads(
        part: ExportPart,
        tabName: String,
        categoryName: String,
        contentType: ExportContentType
    ): Result<String> = withContext(Dispatchers.IO) {
        val dateStr = SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date())
        val typeTag = when (contentType) {
            ExportContentType.RESULT_ONLY -> "Hasil"
            ExportContentType.RESULT_AND_ORIGINAL -> "HasilDanAsli"
            ExportContentType.ORIGINAL_ONLY -> "Asli"
        }
        val partSuffix = if (part.totalParts > 1) "_bagian${part.partIndex}" else ""
        val safeCategory = categoryName.replace("[^a-zA-Z0-9_-]".toRegex(), "")
        val safeTab = tabName.replace("[^a-zA-Z0-9_-]".toRegex(), "")
        val fileName = "${safeTab}_${safeCategory}_${typeTag}_${dateStr}$partSuffix.zip"

        try {
            openDownloadOutputStream(fileName).use { outputStream ->
                if (outputStream == null) {
                    return@withContext Result.failure(Exception("Tidak dapat membuka folder Download"))
                }

                ZipOutputStream(outputStream).use { zos ->
                    // Set STORED method (no compression) as strictly requested in prompt
                    zos.setMethod(ZipOutputStream.STORED)

                    val usedNames = mutableSetOf<String>()
                    val buffer = ByteArray(32768)

                    for (item in part.items) {
                        if (!item.sourceFile.exists()) continue

                        // Ensure unique entry name in zip
                        var entryName = item.entryName
                        var counter = 2
                        while (usedNames.contains(entryName)) {
                            val dot = item.entryName.lastIndexOf('.')
                            entryName = if (dot > 0) {
                                "${item.entryName.substring(0, dot)}_$counter.${item.entryName.substring(dot + 1)}"
                            } else {
                                "${item.entryName}_$counter"
                            }
                            counter++
                        }
                        usedNames.add(entryName)

                        val fileLength = item.sourceFile.length()

                        // Calculate CRC32 for STORED entry
                        val crc = CRC32()
                        FileInputStream(item.sourceFile).use { fis ->
                            var len: Int
                            while (fis.read(buffer).also { len = it } != -1) {
                                crc.update(buffer, 0, len)
                            }
                        }

                        val entry = ZipEntry(entryName).apply {
                            method = ZipEntry.STORED
                            size = fileLength
                            compressedSize = fileLength
                            setCrc(crc.value)
                            time = item.sourceFile.lastModified()
                        }

                        zos.putNextEntry(entry)
                        FileInputStream(item.sourceFile).use { fis ->
                            var len: Int
                            while (fis.read(buffer).also { len = it } != -1) {
                                zos.write(buffer, 0, len)
                            }
                        }
                        zos.closeEntry()
                    }
                    zos.finish()
                }
            }
            Result.success(fileName)
        } catch (e: Exception) {
            e.printStackTrace()
            Result.failure(e)
        }
    }

    /**
     * Downloads a single image from fullscreen viewer to Download directory
     */
    suspend fun saveSingleImageToDownloads(file: File, originalName: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            openDownloadOutputStream(originalName).use { out ->
                if (out == null) return@withContext Result.failure(Exception("Tidak dapat menulis ke Download"))
                FileInputStream(file).use { input ->
                    val buffer = ByteArray(8192)
                    var read: Int
                    while (input.read(buffer).also { read = it } != -1) {
                        out.write(buffer, 0, read)
                    }
                    out.flush()
                }
            }
            Result.success(originalName)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun openDownloadOutputStream(fileName: String): OutputStream? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, if (fileName.endsWith(".zip")) "application/zip" else "image/*")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            if (uri != null) context.contentResolver.openOutputStream(uri) else null
        } else {
            val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            if (!downloadsDir.exists()) downloadsDir.mkdirs()
            val target = File(downloadsDir, fileName)
            FileOutputStream(target)
        }
    }
}

package com.example.manager

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.example.data.database.AppDatabase
import com.example.data.entity.CategoryEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class BackupRecord(
    val fileName: String,
    val categoryName: String,
    val favorite: Boolean,
    val trashed: Boolean,
    val seenGallery: Boolean,
    val seenFav: Boolean,
    val seenLepas: Boolean,
    val seenTrash: Boolean
)

class BackupManager(
    private val context: Context,
    private val database: AppDatabase
) {

    /**
     * Exports selection metadata (favorite, trashed, seen) by fileName + categoryName to JSON
     */
    suspend fun exportBackupJson(): Result<String> = withContext(Dispatchers.IO) {
        val dateStr = SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date())
        val fileName = "GaleriPilihan_$dateStr.json"

        try {
            val categories = database.categoryDao().getAllCategoriesSync()
            val categoryMap = categories.associateBy { it.id }
            val images = database.imageItemDao().getAllImages()

            val jsonArray = JSONArray()
            for (img in images) {
                val catName = categoryMap[img.categoryId]?.name ?: "3D"
                val obj = JSONObject().apply {
                    put("fileName", img.originalName)
                    put("categoryName", catName)
                    put("favorite", img.favorite)
                    put("trashed", img.trashed)
                    put("seenGallery", img.seenGallery)
                    put("seenFav", img.seenFav)
                    put("seenLepas", img.seenLepas)
                    put("seenTrash", img.seenTrash)
                }
                jsonArray.put(obj)
            }

            val root = JSONObject().apply {
                put("version", 1)
                put("exportedAt", System.currentTimeMillis())
                put("totalRecords", jsonArray.length())
                put("records", jsonArray)
            }

            val jsonString = root.toString(2)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/json")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                }
                val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: return@withContext Result.failure(Exception("Gagal membuat file di folder Download"))
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    out.write(jsonString.toByteArray(Charsets.UTF_8))
                }
            } else {
                val dlDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                if (!dlDir.exists()) dlDir.mkdirs()
                val targetFile = File(dlDir, fileName)
                FileOutputStream(targetFile).use { out ->
                    out.write(jsonString.toByteArray(Charsets.UTF_8))
                }
            }

            Result.success(fileName)
        } catch (e: Exception) {
            e.printStackTrace()
            Result.failure(e)
        }
    }

    /**
     * Restores selection state from JSON InputStream.
     * Creates any missing categories and applies to matching files.
     */
    suspend fun restoreBackupJson(inputStream: InputStream): Result<Int> = withContext(Dispatchers.IO) {
        try {
            val jsonString = inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val root = JSONObject(jsonString)
            val records = root.optJSONArray("records") ?: JSONArray()

            var restoredCount = 0
            val existingCategories = database.categoryDao().getAllCategoriesSync().toMutableList()
            val catNameToId = existingCategories.associate { it.name.lowercase() to it.id }.toMutableMap()

            val allImages = database.imageItemDao().getAllImages().toMutableList()

            for (i in 0 until records.length()) {
                val obj = records.getJSONObject(i)
                val fileName = obj.getString("fileName")
                val catName = obj.optString("categoryName", "3D")
                val favorite = obj.optBoolean("favorite", false)
                val trashed = obj.optBoolean("trashed", false)
                val seenGallery = obj.optBoolean("seenGallery", false)
                val seenFav = obj.optBoolean("seenFav", false)
                val seenLepas = obj.optBoolean("seenLepas", false)
                val seenTrash = obj.optBoolean("seenTrash", false)

                // Get or create category
                var catId = catNameToId[catName.lowercase()]
                if (catId == null) {
                    val newCat = CategoryEntity(name = catName)
                    catId = database.categoryDao().insert(newCat)
                    catNameToId[catName.lowercase()] = catId
                }

                // Find matching image by originalName and categoryId
                val match = allImages.firstOrNull { it.originalName.equals(fileName, ignoreCase = true) && it.categoryId == catId }
                if (match != null) {
                    val updated = match.copy(
                        favorite = favorite,
                        trashed = trashed,
                        seenGallery = seenGallery,
                        seenFav = seenFav,
                        seenLepas = seenLepas,
                        seenTrash = seenTrash
                    )
                    database.imageItemDao().update(updated)
                    restoredCount++
                }
            }

            Result.success(restoredCount)
        } catch (e: Exception) {
            e.printStackTrace()
            Result.failure(e)
        }
    }
}

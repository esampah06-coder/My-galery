package com.example.manager

import android.content.Context
import com.example.data.database.AppDatabase
import com.example.data.entity.ImageItemEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class CleanManager(
    private val context: Context,
    private val database: AppDatabase
) {

    /**
     * Empty Trash for specified category. Deletes physical files and unused original assets.
     */
    suspend fun emptyTrash(categoryId: Long): Int = withContext(Dispatchers.IO) {
        val trashItems = database.imageItemDao().getTrashImages(categoryId)
        deleteItemsAndCleanAssets(trashItems)
        trashItems.size
    }

    /**
     * Clear Lepas (unpaired results + orphan originals) for specified category.
     */
    suspend fun clearLepas(categoryId: Long): Int = withContext(Dispatchers.IO) {
        val lepasItems = database.imageItemDao().getLepasImages(categoryId)
        deleteItemsAndCleanAssets(lepasItems)
        lepasItems.size
    }

    /**
     * Clear latest batch except favorites.
     */
    suspend fun clearLatestBatch(): Pair<Int, Long?> = withContext(Dispatchers.IO) {
        val latestBatchId = database.imageItemDao().getLatestBatchId() ?: return@withContext Pair(0, null)
        val batchItems = database.imageItemDao().getImagesByBatch(latestBatchId)
        val nonFavorites = batchItems.filter { !it.favorite }
        deleteItemsAndCleanAssets(nonFavorites)
        Pair(nonFavorites.size, latestBatchId)
    }

    /**
     * Clear ALL images across all categories.
     */
    suspend fun clearAllCategories(): Int = withContext(Dispatchers.IO) {
        val allImages = database.imageItemDao().getAllImages()
        deleteItemsAndCleanAssets(allImages)
        // Also clear all original assets
        val allAssets = database.originalAssetDao().getAll()
        for (asset in allAssets) {
            File(asset.filePath).delete()
            File(asset.thumbnailPath).delete()
            database.originalAssetDao().delete(asset)
        }
        allImages.size
    }

    /**
     * Permanently deletes image items, cleans disk files, and removes paired original assets
     * if no other result images use them.
     */
    suspend fun deleteItemsAndCleanAssets(items: List<ImageItemEntity>) = withContext(Dispatchers.IO) {
        if (items.isEmpty()) return@withContext

        val bksToCheck = items.filter { it.hasOriginal && it.bk.isNotEmpty() }.map { it.bk }.toSet()

        // Delete from database
        database.imageItemDao().deleteAll(items)

        // Delete physical files
        for (item in items) {
            File(item.filePath).delete()
            File(item.thumbnailPath).delete()
        }

        // For paired original assets, check if any other image still uses the same bk
        for (bk in bksToCheck) {
            val remainingUsingBk = database.imageItemDao().countResultsUsingBk(bk)
            if (remainingUsingBk == 0) {
                val asset = database.originalAssetDao().getByBk(bk)
                if (asset != null) {
                    File(asset.filePath).delete()
                    File(asset.thumbnailPath).delete()
                    database.originalAssetDao().delete(asset)
                }
            }
        }
    }
}

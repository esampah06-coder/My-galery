package com.example.ui.viewer

import android.content.res.Configuration
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.DriveFileMove
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.RemoveRedEye
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.datastore.AppSettings
import com.example.data.entity.CategoryEntity
import com.example.data.entity.ImageItemEntity
import com.example.data.entity.OriginalAssetEntity
import com.example.ui.theme.AccentPink
import com.example.ui.theme.AccentPurple
import com.example.ui.theme.AccentTeal
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.DeleteRed
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.AppTab
import com.example.util.VibrationHelper
import kotlinx.coroutines.launch
import java.io.File
import kotlin.math.abs
import kotlin.math.roundToInt

@Composable
fun FullScreenViewer(
    activeImage: ImageItemEntity,
    pairedOriginalAsset: OriginalAssetEntity?,
    isViewingOriginal: Boolean,
    displayedImages: List<ImageItemEntity>,
    activeTab: AppTab,
    allCategories: List<CategoryEntity>,
    settings: AppSettings,
    onClose: () -> Unit,
    onNavigateNext: () -> Boolean,
    onNavigatePrevious: () -> Boolean,
    onJumpToIndex: (ImageItemEntity) -> Unit,
    onToggleFavorite: () -> Unit,
    onTrash: () -> Unit,
    onRestore: () -> Unit,
    onDeletePermanent: () -> Unit,
    onToggleViewingOriginal: () -> Unit,
    onSetViewingOriginal: (Boolean) -> Unit,
    onMoveToCategory: (Long) -> Unit,
    onDownloadSingle: (File, String) -> Unit,
    onSaveButtonPositions: (String, Boolean) -> Unit, // json, isLandscape
    onUpdateSwipeDownMode: (String) -> Unit,
    onUpdateNavMode: (String) -> Unit,
    onUpdateShowThumbnails: (Boolean) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val configuration = LocalConfiguration.current
    val isLandscape = configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

    BackHandler {
        if (isViewingOriginal) {
            onSetViewingOriginal(false)
        } else {
            onClose()
        }
    }

    // UI overlays visibility (toggle on 1/3 top tap)
    var showChrome by remember { mutableStateOf(true) }
    var showMoreMenu by remember { mutableStateOf(false) }
    var showMoveCategoryDialog by remember { mutableStateOf(false) }
    var showButtonEditor by remember { mutableStateOf(false) }
    var showConfirmTrashDialog by remember { mutableStateOf(false) }

    // Flash arrow indicator for tap navigation
    var flashArrowDirection by remember { mutableStateOf<String?>(null) } // "LEFT" or "RIGHT"

    // Zoom and pan state
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    // Swipe drag state
    var dragOffsetX by remember { mutableFloatStateOf(0f) }
    var dragOffsetY by remember { mutableFloatStateOf(0f) }
    val animatedOffsetX = remember { Animatable(0f) }
    val animatedOffsetY = remember { Animatable(0f) }

    val activeIndex = displayedImages.indexOfFirst { it.id == activeImage.id }
    val totalCount = displayedImages.size

    // Determine current file to render
    val currentFile = if (isViewingOriginal && pairedOriginalAsset != null) {
        File(pairedOriginalAsset.filePath)
    } else {
        File(activeImage.filePath)
    }

    // Parse button positions
    val positionJson = if (isLandscape) settings.buttonPositionsLandscape else settings.buttonPositionsPortrait
    val buttonPositions = remember(positionJson) { parsePositions(positionJson) }

    // Center badge feedback text during drag
    val dragFeedback = remember(dragOffsetX, dragOffsetY, isViewingOriginal, activeTab, settings.navMode) {
        val distY = dragOffsetY
        val distX = dragOffsetX

        if (settings.navMode == "FAST_SORT") {
            when {
                distX > 60f -> Pair("♥ FAVORIT", AccentPink)
                distX < -60f -> Pair("🗑 SAMPAH", DeleteRed)
                distY < -60f -> Pair("⏭ LEWATI", AccentPurple)
                distY > 60f -> Pair(if (isViewingOriginal) "↩ HASIL" else "👁 ASLI", AccentTeal)
                else -> null
            }
        } else {
            when {
                distY < -60f -> {
                    when {
                        isViewingOriginal -> Pair("↩ HASIL", AccentTeal)
                        activeTab == AppTab.FAVORIT -> Pair("↩ KELUARKAN", AccentPink)
                        activeTab == AppTab.TRASH -> Pair("↩ PULIHKAN", AccentTeal)
                        activeImage.isOriginal -> null
                        else -> Pair("♥ FAVORIT", AccentPink)
                    }
                }
                distY > 60f -> {
                    when {
                        activeTab == AppTab.TRASH -> Pair("⌫ HAPUS PERMANEN", DeleteRed)
                        settings.swipeDownMode == "ORIGINAL_FIRST" && !isViewingOriginal && activeImage.hasOriginal -> {
                            Pair("👁 ASLI", AccentTeal)
                        }
                        settings.swipeDownMode == "SHORT_LONG" && distY < 240f && !isViewingOriginal && activeImage.hasOriginal -> {
                            Pair("👁 ASLI", AccentTeal)
                        }
                        else -> Pair("🗑 SAMPAH", DeleteRed)
                    }
                }
                else -> null
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .onKeyEvent { event ->
                when (event.key) {
                    Key.DirectionRight -> { onNavigateNext(); true }
                    Key.DirectionLeft -> { onNavigatePrevious(); true }
                    Key.Escape -> { onClose(); true }
                    Key.L -> { onToggleFavorite(); true }
                    Key.Delete -> { onTrash(); true }
                    else -> false
                }
            }
    ) {
        // Main Image Display with Zoom & Pan & Drag
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        val newScale = (scale * zoom).coerceIn(1f, 5f)
                        scale = newScale
                        if (newScale > 1f) {
                            val maxOffset = (newScale - 1f) * 600f
                            offset = Offset(
                                x = (offset.x + pan.x).coerceIn(-maxOffset, maxOffset),
                                y = (offset.y + pan.y).coerceIn(-maxOffset, maxOffset)
                            )
                        } else {
                            offset = Offset.Zero
                        }
                    }
                }
                .pointerInput(settings.navMode, isViewingOriginal, activeTab) {
                    detectTapGestures(
                        onDoubleTap = {
                            scale = if (scale > 1f) 1f else 2.5f
                            offset = Offset.Zero
                        },
                        onTap = { tapOffset ->
                            if (scale > 1f) {
                                scale = 1f
                                offset = Offset.Zero
                                return@detectTapGestures
                            }
                            val screenH = size.height
                            val screenW = size.width

                            if (tapOffset.y < screenH * 0.33f) {
                                // Tap top 1/3 = Toggle Clean Mode
                                showChrome = !showChrome
                            } else {
                                // Tap bottom 2/3 = Previous / Next
                                if (tapOffset.x < screenW * 0.5f) {
                                    flashArrowDirection = "LEFT"
                                    onNavigatePrevious()
                                } else {
                                    flashArrowDirection = "RIGHT"
                                    onNavigateNext()
                                }
                                coroutineScope.launch {
                                    kotlinx.coroutines.delay(200)
                                    flashArrowDirection = null
                                }
                            }
                        }
                    )
                }
                .pointerInput(settings.navMode, scale, isViewingOriginal, activeTab) {
                    if (scale <= 1f && (settings.navMode == "GESTURE" || settings.navMode == "HYBRID" || settings.navMode == "FAST_SORT")) {
                        detectDragGestures(
                            onDragEnd = {
                                val dx = dragOffsetX
                                val dy = dragOffsetY
                                dragOffsetX = 0f
                                dragOffsetY = 0f

                                coroutineScope.launch {
                                    // Process swipe threshold: >64px
                                    if (settings.navMode == "FAST_SORT") {
                                        when {
                                            dx > 70f -> {
                                                VibrationHelper.vibrateShort(context)
                                                onToggleFavorite()
                                            }
                                            dx < -70f -> {
                                                VibrationHelper.vibrateShort(context)
                                                if (settings.confirmTrash) showConfirmTrashDialog = true else onTrash()
                                            }
                                            dy < -70f -> {
                                                onNavigateNext()
                                            }
                                            dy > 70f -> {
                                                onToggleViewingOriginal()
                                            }
                                        }
                                    } else {
                                        // Standard gesture mode
                                        if (dy < -64f) {
                                            // Swipe Up
                                            VibrationHelper.vibrateShort(context)
                                            if (isViewingOriginal) {
                                                onSetViewingOriginal(false)
                                            } else if (activeTab == AppTab.TRASH) {
                                                onRestore()
                                            } else {
                                                onToggleFavorite()
                                            }
                                        } else if (dy > 64f) {
                                            // Swipe Down
                                            VibrationHelper.vibrateShort(context)
                                            if (activeTab == AppTab.TRASH) {
                                                onDeletePermanent()
                                            } else if (settings.swipeDownMode == "ORIGINAL_FIRST") {
                                                if (!isViewingOriginal && activeImage.hasOriginal) {
                                                    onSetViewingOriginal(true)
                                                } else {
                                                    if (settings.confirmTrash) showConfirmTrashDialog = true else onTrash()
                                                }
                                            } else if (settings.swipeDownMode == "SHORT_LONG") {
                                                if (dy < 240f && !isViewingOriginal && activeImage.hasOriginal) {
                                                    onSetViewingOriginal(true)
                                                } else {
                                                    if (settings.confirmTrash) showConfirmTrashDialog = true else onTrash()
                                                }
                                            } else {
                                                if (settings.confirmTrash) showConfirmTrashDialog = true else onTrash()
                                            }
                                        } else if (settings.horizontalSwipeEnabled && abs(dx) > 70f) {
                                            if (dx > 0) onNavigatePrevious() else onNavigateNext()
                                        }
                                    }
                                }
                            },
                            onDragCancel = {
                                dragOffsetX = 0f
                                dragOffsetY = 0f
                            },
                            onDrag = { change, dragAmount ->
                                change.consume()
                                dragOffsetX += dragAmount.x
                                dragOffsetY += dragAmount.y
                            }
                        )
                    }
                }
        ) {
            val rotationAngle = if (scale == 1f) (dragOffsetX * 0.04f).coerceIn(-10f, 10f) else 0f

            AsyncImage(
                model = ImageRequest.Builder(context)
                    .data(currentFile)
                    .crossfade(true)
                    .build(),
                contentDescription = activeImage.name,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer(
                        scaleX = scale,
                        scaleY = scale,
                        translationX = offset.x + dragOffsetX,
                        translationY = offset.y + dragOffsetY,
                        rotationZ = rotationAngle
                    )
            )

            // Flash arrow on screen tap
            if (flashArrowDirection != null) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 32.dp),
                    contentAlignment = if (flashArrowDirection == "LEFT") Alignment.CenterStart else Alignment.CenterEnd
                ) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.5f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (flashArrowDirection == "LEFT") Icons.AutoMirrored.Filled.ArrowBack else Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }
            }

            // Central gesture action indicator label
            if (dragFeedback != null) {
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color.Black.copy(alpha = 0.75f))
                        .border(2.dp, dragFeedback.second, RoundedCornerShape(16.dp))
                        .padding(horizontal = 24.dp, vertical = 12.dp)
                ) {
                    Text(
                        text = dragFeedback.first,
                        color = dragFeedback.second,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Top Badge "ASLI" when viewing original
            if (isViewingOriginal) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 70.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(AccentTeal)
                        .padding(horizontal = 14.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "ASLI (REFERENSI)",
                        color = Color(0xFF03251D),
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }
        }

        // Top App Bar Chrome
        AnimatedVisibility(
            visible = showChrome,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.TopCenter)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.65f))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, contentDescription = "Tutup", tint = Color.White)
                }

                Text(
                    text = "${activeIndex + 1} / $totalCount",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )

                Box {
                    IconButton(onClick = { showMoreMenu = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "Menu", tint = Color.White)
                    }

                    DropdownMenu(
                        expanded = showMoreMenu,
                        onDismissRequest = { showMoreMenu = false },
                        containerColor = DarkSurface
                    ) {
                        DropdownMenuItem(
                            text = { Text(if (isViewingOriginal) "Kembali ke Hasil" else "Lihat Gambar Asli", color = TextPrimary) },
                            leadingIcon = { Icon(Icons.Default.RemoveRedEye, contentDescription = null, tint = AccentTeal) },
                            onClick = {
                                showMoreMenu = false
                                onToggleViewingOriginal()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Pindahkan ke Kategori Lain", color = TextPrimary) },
                            leadingIcon = { Icon(Icons.Default.DriveFileMove, contentDescription = null, tint = AccentPurple) },
                            onClick = {
                                showMoreMenu = false
                                showMoveCategoryDialog = true
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Unduh Gambar Ini", color = TextPrimary) },
                            leadingIcon = { Icon(Icons.Default.Download, contentDescription = null, tint = AccentPink) },
                            onClick = {
                                showMoreMenu = false
                                onDownloadSingle(currentFile, activeImage.originalName)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text(if (settings.showThumbnails) "Sembunyikan Strip Gambar Mini" else "Tampilkan Strip Gambar Mini", color = TextPrimary) },
                            leadingIcon = { Icon(Icons.Default.PhotoLibrary, contentDescription = null, tint = TextSecondary) },
                            onClick = {
                                showMoreMenu = false
                                onUpdateShowThumbnails(!settings.showThumbnails)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Atur Posisi Tombol Layar", color = TextPrimary) },
                            leadingIcon = { Icon(Icons.Default.Settings, contentDescription = null, tint = AccentPurple) },
                            onClick = {
                                showMoreMenu = false
                                showButtonEditor = true
                            }
                        )
                    }
                }
            }
        }

        // Bottom Chrome with File Name & Thumbnails
        AnimatedVisibility(
            visible = showChrome,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.75f))
                    .padding(bottom = 12.dp)
            ) {
                // 7-Thumbnail Preview Strip
                if (settings.showThumbnails && displayedImages.isNotEmpty()) {
                    val startIndex = (activeIndex - 3).coerceAtLeast(0)
                    val endIndex = (startIndex + 7).coerceAtMost(displayedImages.size)
                    val visibleThumbnails = displayedImages.subList(startIndex, endIndex)

                    LazyRow(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp, horizontal = 12.dp),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        itemsIndexed(visibleThumbnails) { _, thumbItem ->
                            val isCurrent = thumbItem.id == activeImage.id
                            val thumbFile = File(thumbItem.thumbnailPath).takeIf { it.exists() } ?: File(thumbItem.filePath)

                            Box(
                                modifier = Modifier
                                    .padding(horizontal = 4.dp)
                                    .size(width = 44.dp, height = 58.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .border(
                                        width = if (isCurrent) 2.5.dp else 1.dp,
                                        color = if (isCurrent) AccentPurple else Color.Transparent,
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .clickable { onJumpToIndex(thumbItem) }
                            ) {
                                AsyncImage(
                                    model = thumbFile,
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }
                    }
                }

                // File name label
                val subtitleTag = when {
                    isViewingOriginal -> "• Gambar Asli Referensi"
                    activeImage.isOriginal -> "• Gambar Asli"
                    activeImage.promptNo > 0 -> "• Prompt ${activeImage.promptNo}"
                    else -> "• Hasil"
                }

                Text(
                    text = "${if (isViewingOriginal) pairedOriginalAsset?.originalFileName ?: activeImage.name else activeImage.name} $subtitleTag",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 6.dp)
                )

                // On-screen buttons (if Hybrid or Buttons mode)
                if (settings.navMode == "BUTTONS" || settings.navMode == "HYBRID") {
                    ViewerFloatingButtons(
                        activeImage = activeImage,
                        hasOriginal = activeImage.hasOriginal,
                        isViewingOriginal = isViewingOriginal,
                        activeTab = activeTab,
                        buttonSize = settings.buttonSize,
                        transparency = settings.buttonTransparency,
                        onHoldEye = { onSetViewingOriginal(it) },
                        onTapEye = { onToggleViewingOriginal() },
                        onToggleFavorite = onToggleFavorite,
                        onTrash = {
                            if (settings.confirmTrash) showConfirmTrashDialog = true else onTrash()
                        },
                        onRestore = onRestore,
                        onDeletePermanent = onDeletePermanent,
                        onDownload = { onDownloadSingle(currentFile, activeImage.originalName) }
                    )
                }
            }
        }
    }

    // Button position editor overlay
    if (showButtonEditor) {
        ViewerButtonEditor(
            initialPositions = buttonPositions,
            onSavePositions = { newPos ->
                val serialized = serializePositions(newPos)
                onSaveButtonPositions(serialized, isLandscape)
            },
            onReset = {
                onSaveButtonPositions("", isLandscape)
            },
            onClose = { showButtonEditor = false }
        )
    }

    // Move to category dialog
    if (showMoveCategoryDialog) {
        AlertDialog(
            onDismissRequest = { showMoveCategoryDialog = false },
            containerColor = DarkSurface,
            title = { Text("Pindahkan ke Kategori Lain", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    allCategories.forEach { cat ->
                        Text(
                            text = cat.name,
                            color = TextPrimary,
                            fontSize = 15.sp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onMoveToCategory(cat.id)
                                    showMoveCategoryDialog = false
                                }
                                .padding(vertical = 10.dp, horizontal = 8.dp)
                        )
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showMoveCategoryDialog = false }) {
                    Text("Batal", color = TextSecondary)
                }
            }
        )
    }

    // Confirm trash dialog
    if (showConfirmTrashDialog) {
        AlertDialog(
            onDismissRequest = { showConfirmTrashDialog = false },
            containerColor = DarkSurface,
            title = { Text("Pindahkan ke Trash?", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = { Text("Gambar akan dipindahkan ke tab Trash. Anda dapat memulihkannya nanti.", color = TextSecondary) },
            confirmButton = {
                Button(
                    onClick = {
                        showConfirmTrashDialog = false
                        onTrash()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DeleteRed)
                ) {
                    Text("Ya, Buang ke Trash", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmTrashDialog = false }) {
                    Text("Batal", color = TextSecondary)
                }
            }
        )
    }
}

@Composable
fun ViewerFloatingButtons(
    activeImage: ImageItemEntity,
    hasOriginal: Boolean,
    isViewingOriginal: Boolean,
    activeTab: AppTab,
    buttonSize: String,
    transparency: Float,
    onHoldEye: (Boolean) -> Unit,
    onTapEye: () -> Unit,
    onToggleFavorite: () -> Unit,
    onTrash: () -> Unit,
    onRestore: () -> Unit,
    onDeletePermanent: () -> Unit,
    onDownload: () -> Unit
) {
    val buttonDimension = when (buttonSize) {
        "SMALL" -> 44.dp
        "LARGE" -> 60.dp
        else -> 52.dp
    }
    val iconDimension = when (buttonSize) {
        "SMALL" -> 22.dp
        "LARGE" -> 30.dp
        else -> 26.dp
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Eye button: Hold to peek, short tap to toggle
        val eyeInteractionSource = remember { MutableInteractionSource() }
        val isPressed by eyeInteractionSource.collectIsPressedAsState()
        LaunchedEffect(isPressed) {
            if (hasOriginal) {
                onHoldEye(isPressed)
            }
        }

        Box(
            modifier = Modifier
                .size(buttonDimension)
                .clip(CircleShape)
                .background(DarkSurfaceVariant.copy(alpha = transparency))
                .clickable(
                    enabled = hasOriginal,
                    interactionSource = eyeInteractionSource,
                    indication = null,
                    onClick = onTapEye
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.RemoveRedEye,
                contentDescription = "Lihat Asli",
                tint = if (hasOriginal) AccentTeal else TextSecondary.copy(alpha = 0.4f),
                modifier = Modifier.size(iconDimension)
            )
        }

        // Favorite Button (unless in Trash or Original)
        if (activeTab != AppTab.TRASH && !activeImage.isOriginal) {
            Box(
                modifier = Modifier
                    .size(buttonDimension)
                    .clip(CircleShape)
                    .background(DarkSurfaceVariant.copy(alpha = transparency))
                    .clickable(onClick = onToggleFavorite),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (activeImage.favorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                    contentDescription = "Favorit",
                    tint = if (activeImage.favorite) AccentPink else Color.White,
                    modifier = Modifier.size(iconDimension)
                )
            }
        }

        // Trash / Restore Button
        if (activeTab == AppTab.TRASH) {
            Box(
                modifier = Modifier
                    .size(buttonDimension)
                    .clip(CircleShape)
                    .background(DarkSurfaceVariant.copy(alpha = transparency))
                    .clickable(onClick = onRestore),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Restore,
                    contentDescription = "Pulihkan",
                    tint = AccentTeal,
                    modifier = Modifier.size(iconDimension)
                )
            }
            Box(
                modifier = Modifier
                    .size(buttonDimension)
                    .clip(CircleShape)
                    .background(DeleteRed.copy(alpha = transparency))
                    .clickable(onClick = onDeletePermanent),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.DeleteForever,
                    contentDescription = "Hapus Permanen",
                    tint = Color.White,
                    modifier = Modifier.size(iconDimension)
                )
            }
        } else {
            Box(
                modifier = Modifier
                    .size(buttonDimension)
                    .clip(CircleShape)
                    .background(DarkSurfaceVariant.copy(alpha = transparency))
                    .clickable(onClick = onTrash),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Trash",
                    tint = DeleteRed,
                    modifier = Modifier.size(iconDimension)
                )
            }
        }

        // Download Button
        Box(
            modifier = Modifier
                .size(buttonDimension)
                .clip(CircleShape)
                .background(DarkSurfaceVariant.copy(alpha = transparency))
                .clickable(onClick = onDownload),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Download,
                contentDescription = "Unduh",
                tint = Color.White,
                modifier = Modifier.size(iconDimension)
            )
        }
    }
}

package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val GaleriSortirColorScheme = darkColorScheme(
    primary = AccentPurple,
    onPrimary = Color.White,
    primaryContainer = AccentPurple.copy(alpha = 0.25f),
    onPrimaryContainer = AccentPurpleLight,
    secondary = AccentTeal,
    onSecondary = Color(0xFF03251D),
    secondaryContainer = AccentTeal.copy(alpha = 0.2f),
    onSecondaryContainer = AccentTeal,
    tertiary = AccentPink,
    onTertiary = Color.White,
    background = DarkBackground,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    error = DeleteRed,
    onError = Color.White
)

val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(24.dp)
)

@Composable
fun GaleriSortirTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = GaleriSortirColorScheme,
        typography = Typography,
        shapes = AppShapes,
        content = content
    )
}

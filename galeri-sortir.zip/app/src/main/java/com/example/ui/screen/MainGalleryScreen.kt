package com.example.ui.screen

import android.content.res.Configuration
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.DriveFileMove
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.LinkOff
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Photo
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.CategoryEntity
import com.example.data.entity.ImageItemEntity
import com.example.manager.ImportClassificationType
import com.example.manager.ImportManager
import com.example.manager.ImportSummary
import com.example.ui.components.CategorySelectionDialog
import com.example.ui.components.CleanBottomSheet
import com.example.ui.components.ExportBottomSheet
import com.example.ui.components.ImageCard
import com.example.ui.components.ImportProgressDialog
import com.example.ui.components.ImportSourceDialog
import com.example.ui.components.ImportSummaryDialog
import com.example.ui.components.LinkImportBottomSheet
import com.example.ui.components.MainMenuSheet
import com.example.ui.components.SortBottomSheet
import com.example.ui.components.StorageOverviewDialog
import com.example.ui.theme.AccentPink
import com.example.ui.theme.AccentPurple
import com.example.ui.theme.AccentTeal
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.DeleteRed
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.AppTab
import com.example.ui.viewmodel.GalleryViewModel
import com.example.ui.viewmodel.StorageOverview
import com.example.ui.viewer.FullScreenViewer
import kotlinx.coroutines.launch
import java.io.InputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainGalleryScreen(viewModel: GalleryViewModel) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val configuration = LocalConfiguration.current
    val isLandscape = configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

    val settings by viewModel.settings.collectAsState()
    val activeCategory by viewModel.activeCategory.collectAsState()
    val allCategories by viewModel.allCategories.collectAsState()
    val selectedTab by viewModel.selectedTab.collectAsState()
    val displayedImages by viewModel.displayedImages.collectAsState()
    val tabBadges by viewModel.tabBadges.collectAsState()
    val isSelectionMode by viewModel.isSelectionMode.collectAsState()
    val selectedImageIds by viewModel.selectedImageIds.collectAsState()
    val undoAction by viewModel.undoAction.collectAsState()
    val toastMessage by viewModel.toastMessage.collectAsState()

    // Fullscreen viewer state
    val viewerActiveImage by viewModel.viewerActiveImage.collectAsState()
    val viewerOriginalAsset by viewModel.viewerOriginalAsset.collectAsState()
    val isViewingOriginal by viewModel.isViewingOriginal.collectAsState()

    // Import manager progress
    val importProgress by viewModel.importManager.progress.collectAsState()
    var importSummaryResult by remember { mutableStateOf<ImportSummary?>(null) }

    // Dialog & Sheet States
    var showCategoryDialog by remember { mutableStateOf(false) }
    var showSortSheet by remember { mutableStateOf(false) }
    var showImportSourceDialog by remember { mutableStateOf(false) }
    var showLinkImportSheet by remember { mutableStateOf(false) }
    var showExportSheet by remember { mutableStateOf(false) }
    var showCleanSheet by remember { mutableStateOf(false) }
    var showMainMenuSheet by remember { mutableStateOf(false) }
    var showStorageOverviewDialog by remember { mutableStateOf<StorageOverview?>(null) }
    var showTabOptionsPopup by remember { mutableStateOf(false) }
    var showSelectCountDialog by remember { mutableStateOf(false) }
    var showBatchMoveCategoryDialog by remember { mutableStateOf(false) }

    // Pending import classification type
    var pendingImportType by remember { mutableStateOf(ImportClassificationType.AUTO_MIX) }

    val gridState = rememberLazyGridState()

    // SAF Document Picker for files / zips
    val selectFilesLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            coroutineScope.launch {
                val entries = mutableListOf<ImportManager.RawEntry>()
                for (uri in uris) {
                    val fileName = resolveUriFileName(context, uri)
                    val ext = fileName.substringAfterLast('.').lowercase()
                    if (ext == "zip") {
                        val input = context.contentResolver.openInputStream(uri)
                        if (input != null) {
                            val zipEntries = viewModel.importManager.parseZipEntries(
                                zipInputStream = input,
                                zipName = fileName,
                                zipTime = System.currentTimeMillis()
                            )
                            entries.addAll(zipEntries)
                        }
                    } else if (ext in listOf("png", "jpg", "jpeg", "webp")) {
                        entries.add(
                            ImportManager.RawEntry(
                                originalFileName = fileName,
                                size = resolveUriFileSize(context, uri),
                                modifiedTime = System.currentTimeMillis(),
                                zipName = "",
                                zipTime = 0L,
                                openStream = { context.contentResolver.openInputStream(uri) ?: InputStream.nullInputStream() }
                            )
                        )
                    }
                }
                if (entries.isNotEmpty()) {
                    val summary = viewModel.importManager.importEntries(
                        entries = entries,
                        categoryId = activeCategory.id,
                        type = pendingImportType,
                        treatPromptAsResult = settings.importTreatPromptAsResult,
                        matchTruncatedNames = settings.importMatchTruncatedNames
                    )
                    importSummaryResult = summary
                }
            }
        }
    }

    // SAF Folder Picker
    val selectFolderLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { treeUri: Uri? ->
        if (treeUri != null) {
            coroutineScope.launch {
                try {
                    val treeDocId = android.provider.DocumentsContract.getTreeDocumentId(treeUri)
                    val childrenUri = android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, treeDocId)
                    val cursor = context.contentResolver.query(
                        childrenUri,
                        arrayOf(
                            android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                            android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                            android.provider.DocumentsContract.Document.COLUMN_SIZE,
                            android.provider.DocumentsContract.Document.COLUMN_LAST_MODIFIED
                        ),
                        null, null, null
                    )

                    val entries = mutableListOf<ImportManager.RawEntry>()
                    cursor?.use { c ->
                        val idIdx = c.getColumnIndex(android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID)
                        val nameIdx = c.getColumnIndex(android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME)
                        val sizeIdx = c.getColumnIndex(android.provider.DocumentsContract.Document.COLUMN_SIZE)
                        val modIdx = c.getColumnIndex(android.provider.DocumentsContract.Document.COLUMN_LAST_MODIFIED)

                        while (c.moveToNext()) {
                            val docId = if (idIdx >= 0) c.getString(idIdx) else continue
                            val name = if (nameIdx >= 0) c.getString(nameIdx) else continue
                            val size = if (sizeIdx >= 0) c.getLong(sizeIdx) else 0L
                            val mod = if (modIdx >= 0) c.getLong(modIdx) else 0L
                            val fileUri = android.provider.DocumentsContract.buildDocumentUriUsingTree(treeUri, docId)
                            val ext = name.substringAfterLast('.').lowercase()

                            if (ext in listOf("png", "jpg", "jpeg", "webp")) {
                                entries.add(
                                    ImportManager.RawEntry(
                                        originalFileName = name,
                                        size = size,
                                        modifiedTime = mod,
                                        zipName = "",
                                        zipTime = 0L,
                                        openStream = { context.contentResolver.openInputStream(fileUri) ?: InputStream.nullInputStream() }
                                    )
                                )
                            } else if (ext == "zip") {
                                val input = context.contentResolver.openInputStream(fileUri)
                                if (input != null) {
                                    val zipEntries = viewModel.importManager.parseZipEntries(
                                        zipInputStream = input,
                                        zipName = name,
                                        zipTime = mod
                                    )
                                    entries.addAll(zipEntries)
                                }
                            }
                        }
                    }

                    if (entries.isNotEmpty()) {
                        val summary = viewModel.importManager.importEntries(
                            entries = entries,
                            categoryId = activeCategory.id,
                            type = pendingImportType,
                            treatPromptAsResult = settings.importTreatPromptAsResult,
                            matchTruncatedNames = settings.importMatchTruncatedNames
                        )
                        importSummaryResult = summary
                    }
                } catch (e: Exception) {
                    viewModel.showToast("Gagal membaca folder: ${e.message}")
                }
            }
        }
    }

    // SAF JSON Backup Restore picker
    val restoreJsonLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch {
                val stream = context.contentResolver.openInputStream(uri)
                if (stream != null) {
                    val result = viewModel.backupManager.restoreBackupJson(stream)
                    if (result.isSuccess) {
                        viewModel.showToast("${result.getOrNull()} catatan dipulihkan dari cadangan")
                    } else {
                        viewModel.showToast("Gagal memulihkan cadangan: ${result.exceptionOrNull()?.message}")
                    }
                }
            }
        }
    }

    Scaffold(
        containerColor = DarkBackground,
        topBar = {
            TopAppBarGaleri(
                categoryName = activeCategory.name,
                tabTitle = selectedTab.title,
                totalCount = tabBadges[selectedTab]?.total ?: 0,
                unseenCount = tabBadges[selectedTab]?.unseen ?: 0,
                sortMode = settings.sortMode,
                onCategoryClick = { showCategoryDialog = true },
                onExportClick = { showExportSheet = true },
                onCleanClick = { showCleanSheet = true },
                onSortClick = { showSortSheet = true },
                onColumnsClick = {
                    val nextCols = when (settings.gridColumns) {
                        2 -> 3
                        3 -> 4
                        else -> 2
                    }
                    coroutineScope.launch { viewModel.settingsDataStore.updateGridColumns(nextCols) }
                },
                onImportClick = { showImportSourceDialog = true },
                onMenuClick = { showMainMenuSheet = true }
            )
        },
        bottomBar = {
            if (!isLandscape) {
                if (isSelectionMode) {
                    SelectionActionBar(
                        selectedCount = selectedImageIds.size,
                        isTrashTab = selectedTab == AppTab.TRASH,
                        onMoveClick = { showBatchMoveCategoryDialog = true },
                        onTrashClick = { viewModel.batchMoveToTrash() },
                        onRestoreClick = { viewModel.batchRestoreFromTrash() },
                        onDeletePermanentClick = { viewModel.batchDeletePermanently() },
                        onZipClick = { showExportSheet = true },
                        onMarkSeenClick = { viewModel.batchMarkSeen(true) },
                        onSelectCountClick = { showSelectCountDialog = true },
                        onSelectAllClick = { viewModel.selectAllDisplayed() },
                        onCloseSelection = { viewModel.clearSelection() }
                    )
                } else {
                    GalleryBottomBar(
                        selectedTab = selectedTab,
                        badges = tabBadges,
                        onTabClick = { tab ->
                            if (tab == selectedTab) {
                                showTabOptionsPopup = true
                            } else {
                                viewModel.selectTab(tab)
                            }
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Navigation Rail for Landscape/Tablet
            if (isLandscape) {
                GalleryNavRail(
                    selectedTab = selectedTab,
                    badges = tabBadges,
                    onTabClick = { tab ->
                        if (tab == selectedTab) {
                            showTabOptionsPopup = true
                        } else {
                            viewModel.selectTab(tab)
                        }
                    }
                )
            }

            Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                val effectiveCols = if (isLandscape) (settings.gridColumns * 2).coerceAtMost(6) else settings.gridColumns

                if (displayedImages.isEmpty()) {
                    // Contextual Empty State
                    EmptyStateView(
                        tab = selectedTab,
                        categoryName = activeCategory.name,
                        onImportClick = { showImportSourceDialog = true },
                        onSwitchToLepas = { viewModel.selectTab(AppTab.LEPAS) }
                    )
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(effectiveCols),
                        state = gridState,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(displayedImages, key = { it.id }) { item ->
                            val isSeen = viewModel.isSeenInTab(item, selectedTab)
                            val isSelected = selectedImageIds.contains(item.id)

                            ImageCard(
                                item = item,
                                isSeen = isSeen,
                                isSelected = isSelected,
                                isSelectionMode = isSelectionMode,
                                onCardClick = {
                                    if (isSelectionMode) {
                                        viewModel.toggleSelection(item)
                                    } else {
                                        viewModel.openViewer(item)
                                    }
                                },
                                onCardLongClick = {
                                    viewModel.enterSelectionMode(item)
                                },
                                onToggleFavorite = {
                                    viewModel.toggleFavorite(item)
                                }
                            )
                        }
                    }
                }

                // Selection Action Bar in Landscape
                if (isLandscape && isSelectionMode) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomCenter)
                    ) {
                        SelectionActionBar(
                            selectedCount = selectedImageIds.size,
                            isTrashTab = selectedTab == AppTab.TRASH,
                            onMoveClick = { showBatchMoveCategoryDialog = true },
                            onTrashClick = { viewModel.batchMoveToTrash() },
                            onRestoreClick = { viewModel.batchRestoreFromTrash() },
                            onDeletePermanentClick = { viewModel.batchDeletePermanently() },
                            onZipClick = { showExportSheet = true },
                            onMarkSeenClick = { viewModel.batchMarkSeen(true) },
                            onSelectCountClick = { showSelectCountDialog = true },
                            onSelectAllClick = { viewModel.selectAllDisplayed() },
                            onCloseSelection = { viewModel.clearSelection() }
                        )
                    }
                }

                // Floating Undo Bar
                if (undoAction != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomCenter)
                            .padding(bottom = if (isSelectionMode || isLandscape) 70.dp else 16.dp)
                            .padding(horizontal = 16.dp)
                    ) {
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = undoAction!!.title,
                                    color = TextPrimary,
                                    fontSize = 13.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                TextButton(
                                    onClick = { viewModel.executeUndo() },
                                    colors = ButtonDefaults.textButtonColors(contentColor = AccentTeal)
                                ) {
                                    Text("URUNGKAN", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                                IconButton(
                                    onClick = { viewModel.dismissUndo() },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = "Tutup", tint = TextSecondary, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Fullscreen Image Viewer
    if (viewerActiveImage != null) {
        FullScreenViewer(
            activeImage = viewerActiveImage!!,
            pairedOriginalAsset = viewerOriginalAsset,
            isViewingOriginal = isViewingOriginal,
            displayedImages = displayedImages,
            activeTab = selectedTab,
            allCategories = allCategories,
            settings = settings,
            onClose = { viewModel.closeViewer() },
            onNavigateNext = { viewModel.navigateViewerNext() },
            onNavigatePrevious = { viewModel.navigateViewerPrevious() },
            onJumpToIndex = { viewModel.openViewer(it) },
            onToggleFavorite = { viewModel.onViewerActionFavorite() },
            onTrash = { viewModel.onViewerActionTrash() },
            onRestore = { viewModel.onViewerActionRestore() },
            onDeletePermanent = { viewModel.onViewerActionDeletePermanent() },
            onToggleViewingOriginal = { viewModel.toggleViewingOriginal() },
            onSetViewingOriginal = { viewModel.setViewingOriginalState(it) },
            onMoveToCategory = { targetCatId ->
                viewModel.moveToCategory(viewerActiveImage!!.id, targetCatId)
                viewModel.closeViewer()
            },
            onDownloadSingle = { file, name ->
                coroutineScope.launch {
                    val res = viewModel.exportManager.saveSingleImageToDownloads(file, name)
                    if (res.isSuccess) {
                        viewModel.showToast("✓ $name disimpan di folder Download")
                    } else {
                        viewModel.showToast("Gagal mengunduh: ${res.exceptionOrNull()?.message}")
                    }
                }
            },
            onSaveButtonPositions = { posJson, isLand ->
                coroutineScope.launch {
                    if (isLand) {
                        viewModel.settingsDataStore.updateButtonPositionsLandscape(posJson)
                    } else {
                        viewModel.settingsDataStore.updateButtonPositionsPortrait(posJson)
                    }
                }
            },
            onUpdateSwipeDownMode = { mode ->
                coroutineScope.launch { viewModel.settingsDataStore.updateSwipeDownMode(mode) }
            },
            onUpdateNavMode = { mode ->
                coroutineScope.launch { viewModel.settingsDataStore.updateNavMode(mode) }
            },
            onUpdateShowThumbnails = { show ->
                coroutineScope.launch { viewModel.settingsDataStore.updateShowThumbnails(show) }
            }
        )
    }

    // Category Selection Dialog
    if (showCategoryDialog) {
        val catCounts = remember(displayedImages, allCategories) {
            allCategories.associate { cat ->
                cat.id to 0 // will be computed in repo or viewmodel
            }
        }
        CategorySelectionDialog(
            categories = allCategories,
            activeCategory = activeCategory,
            categoryCounts = catCounts,
            onSelect = { viewModel.selectCategory(it) },
            onCreateCategory = { viewModel.createCategory(it) },
            onRenameCategory = { cat, newName -> viewModel.renameCategory(cat, newName) },
            onDeleteCategory = { viewModel.deleteCategory(it) },
            onDismiss = { showCategoryDialog = false }
        )
    }

    // Sort & Display Bottom Sheet
    if (showSortSheet) {
        SortBottomSheet(
            settings = settings,
            onUpdateSortMode = { mode ->
                coroutineScope.launch { viewModel.settingsDataStore.updateSortMode(mode) }
            },
            onUpdateSeenAtBottom = { enabled ->
                coroutineScope.launch { viewModel.settingsDataStore.updateSeenAtBottom(enabled) }
            },
            onUpdateShowLepasInGallery = { enabled ->
                coroutineScope.launch { viewModel.settingsDataStore.updateShowLepasInGallery(enabled) }
            },
            onUpdateShowOrphanOriginalInGallery = { enabled ->
                coroutineScope.launch { viewModel.settingsDataStore.updateShowOrphanOriginalInGallery(enabled) }
            },
            onUpdateNavMode = { mode ->
                coroutineScope.launch { viewModel.settingsDataStore.updateNavMode(mode) }
            },
            onUpdateSwipeDownMode = { mode ->
                coroutineScope.launch { viewModel.settingsDataStore.updateSwipeDownMode(mode) }
            },
            onDismiss = { showSortSheet = false }
        )
    }

    // Import Source Picker Dialog
    if (showImportSourceDialog) {
        ImportSourceDialog(
            settings = settings,
            onSelectFiles = { type ->
                pendingImportType = type
                selectFilesLauncher.launch(arrayOf("image/*", "application/zip", "*/*"))
            },
            onSelectFolder = { type ->
                pendingImportType = type
                selectFolderLauncher.launch(null)
            },
            onOpenLinkImport = { type ->
                pendingImportType = type
                showLinkImportSheet = true
            },
            onUpdateTreatPromptAsResult = { enabled ->
                coroutineScope.launch { viewModel.settingsDataStore.updateImportTreatPromptAsResult(enabled) }
            },
            onUpdateMatchTruncatedNames = { enabled ->
                coroutineScope.launch { viewModel.settingsDataStore.updateImportMatchTruncatedNames(enabled) }
            },
            onDismiss = { showImportSourceDialog = false }
        )
    }

    // Link (URL) Import Sheet
    if (showLinkImportSheet) {
        LinkImportBottomSheet(
            type = pendingImportType,
            driveApiKey = settings.googleDriveApiKey,
            onStartImport = { urls ->
                coroutineScope.launch {
                    val summary = viewModel.importManager.downloadAndImportUrls(
                        urls = urls,
                        categoryId = activeCategory.id,
                        type = pendingImportType,
                        treatPromptAsResult = settings.importTreatPromptAsResult,
                        matchTruncatedNames = settings.importMatchTruncatedNames,
                        googleDriveApiKey = settings.googleDriveApiKey
                    )
                    importSummaryResult = summary
                }
            },
            onDismiss = { showLinkImportSheet = false }
        )
    }

    // Import Progress Dialog
    ImportProgressDialog(progress = importProgress)

    // Import Summary Dialog
    if (importSummaryResult != null) {
        ImportSummaryDialog(
            summary = importSummaryResult!!,
            onDismiss = { importSummaryResult = null }
        )
    }

    // Export Bottom Sheet
    if (showExportSheet) {
        val itemsToExport = if (isSelectionMode && selectedImageIds.isNotEmpty()) {
            displayedImages.filter { selectedImageIds.contains(it.id) }
        } else {
            displayedImages
        }

        ExportBottomSheet(
            exportManager = viewModel.exportManager,
            itemsToExport = itemsToExport,
            activeCategory = activeCategory,
            allCategories = allCategories,
            currentTabName = selectedTab.title,
            isSelectionScope = isSelectionMode,
            onPurgeExportedItems = { purgedItems ->
                coroutineScope.launch {
                    viewModel.cleanManager.deleteItemsAndCleanAssets(purgedItems)
                    viewModel.clearSelection()
                    viewModel.showToast("${purgedItems.size} gambar disingkirkan dari galeri")
                }
            },
            onDismiss = { showExportSheet = false }
        )
    }

    // Clean Bottom Sheet
    if (showCleanSheet) {
        val trashCount = tabBadges[AppTab.TRASH]?.total ?: 0
        val lepasCount = tabBadges[AppTab.LEPAS]?.total ?: 0

        CleanBottomSheet(
            activeCategory = activeCategory,
            trashCount = trashCount,
            lepasCount = lepasCount,
            isImportRunning = viewModel.importManager.isImportRunning(),
            onEmptyTrash = {
                coroutineScope.launch {
                    val count = viewModel.cleanManager.emptyTrash(activeCategory.id)
                    viewModel.showToast("$count gambar di Trash dibersihkan")
                }
            },
            onClearLepas = {
                coroutineScope.launch {
                    val count = viewModel.cleanManager.clearLepas(activeCategory.id)
                    viewModel.showToast("$count gambar di tab Lepas dibersihkan")
                }
            },
            onClearLatestBatch = {
                coroutineScope.launch {
                    val (count, _) = viewModel.cleanManager.clearLatestBatch()
                    viewModel.showToast("$count gambar batch terakhir dibersihkan (favorit aman)")
                }
            },
            onClearAllCategories = {
                coroutineScope.launch {
                    val count = viewModel.cleanManager.clearAllCategories()
                    viewModel.showToast("Reset total berhasil ($count gambar dihapus)")
                }
            },
            onDismiss = { showCleanSheet = false }
        )
    }

    // Main Menu Sheet
    if (showMainMenuSheet) {
        MainMenuSheet(
            onOpenSort = { showSortSheet = true },
            onCycleColumns = {
                val nextCols = when (settings.gridColumns) {
                    2 -> 3
                    3 -> 4
                    else -> 2
                }
                coroutineScope.launch { viewModel.settingsDataStore.updateGridColumns(nextCols) }
            },
            onOpenLinkImport = { showLinkImportSheet = true },
            onOpenZipExport = { showExportSheet = true },
            onOpenClean = { showCleanSheet = true },
            onShowStorageOverview = {
                coroutineScope.launch {
                    val stats = viewModel.getStorageOverview()
                    showStorageOverviewDialog = stats
                }
            },
            onExportBackupJson = {
                coroutineScope.launch {
                    val res = viewModel.backupManager.exportBackupJson()
                    if (res.isSuccess) {
                        viewModel.showToast("✓ Cadangan disimpan: ${res.getOrNull()} di Download")
                    } else {
                        viewModel.showToast("Gagal menyimpan cadangan: ${res.exceptionOrNull()?.message}")
                    }
                }
            },
            onRestoreBackupJson = {
                restoreJsonLauncher.launch(arrayOf("application/json", "text/*", "*/*"))
            },
            onDismiss = { showMainMenuSheet = false }
        )
    }

    // Storage Overview Dialog
    if (showStorageOverviewDialog != null) {
        StorageOverviewDialog(
            overview = showStorageOverviewDialog!!,
            onDismiss = { showStorageOverviewDialog = null }
        )
    }

    // Tab Options Popup (when tapping active tab)
    if (showTabOptionsPopup) {
        TabOptionsDialog(
            currentTab = selectedTab,
            settings = settings,
            onUpdateShowLepas = { coroutineScope.launch { viewModel.settingsDataStore.updateShowLepasInGallery(it) } },
            onUpdateShowOrphan = { coroutineScope.launch { viewModel.settingsDataStore.updateShowOrphanOriginalInGallery(it) } },
            onUpdateLepasFilter = { coroutineScope.launch { viewModel.settingsDataStore.updateLepasFilter(it) } },
            onFilterSeen = { viewModel.setFilterSeenStatus(it) },
            onOpenSelectCount = { showSelectCountDialog = true },
            onScrollToTop = {
                coroutineScope.launch { gridState.animateScrollToItem(0) }
            },
            onDismiss = { showTabOptionsPopup = false }
        )
    }

    // Multi-Select specific count dialog
    if (showSelectCountDialog) {
        SelectCountDialog(
            defaultCount = settings.multiSelectCount,
            onSelect = { count, fromStart ->
                coroutineScope.launch { viewModel.settingsDataStore.updateMultiSelectCount(count) }
                viewModel.selectSpecificCount(count, fromStart)
            },
            onDismiss = { showSelectCountDialog = false }
        )
    }

    // Move to category dialog for selection mode
    if (showBatchMoveCategoryDialog) {
        AlertDialog(
            onDismissRequest = { showBatchMoveCategoryDialog = false },
            containerColor = DarkSurface,
            title = { Text("Pindahkan ${selectedImageIds.size} Gambar", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    allCategories.forEach { cat ->
                        Text(
                            text = cat.name,
                            color = TextPrimary,
                            fontSize = 15.sp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    viewModel.batchMoveToCategory(cat.id)
                                    showBatchMoveCategoryDialog = false
                                }
                                .padding(vertical = 10.dp, horizontal = 8.dp)
                        )
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showBatchMoveCategoryDialog = false }) {
                    Text("Batal", color = TextSecondary)
                }
            }
        )
    }

    // Toast message banner
    if (toastMessage != null) {
        LaunchedEffect(toastMessage) {
            kotlinx.coroutines.delay(2500)
            viewModel.clearToast()
        }
    }
}

private fun resolveUriFileName(context: android.content.Context, uri: Uri): String {
    var name = "file_${System.currentTimeMillis()}"
    val cursor = context.contentResolver.query(uri, null, null, null, null)
    cursor?.use {
        if (it.moveToFirst()) {
            val idx = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (idx >= 0) name = it.getString(idx)
        }
    }
    return name
}

private fun resolveUriFileSize(context: android.content.Context, uri: Uri): Long {
    var size = 0L
    val cursor = context.contentResolver.query(uri, null, null, null, null)
    cursor?.use {
        if (it.moveToFirst()) {
            val idx = it.getColumnIndex(android.provider.OpenableColumns.SIZE)
            if (idx >= 0) size = it.getLong(idx)
        }
    }
    return size
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopAppBarGaleri(
    categoryName: String,
    tabTitle: String,
    totalCount: Int,
    unseenCount: Int,
    sortMode: String,
    onCategoryClick: () -> Unit,
    onExportClick: () -> Unit,
    onCleanClick: () -> Unit,
    onSortClick: () -> Unit,
    onColumnsClick: () -> Unit,
    onImportClick: () -> Unit,
    onMenuClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSurface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Category Dropdown trigger
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable(onClick = onCategoryClick)
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Galeri Sortir",
                            color = TextPrimary,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Icon(
                            imageVector = Icons.Default.ArrowDropDown,
                            contentDescription = "Pilih kategori",
                            tint = AccentPurple
                        )
                    }
                    Text(
                        text = "$categoryName • $tabTitle: $totalCount gambar (${unseenCount} baru)",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Action Buttons
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onExportClick, modifier = Modifier.size(34.dp)) {
                    Icon(Icons.Default.Download, contentDescription = "Ekspor ZIP", tint = AccentTeal, modifier = Modifier.size(20.dp))
                }
                IconButton(onClick = onCleanClick, modifier = Modifier.size(34.dp)) {
                    Icon(Icons.Default.DeleteSweep, contentDescription = "Bersihkan", tint = DeleteRed, modifier = Modifier.size(20.dp))
                }
                IconButton(onClick = onSortClick, modifier = Modifier.size(34.dp)) {
                    Icon(Icons.Default.Sort, contentDescription = "Urutan", tint = TextPrimary, modifier = Modifier.size(20.dp))
                }
                IconButton(onClick = onColumnsClick, modifier = Modifier.size(34.dp)) {
                    Icon(Icons.Default.GridView, contentDescription = "Kolom", tint = TextPrimary, modifier = Modifier.size(20.dp))
                }
                IconButton(onClick = onImportClick, modifier = Modifier.size(34.dp)) {
                    Icon(Icons.Default.Add, contentDescription = "Impor", tint = AccentPurple, modifier = Modifier.size(22.dp))
                }
                IconButton(onClick = onMenuClick, modifier = Modifier.size(34.dp)) {
                    Icon(Icons.Default.Menu, contentDescription = "Menu", tint = TextPrimary, modifier = Modifier.size(20.dp))
                }
            }
        }
    }
}

@Composable
fun GalleryBottomBar(
    selectedTab: AppTab,
    badges: Map<AppTab, com.example.ui.viewmodel.TabBadgeInfo>,
    onTabClick: (AppTab) -> Unit
) {
    NavigationBar(
        containerColor = DarkSurface,
        contentColor = TextPrimary
    ) {
        val tabs = listOf(
            Triple(AppTab.GALERI, Icons.Default.Photo, "Galeri"),
            Triple(AppTab.FAVORIT, Icons.Default.Favorite, "Favorit"),
            Triple(AppTab.LEPAS, Icons.Default.LinkOff, "Lepas"),
            Triple(AppTab.TRASH, Icons.Default.Delete, "Trash")
        )

        tabs.forEach { (tab, icon, title) ->
            val isSelected = selectedTab == tab
            val badge = badges[tab]

            NavigationBarItem(
                selected = isSelected,
                onClick = { onTabClick(tab) },
                icon = {
                    if (badge != null && badge.unseen > 0) {
                        BadgedBox(badge = {
                            Badge(containerColor = AccentTeal) {
                                Text("${badge.unseen}", color = Color(0xFF03251D), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }) {
                            Icon(icon, contentDescription = title)
                        }
                    } else if (badge != null && badge.total > 0) {
                        BadgedBox(badge = {
                            Badge(containerColor = DarkSurfaceVariant) {
                                Text("${badge.total}", color = TextSecondary, fontSize = 10.sp)
                            }
                        }) {
                            Icon(icon, contentDescription = title)
                        }
                    } else {
                        Icon(icon, contentDescription = title)
                    }
                },
                label = { Text(title, fontSize = 11.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = AccentPurple,
                    selectedTextColor = AccentPurple,
                    unselectedIconColor = TextSecondary,
                    unselectedTextColor = TextSecondary,
                    indicatorColor = AccentPurple.copy(alpha = 0.2f)
                )
            )
        }
    }
}

@Composable
fun GalleryNavRail(
    selectedTab: AppTab,
    badges: Map<AppTab, com.example.ui.viewmodel.TabBadgeInfo>,
    onTabClick: (AppTab) -> Unit
) {
    NavigationRail(
        containerColor = DarkSurface,
        contentColor = TextPrimary
    ) {
        val tabs = listOf(
            Triple(AppTab.GALERI, Icons.Default.Photo, "Galeri"),
            Triple(AppTab.FAVORIT, Icons.Default.Favorite, "Favorit"),
            Triple(AppTab.LEPAS, Icons.Default.LinkOff, "Lepas"),
            Triple(AppTab.TRASH, Icons.Default.Delete, "Trash")
        )

        tabs.forEach { (tab, icon, title) ->
            val isSelected = selectedTab == tab
            val badge = badges[tab]

            NavigationRailItem(
                selected = isSelected,
                onClick = { onTabClick(tab) },
                icon = {
                    if (badge != null && badge.unseen > 0) {
                        BadgedBox(badge = {
                            Badge(containerColor = AccentTeal) {
                                Text("${badge.unseen}", color = Color(0xFF03251D), fontSize = 10.sp)
                            }
                        }) {
                            Icon(icon, contentDescription = title)
                        }
                    } else {
                        Icon(icon, contentDescription = title)
                    }
                },
                label = { Text(title, fontSize = 10.sp) },
                colors = NavigationRailItemDefaults.colors(
                    selectedIconColor = AccentPurple,
                    selectedTextColor = AccentPurple,
                    unselectedIconColor = TextSecondary,
                    unselectedTextColor = TextSecondary,
                    indicatorColor = AccentPurple.copy(alpha = 0.2f)
                )
            )
        }
    }
}

@Composable
fun SelectionActionBar(
    selectedCount: Int,
    isTrashTab: Boolean,
    onMoveClick: () -> Unit,
    onTrashClick: () -> Unit,
    onRestoreClick: () -> Unit,
    onDeletePermanentClick: () -> Unit,
    onZipClick: () -> Unit,
    onMarkSeenClick: () -> Unit,
    onSelectCountClick: () -> Unit,
    onSelectAllClick: () -> Unit,
    onCloseSelection: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSurfaceVariant)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onCloseSelection, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Default.Close, contentDescription = "Tutup", tint = TextPrimary)
            }
            Text(
                text = "$selectedCount dipilih",
                color = AccentPurple,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onMoveClick, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Default.DriveFileMove, contentDescription = "Pindahkan", tint = TextPrimary, modifier = Modifier.size(18.dp))
            }

            if (isTrashTab) {
                IconButton(onClick = onRestoreClick, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Restore, contentDescription = "Pulihkan", tint = AccentTeal, modifier = Modifier.size(18.dp))
                }
                IconButton(onClick = onDeletePermanentClick, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Delete, contentDescription = "Hapus Permanen", tint = DeleteRed, modifier = Modifier.size(18.dp))
                }
            } else {
                IconButton(onClick = onTrashClick, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Delete, contentDescription = "Trash", tint = DeleteRed, modifier = Modifier.size(18.dp))
                }
            }

            IconButton(onClick = onZipClick, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Default.Download, contentDescription = "ZIP", tint = AccentTeal, modifier = Modifier.size(18.dp))
            }
            IconButton(onClick = onMarkSeenClick, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Default.Visibility, contentDescription = "Tandai dilihat", tint = TextPrimary, modifier = Modifier.size(18.dp))
            }
            IconButton(onClick = onSelectCountClick, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Default.FilterList, contentDescription = "Pilih Jumlah", tint = AccentPurple, modifier = Modifier.size(18.dp))
            }
            IconButton(onClick = onSelectAllClick, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Default.SelectAll, contentDescription = "Semua", tint = TextPrimary, modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
fun TabOptionsDialog(
    currentTab: AppTab,
    settings: com.example.data.datastore.AppSettings,
    onUpdateShowLepas: (Boolean) -> Unit,
    onUpdateShowOrphan: (Boolean) -> Unit,
    onUpdateLepasFilter: (String) -> Unit,
    onFilterSeen: (String) -> Unit,
    onOpenSelectCount: () -> Unit,
    onScrollToTop: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface,
        title = { Text("Opsi Tab ${currentTab.title}", color = TextPrimary, fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                if (currentTab == AppTab.GALERI) {
                    com.example.ui.components.ToggleRow(
                        title = "Hasil tanpa gambar asli ikut tampil",
                        checked = settings.showLepasInGallery,
                        onCheckedChange = onUpdateShowLepas
                    )
                    com.example.ui.components.ToggleRow(
                        title = "Gambar asli tanpa hasil ikut tampil",
                        checked = settings.showOrphanOriginalInGallery,
                        onCheckedChange = onUpdateShowOrphan
                    )
                    HorizontalDivider(color = DarkSurfaceVariant, modifier = Modifier.padding(vertical = 8.dp))
                } else if (currentTab == AppTab.LEPAS) {
                    Text("TAMPILKAN ISI LEPAS:", color = AccentPurple, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onUpdateLepasFilter("ALL") },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (settings.lepasFilter == "ALL") AccentPurple else DarkSurfaceVariant
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Semua", fontSize = 11.sp)
                        }
                        Button(
                            onClick = { onUpdateLepasFilter("RESULT") },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (settings.lepasFilter == "RESULT") AccentPurple else DarkSurfaceVariant
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Hasil", fontSize = 11.sp)
                        }
                        Button(
                            onClick = { onUpdateLepasFilter("ORIGINAL") },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (settings.lepasFilter == "ORIGINAL") AccentPurple else DarkSurfaceVariant
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Asli", fontSize = 11.sp)
                        }
                    }
                    HorizontalDivider(color = DarkSurfaceVariant, modifier = Modifier.padding(vertical = 8.dp))
                }

                Text("FILTER STATUS DILIHAT:", color = AccentPurple, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { onFilterSeen("ALL"); onDismiss() },
                        colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Semua", fontSize = 11.sp)
                    }
                    Button(
                        onClick = { onFilterSeen("UNSEEN"); onDismiss() },
                        colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Baru", color = AccentTeal, fontSize = 11.sp)
                    }
                    Button(
                        onClick = { onFilterSeen("SEEN"); onDismiss() },
                        colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Dilihat", fontSize = 11.sp)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        onDismiss()
                        onOpenSelectCount()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Pilih Jumlah Tertentu...", color = AccentPurple)
                }

                Spacer(modifier = Modifier.height(8.dp))

                Button(
                    onClick = {
                        onScrollToTop()
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Ke Paling Atas", color = TextPrimary)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Tutup", color = TextSecondary)
            }
        }
    )
}

@Composable
fun SelectCountDialog(
    defaultCount: Int,
    onSelect: (Int, Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    var countText by remember { mutableStateOf(defaultCount.toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface,
        title = { Text("Pilih Jumlah Tertentu", color = TextPrimary, fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Bagus untuk membagi pilihan ekspor per 250 gambar.",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = countText,
                    onValueChange = { countText = it.filter { ch -> ch.isDigit() } },
                    label = { Text("Jumlah (mis. 250)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Column {
                Button(
                    onClick = {
                        val num = countText.toIntOrNull() ?: 250
                        onSelect(num, true)
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AccentPurple),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Pilih N Pertama dari Awal")
                }
                Spacer(modifier = Modifier.height(4.dp))
                Button(
                    onClick = {
                        val num = countText.toIntOrNull() ?: 250
                        onSelect(num, false)
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Tambah N Berikutnya", color = AccentPurple)
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Batal", color = TextSecondary)
            }
        }
    )
}

@Composable
fun EmptyStateView(
    tab: AppTab,
    categoryName: String,
    onImportClick: () -> Unit,
    onSwitchToLepas: () -> Unit
) {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(32.dp)
        ) {
            val (icon, title, desc) = when (tab) {
                AppTab.GALERI -> Triple(
                    Icons.Default.Photo,
                    "Galeri '$categoryName' Kosong",
                    "Impor file gambar atau periksa tab Lepas jika gambar belum memiliki pasangan referensi asli."
                )
                AppTab.FAVORIT -> Triple(
                    Icons.Default.Favorite,
                    "Belum Ada Favorit",
                    "Beri tanda hati pada gambar yang bagus saat menyortir di penampil layar penuh."
                )
                AppTab.LEPAS -> Triple(
                    Icons.Default.LinkOff,
                    "Tidak Ada Gambar Lepas",
                    "Semua hasil generate telah terhubung dengan gambar referensi aslinya."
                )
                AppTab.TRASH -> Triple(
                    Icons.Default.Delete,
                    "Trash Bersih",
                    "Tidak ada gambar di tempat sampah pada kategori ini."
                )
            }

            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = TextSecondary.copy(alpha = 0.5f),
                modifier = Modifier.size(56.dp)
            )
            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = title,
                color = TextPrimary,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = desc,
                color = TextSecondary,
                fontSize = 13.sp,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(18.dp))

            if (tab == AppTab.GALERI) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = onImportClick,
                        colors = ButtonDefaults.buttonColors(containerColor = AccentPurple),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("＋ Impor Gambar", color = Color.White)
                    }
                    Button(
                        onClick = onSwitchToLepas,
                        colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Buka Tab Lepas", color = AccentTeal)
                    }
                }
            }
        }
    }
}

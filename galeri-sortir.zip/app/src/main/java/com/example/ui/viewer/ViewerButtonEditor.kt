package com.example.ui.viewer

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RemoveRedEye
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AccentPink
import com.example.ui.theme.AccentPurple
import com.example.ui.theme.AccentTeal
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DeleteRed
import org.json.JSONObject
import kotlin.math.roundToInt

data class ButtonRelativePosition(
    val xRatio: Float,
    val yRatio: Float
)

val DefaultButtonPositions = mapOf(
    "eye" to ButtonRelativePosition(0.15f, 0.85f),
    "fav" to ButtonRelativePosition(0.38f, 0.85f),
    "trash" to ButtonRelativePosition(0.62f, 0.85f),
    "download" to ButtonRelativePosition(0.85f, 0.85f)
)

fun parsePositions(jsonStr: String): Map<String, ButtonRelativePosition> {
    if (jsonStr.isBlank()) return DefaultButtonPositions
    return try {
        val root = JSONObject(jsonStr)
        val map = mutableMapOf<String, ButtonRelativePosition>()
        val keys = root.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val obj = root.getJSONObject(key)
            val x = obj.optDouble("x", 0.5).toFloat()
            val y = obj.optDouble("y", 0.85).toFloat()
            map[key] = ButtonRelativePosition(x, y)
        }
        map
    } catch (_: Exception) {
        DefaultButtonPositions
    }
}

fun serializePositions(positions: Map<String, ButtonRelativePosition>): String {
    val root = JSONObject()
    positions.forEach { (key, pos) ->
        val obj = JSONObject().apply {
            put("x", pos.xRatio)
            put("y", pos.yRatio)
        }
        root.put(key, obj)
    }
    return root.toString()
}

@Composable
fun ViewerButtonEditor(
    initialPositions: Map<String, ButtonRelativePosition>,
    onSavePositions: (Map<String, ButtonRelativePosition>) -> Unit,
    onReset: () -> Unit,
    onClose: () -> Unit
) {
    val currentPositions = remember {
        mutableStateMapOf<String, ButtonRelativePosition>().apply {
            putAll(initialPositions)
        }
    }

    val buttonList = listOf(
        Triple("eye", Icons.Default.RemoveRedEye, AccentTeal),
        Triple("fav", Icons.Default.Favorite, AccentPink),
        Triple("trash", Icons.Default.Warning, DeleteRed),
        Triple("download", Icons.Default.Download, AccentPurple)
    )

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.85f))
    ) {
        val maxWidthPx = constraints.maxWidth.toFloat()
        val maxHeightPx = constraints.maxHeight.toFloat()

        // Guidelines at 4% and 96%
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(
                    start = (maxWidthPx * 0.04f).dp,
                    end = (maxWidthPx * 0.04f).dp,
                    top = (maxHeightPx * 0.08f).dp,
                    bottom = (maxHeightPx * 0.08f).dp
                )
                .border(1.dp, AccentPurple.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
        )

        // Top bar with Reset and Selesai
        Row(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 24.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = {
                    currentPositions.clear()
                    currentPositions.putAll(DefaultButtonPositions)
                    onReset()
                },
                colors = ButtonDefaults.buttonColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(20.dp)
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                Text(" Reset", color = Color.White, fontSize = 12.sp)
            }

            Button(
                onClick = {
                    onSavePositions(currentPositions.toMap())
                    onClose()
                },
                colors = ButtonDefaults.buttonColors(containerColor = AccentPurple),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.padding(start = 12.dp)
            ) {
                Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                Text(" Selesai", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        // Draggable Buttons
        buttonList.forEach { (id, icon, color) ->
            val pos = currentPositions[id] ?: ButtonRelativePosition(0.5f, 0.85f)
            val posX = (pos.xRatio * maxWidthPx) - 24.dp.value
            val posY = (pos.yRatio * maxHeightPx) - 24.dp.value

            Box(
                modifier = Modifier
                    .offset { IntOffset(posX.roundToInt(), posY.roundToInt()) }
                    .size(54.dp)
                    .clip(CircleShape)
                    .background(DarkSurface)
                    .border(2.dp, color, CircleShape)
                    .pointerInput(Unit) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            val newX = (pos.xRatio * maxWidthPx + dragAmount.x).coerceIn(
                                maxWidthPx * 0.04f,
                                maxWidthPx * 0.96f
                            )
                            val newY = (pos.yRatio * maxHeightPx + dragAmount.y).coerceIn(
                                maxHeightPx * 0.08f,
                                maxHeightPx * 0.92f
                            )
                            currentPositions[id] = ButtonRelativePosition(
                                xRatio = newX / maxWidthPx,
                                yRatio = newY / maxHeightPx
                            )
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = id,
                    tint = color,
                    modifier = Modifier.size(26.dp)
                )
            }
        }
    }
}

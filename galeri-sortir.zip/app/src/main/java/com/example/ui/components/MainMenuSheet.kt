package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AccentPink
import com.example.ui.theme.AccentPurple
import com.example.ui.theme.AccentTeal
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.StorageOverview

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainMenuSheet(
    onOpenSort: () -> Unit,
    onCycleColumns: () -> Unit,
    onOpenLinkImport: () -> Unit,
    onOpenZipExport: () -> Unit,
    onOpenClean: () -> Unit,
    onShowStorageOverview: () -> Unit,
    onExportBackupJson: () -> Unit,
    onRestoreBackupJson: () -> Unit,
    onDismiss: () -> Unit
) {
    var showGuideDialog by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "☰ Menu Utama",
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Tutup", tint = TextSecondary)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // TAMPILAN
            Text("TAMPILAN", color = AccentPurple, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(6.dp))

            MenuItemRow(icon = Icons.Default.Sort, title = "Urutan dan Tampilan", color = AccentPurple) {
                onDismiss()
                onOpenSort()
            }
            MenuItemRow(icon = Icons.Default.GridView, title = "Ubah Jumlah Kolom Grid", color = AccentPurple) {
                onCycleColumns()
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = DarkSurfaceVariant)
            Spacer(modifier = Modifier.height(12.dp))

            // GAMBAR DAN DATA
            Text("GAMBAR DAN DATA", color = AccentTeal, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(6.dp))

            MenuItemRow(icon = Icons.Default.Link, title = "Impor dari Tautan (URL)", color = AccentTeal) {
                onDismiss()
                onOpenLinkImport()
            }
            MenuItemRow(icon = Icons.Default.Download, title = "Ekspor ZIP dan Unduh", color = AccentTeal) {
                onDismiss()
                onOpenZipExport()
            }
            MenuItemRow(icon = Icons.Default.DeleteSweep, title = "Bersihkan Massal", color = AccentTeal) {
                onDismiss()
                onOpenClean()
            }
            MenuItemRow(icon = Icons.Default.Storage, title = "Penyimpanan dan Ringkasan", color = AccentTeal) {
                onShowStorageOverview()
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = DarkSurfaceVariant)
            Spacer(modifier = Modifier.height(12.dp))

            // CADANGAN
            Text("CADANGAN (.JSON)", color = AccentPink, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(6.dp))

            MenuItemRow(icon = Icons.Default.Save, title = "Simpan Cadangan Pilihan (GaleriPilihan.json)", color = AccentPink) {
                onDismiss()
                onExportBackupJson()
            }
            MenuItemRow(icon = Icons.Default.Restore, title = "Pulihkan Pilihan dari JSON", color = AccentPink) {
                onDismiss()
                onRestoreBackupJson()
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = DarkSurfaceVariant)
            Spacer(modifier = Modifier.height(12.dp))

            // LAYAR PENUH DAN BANTUAN
            Text("BANTUAN & PANDUAN", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(6.dp))

            MenuItemRow(icon = Icons.Default.HelpOutline, title = "Panduan Fitur & Gestur", color = TextPrimary) {
                showGuideDialog = true
            }

            Spacer(modifier = Modifier.height(28.dp))
        }
    }

    if (showGuideDialog) {
        FeatureGuideDialog(onDismiss = { showGuideDialog = false })
    }
}

@Composable
fun MenuItemRow(
    icon: ImageVector,
    title: String,
    color: Color,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(12.dp))
            Text(text = title, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
fun StorageOverviewDialog(
    overview: StorageOverview,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface,
        title = { Text("Penyimpanan & Ringkasan", color = TextPrimary, fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                SummaryStatRow("Total gambar di aplikasi", "${overview.totalImages}")
                SummaryStatRow("Pemakaian memori aplikasi", formatBytes(overview.appUsageBytes))
                SummaryStatRow("Sisa ruang penyimpanan HP", formatBytes(overview.availableDiskBytes))
                SummaryStatRow("Kapasitas total HP", formatBytes(overview.totalDiskBytes))

                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(color = DarkSurfaceVariant)
                Spacer(modifier = Modifier.height(12.dp))

                Text("RINCIAN PER KATEGORI", color = AccentPurple, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))

                overview.categoryCounts.forEach { (catName, counts) ->
                    Card(
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(text = "Kategori: $catName", color = AccentTeal, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Galeri: ${counts["galeri"] ?: 0}", color = TextSecondary, fontSize = 11.sp)
                                Text("Favorit: ${counts["fav"] ?: 0}", color = TextSecondary, fontSize = 11.sp)
                                Text("Lepas: ${counts["lepas"] ?: 0}", color = TextSecondary, fontSize = 11.sp)
                                Text("Trash: ${counts["trash"] ?: 0}", color = TextSecondary, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss, colors = ButtonDefaults.buttonColors(containerColor = AccentPurple)) {
                Text("Tutup", color = Color.White)
            }
        }
    )
}

@Composable
fun FeatureGuideDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface,
        title = { Text("Panduan Gestur & Fitur", color = TextPrimary, fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Text("GESTUR DI PENAMPIL LAYAR PENUH", color = AccentPurple, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text("• Geser Atas: Masukkan ke Favorit (animasi hati).\n• Geser Bawah: Lihat gambar asli referensi, atau buang ke Trash.\n• Geser Kiri / Kanan: Pindah ke gambar berikutnya/sebelumnya.\n• Cubit (Pinch): Zoom 1x - 5x. Ketuk saat zoom untuk reset ke 1x.\n• Ketuk 1/3 Atas: Tampil/sembunyikan bilah teks & tombol.\n• Ketuk 2/3 Bawah: Navigasi cepat kiri (prev) dan kanan (next).", color = TextSecondary, fontSize = 12.sp)

                Spacer(modifier = Modifier.height(12.dp))
                Text("TOMBOL MATA 👁", color = AccentTeal, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text("• Tahan tombol mata = Mengintip gambar asli, lepas = kembali ke hasil.\n• Ketuk singkat (<0.3s) = Tampil asli permanen sampai diketuk lagi.", color = TextSecondary, fontSize = 12.sp)

                Spacer(modifier = Modifier.height(12.dp))
                Text("PILIH BANYAK (MULTI-SELECT)", color = AccentPink, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text("• Tahan satu kartu selama 0.4 detik untuk masuk mode pilih.\n• Gunakan bilah bawah untuk Pindahkan, Trash, Ekspor ZIP, atau Tandai sudah dilihat.\n• Tombol 'Jumlah' memudahkan memilih 250 gambar sekaligus untuk ekspor berkala.", color = TextSecondary, fontSize = 12.sp)
            }
        },
        confirmButton = {
            Button(onClick = onDismiss, colors = ButtonDefaults.buttonColors(containerColor = AccentPurple)) {
                Text("Mengerti", color = Color.White)
            }
        }
    )
}

private fun formatBytes(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
    return String.format("%.1f %s", bytes / Math.pow(1024.0, digitGroups.toDouble()), units[digitGroups])
}

package com.example.ui.components

import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.datastore.AppSettings
import com.example.manager.ImportClassificationType
import com.example.manager.ImportProgress
import com.example.manager.ImportSummary
import com.example.ui.theme.AccentPink
import com.example.ui.theme.AccentPurple
import com.example.ui.theme.AccentTeal
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.DeleteRed
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImportSourceDialog(
    settings: AppSettings,
    onSelectFiles: (ImportClassificationType) -> Unit,
    onSelectFolder: (ImportClassificationType) -> Unit,
    onOpenLinkImport: (ImportClassificationType) -> Unit,
    onUpdateTreatPromptAsResult: (Boolean) -> Unit,
    onUpdateMatchTruncatedNames: (Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedType by remember { mutableStateOf(ImportClassificationType.AUTO_MIX) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "＋ Impor Gambar",
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Tutup", tint = TextSecondary)
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "1. JENIS GAMBAR",
                    color = AccentPurple,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))

                val types = listOf(
                    ImportClassificationType.AUTO_MIX to "Campur (otomatis pasangkan)",
                    ImportClassificationType.FORCE_RESULT to "Hasil generate saja",
                    ImportClassificationType.FORCE_ORIGINAL to "Gambar asli saja"
                )

                types.forEach { (type, label) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedType = type }
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = selectedType == type,
                            onClick = { selectedType = type },
                            colors = RadioButtonDefaults.colors(
                                selectedColor = AccentPurple,
                                unselectedColor = TextSecondary
                            )
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = label, color = TextPrimary, fontSize = 13.sp)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(color = DarkSurfaceVariant)
                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "2. SUMBER PENGAMBILAN",
                    color = AccentPurple,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))

                ImportSourceButton(
                    icon = Icons.Default.Image,
                    title = "ZIP atau Gambar",
                    subtitle = "Pilih satu/banyak file ZIP, PNG, JPG, WEBP",
                    color = AccentPurple,
                    onClick = {
                        onDismiss()
                        onSelectFiles(selectedType)
                    }
                )

                Spacer(modifier = Modifier.height(8.dp))

                ImportSourceButton(
                    icon = Icons.Default.Folder,
                    title = "Folder Lengkap",
                    subtitle = "Pilih folder via SAF untuk dibaca isinya",
                    color = AccentTeal,
                    onClick = {
                        onDismiss()
                        onSelectFolder(selectedType)
                    }
                )

                Spacer(modifier = Modifier.height(8.dp))

                ImportSourceButton(
                    icon = Icons.Default.Link,
                    title = "Tautan (URL)",
                    subtitle = "Unduh langsung dari link gambar/ZIP/Drive",
                    color = AccentPink,
                    onClick = {
                        onDismiss()
                        onOpenLinkImport(selectedType)
                    }
                )

                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(color = DarkSurfaceVariant)
                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "OPSI ATURAN PASANGAN",
                    color = AccentPurple,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))

                ToggleRow(
                    title = "Nama mengandung 'prompt' dianggap hasil generate",
                    checked = settings.importTreatPromptAsResult,
                    onCheckedChange = onUpdateTreatPromptAsResult
                )

                ToggleRow(
                    title = "Nama asli yang terpotong di hasil tetap dicocokkan",
                    checked = settings.importMatchTruncatedNames,
                    onCheckedChange = onUpdateMatchTruncatedNames
                )
            }
        },
        confirmButton = {}
    )
}

@Composable
fun ImportSourceButton(
    icon: ImageVector,
    title: String,
    subtitle: String,
    color: Color,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(28.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(text = title, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text(text = subtitle, color = TextSecondary, fontSize = 11.sp)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LinkImportBottomSheet(
    type: ImportClassificationType,
    driveApiKey: String,
    onStartImport: (List<String>) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var urlText by remember { mutableStateOf("") }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 10.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Impor dari Tautan (URL)",
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Tutup", tint = TextSecondary)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "Masukkan satu link per baris. Mendukung file gambar langsung, file .zip, dan file tunggal Google Drive (/file/d/ID). Link folder Drive tidak didukung.",
                color = TextSecondary,
                fontSize = 12.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = urlText,
                onValueChange = { urlText = it },
                label = { Text("Daftar URL (satu per baris)") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp),
                maxLines = 8
            )

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                        if (clipboard != null && clipboard.hasPrimaryClip()) {
                            val clip = clipboard.primaryClip?.getItemAt(0)?.text?.toString()
                            if (!clip.isNullOrEmpty()) {
                                urlText = if (urlText.isEmpty()) clip else "$urlText\n$clip"
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.ContentPaste, contentDescription = null, tint = AccentPurple, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Tempel Clipboard", color = AccentPurple, fontSize = 12.sp)
                }

                Button(
                    onClick = {
                        val firstUrl = urlText.lines().firstOrNull { it.trim().isNotEmpty() }?.trim()
                        if (firstUrl != null) {
                            try {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(firstUrl))
                                context.startActivity(intent)
                            } catch (_: Exception) {}
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.OpenInBrowser, contentDescription = null, tint = AccentTeal, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Buka di Browser", color = AccentTeal, fontSize = 12.sp)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Button(
                onClick = {
                    val urls = urlText.lines().map { it.trim() }.filter { it.isNotEmpty() }
                    if (urls.isNotEmpty()) {
                        onStartImport(urls)
                        onDismiss()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = AccentPurple),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Ambil dan Impor", color = Color.White, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun ImportProgressDialog(
    progress: ImportProgress
) {
    if (!progress.isRunning) return

    AlertDialog(
        onDismissRequest = {}, // Block dismiss while importing
        containerColor = DarkSurface,
        title = {
            Text(
                text = "Sedang Mengimpor...",
                color = TextPrimary,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = progress.message,
                    color = AccentPurple,
                    fontSize = 14.sp
                )
                if (progress.currentFileName.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = progress.currentFileName,
                        color = TextSecondary,
                        fontSize = 11.sp,
                        maxLines = 1
                    )
                }
                Spacer(modifier = Modifier.height(14.dp))

                if (progress.total > 0) {
                    val frac = (progress.current.toFloat() / progress.total.toFloat()).coerceIn(0f, 1f)
                    LinearProgressIndicator(
                        progress = { frac },
                        modifier = Modifier.fillMaxWidth(),
                        color = AccentPurple,
                        trackColor = DarkSurfaceVariant
                    )
                } else {
                    LinearProgressIndicator(
                        modifier = Modifier.fillMaxWidth(),
                        color = AccentPurple,
                        trackColor = DarkSurfaceVariant
                    )
                }
            }
        },
        confirmButton = {}
    )
}

@Composable
fun ImportSummaryDialog(
    summary: ImportSummary,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface,
        title = {
            Text(
                text = if (summary.failedCount == 0 && !summary.isStorageFull) "Impor Selesai!" else "Ringkasan Impor",
                color = if (summary.isStorageFull) DeleteRed else AccentTeal,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                SummaryStatRow("Total diproses", "${summary.totalProcessed}")
                SummaryStatRow("Hasil tersimpan", "${summary.resultsImported}")
                SummaryStatRow("Asli berpasangan baru", "${summary.pairedOriginalsAdded}")
                SummaryStatRow("Kartu Asli yatim", "${summary.orphanOriginalsImported}")
                SummaryStatRow("Duplikat dilewati", "${summary.duplicatesSkipped}")
                if (summary.renamedCount > 0) {
                    SummaryStatRow("Diberi nomor (_2, _3)", "${summary.renamedCount}")
                }
                if (summary.failedCount > 0) {
                    SummaryStatRow("Gagal", "${summary.failedCount}", isError = true)
                }

                if (summary.isStorageFull) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "PERINGATAN: Ruang penyimpanan HP hampir penuh. Impor dihentikan secara aman.",
                        color = DeleteRed,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (summary.failureReasons.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Catatan Kegagalan:",
                        color = TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    summary.failureReasons.take(5).forEach { reason ->
                        Text(
                            text = "• $reason",
                            color = DeleteRed,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = AccentPurple)
            ) {
                Text("Tutup", color = Color.White)
            }
        }
    )
}

@Composable
fun SummaryStatRow(label: String, value: String, isError: Boolean = false) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = TextSecondary, fontSize = 13.sp)
        Text(
            text = value,
            color = if (isError) DeleteRed else TextPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp
        )
    }
}

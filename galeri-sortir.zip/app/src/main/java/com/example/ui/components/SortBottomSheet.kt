package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.datastore.AppSettings
import com.example.ui.theme.AccentPurple
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SortBottomSheet(
    settings: AppSettings,
    onUpdateSortMode: (String) -> Unit,
    onUpdateSeenAtBottom: (Boolean) -> Unit,
    onUpdateShowLepasInGallery: (Boolean) -> Unit,
    onUpdateShowOrphanOriginalInGallery: (Boolean) -> Unit,
    onUpdateNavMode: (String) -> Unit,
    onUpdateSwipeDownMode: (String) -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Urutan & Tampilan",
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Tutup", tint = TextSecondary)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text("URUTKAN BERDASARKAN", color = AccentPurple, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))

            val sortOptions = listOf(
                "ADDED_DESC" to "Terbaru ditambahkan",
                "ADDED_ASC" to "Terlama ditambahkan",
                "NAME_ASC" to "Nama A-Z (Natural)",
                "NAME_DESC" to "Nama Z-A",
                "PROMPT_ASC" to "Nomor prompt (P1, P2...)",
                "LAST_SEEN_DESC" to "Terakhir dilihat",
                "FILE_TIME_DESC" to "Waktu file terbaru",
                "FILE_TIME_ASC" to "Waktu file terlama",
                "ZIP_NAME_ASC" to "Nama per file ZIP"
            )

            sortOptions.forEach { (mode, label) ->
                val isSelected = settings.sortMode == mode
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) AccentPurple.copy(alpha = 0.2f) else DarkSurfaceVariant
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                        .clickable { onUpdateSortMode(mode) }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = label,
                            color = if (isSelected) AccentPurple else TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                        if (isSelected) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = AccentPurple, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(color = DarkSurfaceVariant)
            Spacer(modifier = Modifier.height(16.dp))

            Text("OPSI GRID", color = AccentPurple, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))

            ToggleRow(
                title = "Yang sudah dilihat di paling bawah",
                checked = settings.seenAtBottom,
                onCheckedChange = onUpdateSeenAtBottom
            )

            ToggleRow(
                title = "Hasil tanpa asli ikut tampil di Galeri",
                checked = settings.showLepasInGallery,
                onCheckedChange = onUpdateShowLepasInGallery
            )

            ToggleRow(
                title = "Asli tanpa hasil ikut tampil di Galeri",
                checked = settings.showOrphanOriginalInGallery,
                onCheckedChange = onUpdateShowOrphanOriginalInGallery
            )

            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(color = DarkSurfaceVariant)
            Spacer(modifier = Modifier.height(16.dp))

            Text("NAVIGASI PENAMPIL LAYAR PENUH", color = AccentPurple, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))

            val navModes = listOf(
                "GESTURE" to "A. Gestur (default)",
                "BUTTONS" to "B. Tombol layar",
                "HYBRID" to "C. Gabungan (gestur + tombol)",
                "FAST_SORT" to "D. Sortir cepat (kanan=fav, kiri=sampah)"
            )

            navModes.forEach { (mode, label) ->
                val isSelected = settings.navMode == mode
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) AccentPurple.copy(alpha = 0.2f) else DarkSurfaceVariant
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                        .clickable { onUpdateNavMode(mode) }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = label,
                            color = if (isSelected) AccentPurple else TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                        if (isSelected) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = AccentPurple, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Text("MODE GESER BAWAH DI PENAMPIL", color = AccentPurple, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))

            val swipeDownModes = listOf(
                "ORIGINAL_FIRST" to "Asli dulu (bawah 1x = asli, bawah lagi = sampah)",
                "SHORT_LONG" to "Pendek / panjang (pendek = asli, >30% = sampah)",
                "DIRECT_TRASH" to "Langsung hapus (klasik)"
            )

            swipeDownModes.forEach { (mode, label) ->
                val isSelected = settings.swipeDownMode == mode
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) AccentPurple.copy(alpha = 0.2f) else DarkSurfaceVariant
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                        .clickable { onUpdateSwipeDownMode(mode) }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = label,
                            color = if (isSelected) AccentPurple else TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                        if (isSelected) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = AccentPurple, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun ToggleRow(
    title: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = title, color = TextPrimary, fontSize = 14.sp, modifier = Modifier.fillMaxWidth(0.8f))
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = AccentPurple,
                uncheckedThumbColor = TextSecondary,
                uncheckedTrackColor = DarkSurfaceVariant
            )
        )
    }
}

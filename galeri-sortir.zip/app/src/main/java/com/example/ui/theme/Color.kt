package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBackground = Color(0xFF0D0F14)
val DarkSurface = Color(0xFF161922)
val DarkSurfaceVariant = Color(0xFF202534)
val DarkSurfaceCard = Color(0xFF1B1E2A)
val AccentPurple = Color(0xFF7C6BFF)
val AccentPurpleLight = Color(0xFFA598FF)
val AccentTeal = Color(0xFF0EE0AC)
val AccentPink = Color(0xFFFF4D8D)
val TextPrimary = Color(0xFFEEF0F6)
val TextSecondary = Color(0xFF8B90A3)
val DeleteRed = Color(0xFFE11D48)
val BorderDark = Color(0xFF262C3D)

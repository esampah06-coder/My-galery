package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LinkOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.CategoryEntity
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.DeleteRed
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CleanBottomSheet(
    activeCategory: CategoryEntity,
    trashCount: Int,
    lepasCount: Int,
    isImportRunning: Boolean,
    onEmptyTrash: () -> Unit,
    onClearLepas: () -> Unit,
    onClearLatestBatch: () -> Unit,
    onClearAllCategories: () -> Unit,
    onDismiss: () -> Unit
) {
    var confirmAction by remember { mutableStateOf<String?>(null) }
    var confirmLevelTwoAll by remember { mutableStateOf(false) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "🧹 Bersihkan Massal",
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Tutup", tint = TextSecondary)
                }
            }

            if (isImportRunning) {
                Spacer(modifier = Modifier.height(10.dp))
                Card(
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = DeleteRed.copy(alpha = 0.2f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = DeleteRed)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Pembersihan diblokir selama proses impor sedang berjalan.",
                            color = TextPrimary,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            CleanOptionCard(
                icon = Icons.Default.DeleteSweep,
                title = "Kosongkan Trash (${activeCategory.name})",
                subtitle = "$trashCount gambar di Trash kategori ini akan dihapus permanen.",
                enabled = !isImportRunning && trashCount > 0,
                onClick = { confirmAction = "EMPTY_TRASH" }
            )

            Spacer(modifier = Modifier.height(10.dp))

            CleanOptionCard(
                icon = Icons.Default.LinkOff,
                title = "Bersihkan Tab Lepas (${activeCategory.name})",
                subtitle = "$lepasCount gambar tanpa pasangan di kategori ini akan dihapus.",
                enabled = !isImportRunning && lepasCount > 0,
                onClick = { confirmAction = "CLEAR_LEPAS" }
            )

            Spacer(modifier = Modifier.height(10.dp))

            CleanOptionCard(
                icon = Icons.Default.History,
                title = "Bersihkan Impor Terbaru",
                subtitle = "Hapus batch impor terakhir. Favorit TIDAK ikut dihapus.",
                enabled = !isImportRunning,
                onClick = { confirmAction = "CLEAR_BATCH" }
            )

            Spacer(modifier = Modifier.height(14.dp))
            HorizontalDivider(color = DeleteRed.copy(alpha = 0.4f))
            Spacer(modifier = Modifier.height(14.dp))

            CleanOptionCard(
                icon = Icons.Default.Warning,
                title = "Bersihkan SEMUA Kategori",
                subtitle = "Hapus seluruh gambar dari semua kategori. Reset total.",
                enabled = !isImportRunning,
                isDanger = true,
                onClick = { confirmAction = "CLEAR_ALL" }
            )

            Spacer(modifier = Modifier.height(28.dp))
        }
    }

    // Confirmation dialogs
    if (confirmAction != null) {
        val (title, message, isDanger) = when (confirmAction) {
            "EMPTY_TRASH" -> Triple(
                "Kosongkan Trash?",
                "Sebanyak $trashCount gambar di Trash '${activeCategory.name}' akan dihapus permanen dari memori internal.",
                false
            )
            "CLEAR_LEPAS" -> Triple(
                "Bersihkan Tab Lepas?",
                "Sebanyak $lepasCount gambar tanpa pasangan di kategori '${activeCategory.name}' akan dihapus permanen.",
                false
            )
            "CLEAR_BATCH" -> Triple(
                "Bersihkan Batch Terakhir?",
                "Semua gambar hasil dari impor terakhir akan dihapus. Gambar yang sudah Anda favoritkan tetap aman dan tidak akan dihapus.",
                false
            )
            "CLEAR_ALL" -> Triple(
                "PERINGATAN: Hapus Semua Kategori?",
                "Tindakan ini akan menghapus SEMUA gambar dari SEMUA kategori secara permanen! Data tidak dapat dipulihkan.",
                true
            )
            else -> Triple("", "", false)
        }

        AlertDialog(
            onDismissRequest = { confirmAction = null },
            containerColor = DarkSurface,
            title = { Text(title, color = if (isDanger) DeleteRed else TextPrimary, fontWeight = FontWeight.Bold) },
            text = { Text(message, color = TextSecondary) },
            confirmButton = {
                Button(
                    onClick = {
                        val act = confirmAction
                        confirmAction = null
                        when (act) {
                            "EMPTY_TRASH" -> {
                                onEmptyTrash()
                                onDismiss()
                            }
                            "CLEAR_LEPAS" -> {
                                onClearLepas()
                                onDismiss()
                            }
                            "CLEAR_BATCH" -> {
                                onClearLatestBatch()
                                onDismiss()
                            }
                            "CLEAR_ALL" -> {
                                // Trigger second confirmation dialog
                                confirmLevelTwoAll = true
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DeleteRed)
                ) {
                    Text("Lanjutkan", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmAction = null }) {
                    Text("Batal", color = TextSecondary)
                }
            }
        )
    }

    if (confirmLevelTwoAll) {
        AlertDialog(
            onDismissRequest = { confirmLevelTwoAll = false },
            containerColor = DarkSurface,
            title = { Text("Konfirmasi Tingkat 2 (Terakhir)", color = DeleteRed, fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "Apakah Anda benar-benar yakin ingin mengosongkan seluruh galeri? Semua hasil generate dan referensi akan terhapus dari HP.",
                    color = TextPrimary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        confirmLevelTwoAll = false
                        onClearAllCategories()
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DeleteRed)
                ) {
                    Text("YA, BERSIHKAN SEMUANYA", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmLevelTwoAll = false }) {
                    Text("Batal", color = TextSecondary)
                }
            }
        )
    }
}

@Composable
fun CleanOptionCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    enabled: Boolean,
    isDanger: Boolean = false,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isDanger) DeleteRed.copy(alpha = 0.15f) else DarkSurfaceVariant
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(enabled = enabled, onClick = onClick)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isDanger) DeleteRed else if (enabled) TextPrimary else TextSecondary,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    color = if (isDanger) DeleteRed else if (enabled) TextPrimary else TextSecondary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = subtitle,
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }
        }
    }
}

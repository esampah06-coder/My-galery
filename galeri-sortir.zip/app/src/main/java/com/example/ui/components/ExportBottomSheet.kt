package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.CategoryEntity
import com.example.data.entity.ImageItemEntity
import com.example.manager.ExportContentType
import com.example.manager.ExportFileItem
import com.example.manager.ExportManager
import com.example.manager.ExportPart
import com.example.manager.PartStatus
import com.example.ui.theme.AccentPink
import com.example.ui.theme.AccentPurple
import com.example.ui.theme.AccentTeal
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.DeleteRed
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExportBottomSheet(
    exportManager: ExportManager,
    itemsToExport: List<ImageItemEntity>,
    activeCategory: CategoryEntity,
    allCategories: List<CategoryEntity>,
    currentTabName: String,
    isSelectionScope: Boolean,
    onPurgeExportedItems: (List<ImageItemEntity>) -> Unit,
    onDismiss: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()

    var contentType by remember { mutableStateOf(ExportContentType.RESULT_ONLY) }
    var exportAllCategories by remember { mutableStateOf(false) }
    var onlySeen by remember { mutableStateOf(false) }

    var preparedFiles by remember { mutableStateOf<List<ExportFileItem>>(emptyList()) }
    val parts = remember { mutableStateListOf<ExportPart>() }
    var isCalculating by remember { mutableStateOf(true) }
    var showConfirmPurgeDialog by remember { mutableStateOf(false) }

    fun refreshPreparation() {
        coroutineScope.launch {
            isCalculating = true
            val files = exportManager.prepareExportFiles(
                items = itemsToExport,
                contentType = contentType,
                onlySeen = onlySeen,
                tabName = currentTabName
            )
            preparedFiles = files
            val split = exportManager.splitIntoParts(files, maxPerPart = 250)
            parts.clear()
            parts.addAll(split)
            isCalculating = false
        }
    }

    LaunchedEffect(contentType, onlySeen, exportAllCategories, itemsToExport) {
        refreshPreparation()
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = DarkSurface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "⬇ Ekspor ZIP",
                    color = TextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Tutup", tint = TextSecondary)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Content Type Cycle
            Text("ISI EKSPOR (KETUK UNTUK MENGGANTI)", color = AccentPurple, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(6.dp))

            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        contentType = when (contentType) {
                            ExportContentType.RESULT_ONLY -> ExportContentType.RESULT_AND_ORIGINAL
                            ExportContentType.RESULT_AND_ORIGINAL -> ExportContentType.ORIGINAL_ONLY
                            ExportContentType.ORIGINAL_ONLY -> ExportContentType.RESULT_ONLY
                        }
                    }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = contentType.label, color = AccentTeal, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Text(
                            text = when (contentType) {
                                ExportContentType.RESULT_ONLY -> "Hanya file hasil generate"
                                ExportContentType.RESULT_AND_ORIGINAL -> "Hasil + referensi asli tanpa duplikasi"
                                ExportContentType.ORIGINAL_ONLY -> "Hanya file gambar asli (referensi)"
                            },
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                    Icon(Icons.Default.Sync, contentDescription = "Ganti", tint = AccentTeal)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Only Seen Toggle
            ToggleRow(
                title = "Hanya gambar yang sudah dilihat",
                checked = onlySeen,
                onCheckedChange = { onlySeen = it }
            )

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = DarkSurfaceVariant)
            Spacer(modifier = Modifier.height(10.dp))

            // Preview Info
            Text("PRATINJAU EKSPOR", color = AccentPurple, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(4.dp))

            if (isCalculating) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), color = AccentPurple)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Menghitung berkas...", color = TextSecondary, fontSize = 13.sp)
                }
            } else {
                Text(
                    text = "${itemsToExport.size} gambar → ${preparedFiles.size} file, ${parts.size} bagian (maks 250 per ZIP)",
                    color = TextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Download Buttons for Each Part
            if (parts.isNotEmpty()) {
                Text("BAGIAN ZIP (SIMPAN KE DOWNLOAD)", color = AccentPurple, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))

                parts.forEachIndexed { index, part ->
                    val isPreparing = part.status == PartStatus.PREPARING
                    val isDone = part.status == PartStatus.DOWNLOADED

                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isDone) AccentTeal.copy(alpha = 0.15f) else DarkSurfaceVariant
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Bagian ${part.partIndex} of ${part.totalParts}",
                                    color = if (isDone) AccentTeal else TextPrimary,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (isDone) "✓ Tersimpan di Download" else "${part.items.size} file",
                                    color = if (isDone) AccentTeal else TextSecondary,
                                    fontSize = 12.sp
                                )
                            }

                            Button(
                                onClick = {
                                    coroutineScope.launch {
                                        parts[index] = part.copy(status = PartStatus.PREPARING)
                                        val result = exportManager.exportPartToDownloads(
                                            part = part,
                                            tabName = if (isSelectionScope) "Pilihan" else currentTabName,
                                            categoryName = activeCategory.name,
                                            contentType = contentType
                                        )
                                        if (result.isSuccess) {
                                            parts[index] = part.copy(
                                                status = PartStatus.DOWNLOADED,
                                                downloadedFileName = result.getOrNull() ?: ""
                                            )
                                        } else {
                                            parts[index] = part.copy(
                                                status = PartStatus.FAILED,
                                                errorMessage = result.exceptionOrNull()?.message ?: "Gagal"
                                            )
                                        }
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isDone) DarkSurfaceVariant else AccentPurple
                                ),
                                enabled = !isPreparing
                            ) {
                                if (isPreparing) {
                                    CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Menyiapkan...", fontSize = 12.sp)
                                } else if (isDone) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = AccentTeal, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Unduh Lagi", color = AccentTeal, fontSize = 12.sp)
                                } else {
                                    Icon(Icons.Default.Download, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Unduh", color = Color.White, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }

            // "Singkirkan dari galeri" button: appears only when ALL parts have been downloaded AND contentType != ORIGINAL_ONLY
            val allPartsDownloaded = parts.isNotEmpty() && parts.all { it.status == PartStatus.DOWNLOADED }
            if (allPartsDownloaded && contentType != ExportContentType.ORIGINAL_ONLY) {
                Spacer(modifier = Modifier.height(18.dp))
                HorizontalDivider(color = DeleteRed.copy(alpha = 0.5f))
                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = { showConfirmPurgeDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = DeleteRed),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.DeleteForever, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Singkirkan dari Galeri",
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Hapus permanen ${itemsToExport.size} gambar yang baru diekspor untuk mengosongkan penyimpanan internal.",
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }

            Spacer(modifier = Modifier.height(28.dp))
        }
    }

    if (showConfirmPurgeDialog) {
        AlertDialog(
            onDismissRequest = { showConfirmPurgeDialog = false },
            containerColor = DarkSurface,
            title = { Text("Singkirkan Gambar dari Galeri?", color = DeleteRed, fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "Pastikan semua file ZIP bagian sudah tersimpan di folder Download. Gambar akan dihapus permanen dari HP dan TIDAK BISA DIKEMBALIKAN.",
                    color = TextPrimary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showConfirmPurgeDialog = false
                        onPurgeExportedItems(itemsToExport)
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DeleteRed)
                ) {
                    Text("Ya, Hapus Permanen", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmPurgeDialog = false }) {
                    Text("Batal", color = TextSecondary)
                }
            }
        )
    }
}

package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.datastore.AppSettings
import com.example.data.datastore.AppSettingsDataStore
import com.example.data.entity.CategoryEntity
import com.example.data.entity.ImageItemEntity
import com.example.data.entity.OriginalAssetEntity
import com.example.manager.BackupManager
import com.example.manager.CleanManager
import com.example.manager.ExportContentType
import com.example.manager.ExportManager
import com.example.manager.ExportPart
import com.example.manager.ImportClassificationType
import com.example.manager.ImportManager
import com.example.manager.ImportSummary
import com.example.manager.PartStatus
import com.example.util.NaturalOrderComparator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.InputStream

enum class AppTab(val title: String) {
    GALERI("Galeri"),
    FAVORIT("Favorit"),
    LEPAS("Lepas"),
    TRASH("Trash")
}

data class TabBadgeInfo(
    val total: Int = 0,
    val unseen: Int = 0
)

data class StorageOverview(
    val appUsageBytes: Long = 0L,
    val availableDiskBytes: Long = 0L,
    val totalDiskBytes: Long = 0L,
    val totalImages: Int = 0,
    val categoryCounts: Map<String, Map<String, Int>> = emptyMap()
)

data class UndoAction(
    val title: String,
    val action: suspend () -> Unit
)

class GalleryViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getInstance(application)
    val settingsDataStore = AppSettingsDataStore(application)
    val importManager = ImportManager(application, database)
    val exportManager = ExportManager(application, database)
    val cleanManager = CleanManager(application, database)
    val backupManager = BackupManager(application, database)

    val settings: StateFlow<AppSettings> = settingsDataStore.settingsFlow.stateIn(
        scope = viewModelScope,
        started = SharingStarted.Eagerly,
        initialValue = AppSettings()
    )

    private val _selectedTab = MutableStateFlow(AppTab.GALERI)
    val selectedTab: StateFlow<AppTab> = _selectedTab.asStateFlow()

    private val _allCategories = MutableStateFlow<List<CategoryEntity>>(emptyList())
    val allCategories: StateFlow<List<CategoryEntity>> = _allCategories.asStateFlow()

    private val _activeCategory = MutableStateFlow(CategoryEntity(id = 1L, name = "3D"))
    val activeCategory: StateFlow<CategoryEntity> = _activeCategory.asStateFlow()

    private val _rawCategoryImages = MutableStateFlow<List<ImageItemEntity>>(emptyList())

    // Selection mode
    private val _isSelectionMode = MutableStateFlow(false)
    val isSelectionMode: StateFlow<Boolean> = _isSelectionMode.asStateFlow()

    private val _selectedImageIds = MutableStateFlow<Set<Long>>(emptySet())
    val selectedImageIds: StateFlow<Set<Long>> = _selectedImageIds.asStateFlow()

    // Fullscreen viewer
    private val _viewerActiveImage = MutableStateFlow<ImageItemEntity?>(null)
    val viewerActiveImage: StateFlow<ImageItemEntity?> = _viewerActiveImage.asStateFlow()

    private val _viewerOriginalAsset = MutableStateFlow<OriginalAssetEntity?>(null)
    val viewerOriginalAsset: StateFlow<OriginalAssetEntity?> = _viewerOriginalAsset.asStateFlow()

    private val _isViewingOriginal = MutableStateFlow(false)
    val isViewingOriginal: StateFlow<Boolean> = _isViewingOriginal.asStateFlow()

    // Undo banner/toast
    private val _undoAction = MutableStateFlow<UndoAction?>(null)
    val undoAction: StateFlow<UndoAction?> = _undoAction.asStateFlow()

    // Status message / toast
    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    // Tab filter options (seen only / unseen only / all)
    private val _filterSeenStatus = MutableStateFlow("ALL") // ALL, UNSEEN, SEEN
    val filterSeenStatus: StateFlow<String> = _filterSeenStatus.asStateFlow()

    init {
        // Observe categories
        viewModelScope.launch {
            database.categoryDao().getAllCategories().collect { cats ->
                _allCategories.value = cats
                val currentActiveId = settings.value.activeCategoryId
                val found = cats.find { it.id == currentActiveId } ?: cats.firstOrNull()
                if (found != null && found != _activeCategory.value) {
                    _activeCategory.value = found
                }
            }
        }

        // Observe images for active category
        viewModelScope.launch {
            _activeCategory.collect { cat ->
                database.imageItemDao().getAllByCategoryFlow(cat.id).collect { images ->
                    _rawCategoryImages.value = images
                }
            }
        }
    }

    // Filtered and sorted images for current tab
    val displayedImages: StateFlow<List<ImageItemEntity>> = combine(
        _rawCategoryImages,
        _selectedTab,
        settings,
        _filterSeenStatus
    ) { images, tab, prefs, seenFilter ->
        val tabFiltered = when (tab) {
            AppTab.GALERI -> images.filter {
                !it.trashed && !it.favorite && (
                        (it.hasOriginal && !it.isOriginal) ||
                                (prefs.showLepasInGallery && !it.hasOriginal && !it.isOriginal) ||
                                (prefs.showOrphanOriginalInGallery && it.isOriginal)
                        )
            }
            AppTab.FAVORIT -> images.filter { it.favorite && !it.trashed }
            AppTab.LEPAS -> images.filter {
                !it.trashed && (!it.hasOriginal || it.isOriginal) && when (prefs.lepasFilter) {
                    "RESULT" -> !it.isOriginal
                    "ORIGINAL" -> it.isOriginal
                    else -> true
                }
            }
            AppTab.TRASH -> images.filter { it.trashed }
        }

        // Apply tab seen filter
        val statusFiltered = when (seenFilter) {
            "UNSEEN" -> tabFiltered.filter { !isSeenInTab(it, tab) }
            "SEEN" -> tabFiltered.filter { isSeenInTab(it, tab) }
            else -> tabFiltered
        }

        // Sort images
        val sorted = sortItems(statusFiltered, prefs.sortMode)

        // If seen at bottom is active, put seen items after unseen
        if (prefs.seenAtBottom) {
            val (unseen, seen) = sorted.partition { !isSeenInTab(it, tab) }
            unseen + seen
        } else {
            sorted
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Tab badges
    val tabBadges: StateFlow<Map<AppTab, TabBadgeInfo>> = combine(
        _rawCategoryImages,
        settings
    ) { images, prefs ->
        val galeriItems = images.filter {
            !it.trashed && !it.favorite && (
                    (it.hasOriginal && !it.isOriginal) ||
                            (prefs.showLepasInGallery && !it.hasOriginal && !it.isOriginal) ||
                            (prefs.showOrphanOriginalInGallery && it.isOriginal)
                    )
        }
        val favItems = images.filter { it.favorite && !it.trashed }
        val lepasItems = images.filter { !it.trashed && (!it.hasOriginal || it.isOriginal) }
        val trashItems = images.filter { it.trashed }

        mapOf(
            AppTab.GALERI to TabBadgeInfo(
                total = galeriItems.size,
                unseen = galeriItems.count { !it.seenGallery }
            ),
            AppTab.FAVORIT to TabBadgeInfo(
                total = favItems.size,
                unseen = favItems.count { !it.seenFav }
            ),
            AppTab.LEPAS to TabBadgeInfo(
                total = lepasItems.size,
                unseen = lepasItems.count { !it.seenLepas }
            ),
            AppTab.TRASH to TabBadgeInfo(
                total = trashItems.size,
                unseen = trashItems.count { !it.seenTrash }
            )
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    fun isSeenInTab(item: ImageItemEntity, tab: AppTab): Boolean {
        return when (tab) {
            AppTab.GALERI -> item.seenGallery
            AppTab.FAVORIT -> item.seenFav
            AppTab.LEPAS -> item.seenLepas
            AppTab.TRASH -> item.seenTrash
        }
    }

    private fun sortItems(items: List<ImageItemEntity>, sortMode: String): List<ImageItemEntity> {
        return when (sortMode) {
            "NAME_ASC" -> items.sortedWith { a, b -> NaturalOrderComparator.compare(a.name, b.name) }
            "NAME_DESC" -> items.sortedWith { a, b -> NaturalOrderComparator.compare(b.name, a.name) }
            "ADDED_ASC" -> items.sortedBy { it.addedAt }
            "ADDED_DESC" -> items.sortedByDescending { it.addedAt }
            "PROMPT_ASC" -> items.sortedBy { it.promptNo }
            "LAST_SEEN_DESC" -> items.sortedByDescending { it.lastSeenAt }
            "FILE_TIME_DESC" -> items.sortedByDescending { it.fileModified }
            "FILE_TIME_ASC" -> items.sortedBy { it.fileModified }
            "ZIP_NAME_ASC" -> items.sortedWith { a, b -> NaturalOrderComparator.compare(a.zipName, b.zipName) }
            else -> items.sortedByDescending { it.addedAt }
        }
    }

    fun selectTab(tab: AppTab) {
        if (_selectedTab.value != tab) {
            _selectedTab.value = tab
            clearSelection()
        }
    }

    fun setFilterSeenStatus(status: String) {
        _filterSeenStatus.value = status
    }

    // Category operations
    fun selectCategory(category: CategoryEntity) {
        _activeCategory.value = category
        viewModelScope.launch {
            settingsDataStore.updateActiveCategoryId(category.id)
        }
        clearSelection()
    }

    fun createCategory(name: String) {
        val trimmed = name.trim()
        if (trimmed.isEmpty() || trimmed.length > 20) {
            showToast("Nama kategori 1-20 karakter")
            return
        }
        viewModelScope.launch {
            val existing = database.categoryDao().getCategoryByName(trimmed)
            if (existing != null) {
                showToast("Kategori '$trimmed' sudah ada")
                return@launch
            }
            val newId = database.categoryDao().insert(CategoryEntity(name = trimmed))
            val created = CategoryEntity(id = newId, name = trimmed)
            selectCategory(created)
            selectTab(AppTab.GALERI)
            showToast("Kategori '$trimmed' dibuat")
        }
    }

    fun renameCategory(category: CategoryEntity, newName: String) {
        val trimmed = newName.trim()
        if (trimmed.isEmpty() || trimmed.length > 20) {
            showToast("Nama kategori 1-20 karakter")
            return
        }
        viewModelScope.launch {
            val existing = database.categoryDao().getCategoryByName(trimmed)
            if (existing != null && existing.id != category.id) {
                showToast("Nama '$trimmed' sudah digunakan")
                return@launch
            }
            database.categoryDao().update(category.copy(name = trimmed))
            if (_activeCategory.value.id == category.id) {
                _activeCategory.value = category.copy(name = trimmed)
            }
            showToast("Nama kategori diperbarui")
        }
    }

    fun deleteCategory(category: CategoryEntity) {
        viewModelScope.launch {
            val count = database.categoryDao().getImageCount(category.id)
            if (count > 0) {
                showToast("Hanya kategori kosong yang bisa dihapus")
                return@launch
            }
            if (_allCategories.value.size <= 1) {
                showToast("Minimal harus ada satu kategori")
                return@launch
            }
            database.categoryDao().delete(category)
            val fallback = _allCategories.value.firstOrNull { it.id != category.id }
            if (fallback != null) {
                selectCategory(fallback)
            }
            showToast("Kategori '${category.name}' dihapus")
        }
    }

    // Image operations
    fun toggleFavorite(item: ImageItemEntity) {
        viewModelScope.launch {
            val newFav = !item.favorite
            database.imageItemDao().setFavorite(item.id, newFav)
            _undoAction.value = UndoAction(
                title = if (newFav) "Masuk Favorit" else "Dikeluarkan dari Favorit",
                action = { database.imageItemDao().setFavorite(item.id, !newFav) }
            )
        }
    }

    fun moveToTrash(item: ImageItemEntity) {
        viewModelScope.launch {
            database.imageItemDao().setTrashed(item.id, true, System.currentTimeMillis())
            _undoAction.value = UndoAction(
                title = "Dipindah ke Trash",
                action = { database.imageItemDao().setTrashed(item.id, false, 0L) }
            )
        }
    }

    fun restoreFromTrash(item: ImageItemEntity) {
        viewModelScope.launch {
            database.imageItemDao().setTrashed(item.id, false, 0L)
            _undoAction.value = UndoAction(
                title = "Dipulihkan dari Trash",
                action = { database.imageItemDao().setTrashed(item.id, true, System.currentTimeMillis()) }
            )
        }
    }

    fun deletePermanently(item: ImageItemEntity) {
        viewModelScope.launch {
            cleanManager.deleteItemsAndCleanAssets(listOf(item))
            showToast("Dihapus permanen")
        }
    }

    // Selection mode operations
    fun enterSelectionMode(firstItem: ImageItemEntity) {
        _isSelectionMode.value = true
        _selectedImageIds.value = setOf(firstItem.id)
    }

    fun toggleSelection(item: ImageItemEntity) {
        val current = _selectedImageIds.value.toMutableSet()
        if (current.contains(item.id)) {
            current.remove(item.id)
        } else {
            current.add(item.id)
        }
        _selectedImageIds.value = current
        if (current.isEmpty()) {
            _isSelectionMode.value = false
        }
    }

    fun selectAllDisplayed() {
        val allIds = displayedImages.value.map { it.id }.toSet()
        _selectedImageIds.value = allIds
        _isSelectionMode.value = allIds.isNotEmpty()
    }

    fun selectSpecificCount(count: Int, fromStart: Boolean) {
        val list = displayedImages.value
        val newSelection = if (fromStart) {
            list.take(count).map { it.id }.toSet()
        } else {
            val lastSelectedIndex = list.indexOfLast { _selectedImageIds.value.contains(it.id) }
            val startIndex = if (lastSelectedIndex >= 0) lastSelectedIndex + 1 else 0
            val additions = list.drop(startIndex).take(count).map { it.id }
            _selectedImageIds.value + additions
        }
        _selectedImageIds.value = newSelection
        _isSelectionMode.value = newSelection.isNotEmpty()
    }

    fun clearSelection() {
        _selectedImageIds.value = emptySet()
        _isSelectionMode.value = false
    }

    fun batchMoveToTrash() {
        val ids = _selectedImageIds.value.toList()
        viewModelScope.launch {
            database.imageItemDao().setBatchTrashed(ids, true, System.currentTimeMillis())
            val count = ids.size
            clearSelection()
            _undoAction.value = UndoAction(
                title = "$count gambar dipindah ke Trash",
                action = { database.imageItemDao().setBatchTrashed(ids, false, 0L) }
            )
        }
    }

    fun batchRestoreFromTrash() {
        val ids = _selectedImageIds.value.toList()
        viewModelScope.launch {
            database.imageItemDao().setBatchTrashed(ids, false, 0L)
            val count = ids.size
            clearSelection()
            _undoAction.value = UndoAction(
                title = "$count gambar dipulihkan",
                action = { database.imageItemDao().setBatchTrashed(ids, true, System.currentTimeMillis()) }
            )
        }
    }

    fun batchDeletePermanently() {
        val ids = _selectedImageIds.value.toList()
        viewModelScope.launch {
            val items = database.imageItemDao().getByIds(ids)
            cleanManager.deleteItemsAndCleanAssets(items)
            val count = items.size
            clearSelection()
            showToast("$count gambar dihapus permanen")
        }
    }

    fun batchMoveToCategory(targetCategoryId: Long) {
        val ids = _selectedImageIds.value.toList()
        viewModelScope.launch {
            database.imageItemDao().moveToCategory(ids, targetCategoryId)
            val count = ids.size
            clearSelection()
            showToast("$count gambar dipindahkan")
        }
    }

    fun moveToCategory(id: Long, targetCategoryId: Long) {
        viewModelScope.launch {
            database.imageItemDao().moveToCategory(listOf(id), targetCategoryId)
            showToast("Gambar dipindahkan")
        }
    }

    fun batchMarkSeen(seen: Boolean) {
        val ids = _selectedImageIds.value.toList()
        viewModelScope.launch {
            val currentTab = _selectedTab.value
            for (id in ids) {
                when (currentTab) {
                    AppTab.GALERI -> database.imageItemDao().setSeenGallery(id, seen)
                    AppTab.FAVORIT -> database.imageItemDao().setSeenFav(id, seen)
                    AppTab.LEPAS -> database.imageItemDao().setSeenLepas(id, seen)
                    AppTab.TRASH -> database.imageItemDao().setSeenTrash(id, seen)
                }
            }
            val count = ids.size
            clearSelection()
            _undoAction.value = UndoAction(
                title = if (seen) "$count ditandai sudah dilihat" else "$count ditandai belum dilihat",
                action = {
                    for (id in ids) {
                        when (currentTab) {
                            AppTab.GALERI -> database.imageItemDao().setSeenGallery(id, !seen)
                            AppTab.FAVORIT -> database.imageItemDao().setSeenFav(id, !seen)
                            AppTab.LEPAS -> database.imageItemDao().setSeenLepas(id, !seen)
                            AppTab.TRASH -> database.imageItemDao().setSeenTrash(id, !seen)
                        }
                    }
                }
            )
        }
    }

    // Fullscreen Viewer actions
    fun openViewer(item: ImageItemEntity) {
        _viewerActiveImage.value = item
        _isViewingOriginal.value = false
        // Mark as seen immediately in current tab
        viewModelScope.launch {
            when (_selectedTab.value) {
                AppTab.GALERI -> database.imageItemDao().setSeenGallery(item.id, true)
                AppTab.FAVORIT -> database.imageItemDao().setSeenFav(item.id, true)
                AppTab.LEPAS -> database.imageItemDao().setSeenLepas(item.id, true)
                AppTab.TRASH -> database.imageItemDao().setSeenTrash(item.id, true)
            }
            database.imageItemDao().setLastSeenAt(item.id, System.currentTimeMillis())

            // Preload paired original if available
            if (item.hasOriginal && item.bk.isNotEmpty()) {
                val asset = database.originalAssetDao().getByBk(item.bk)
                _viewerOriginalAsset.value = asset
            } else {
                _viewerOriginalAsset.value = null
            }
        }
    }

    fun closeViewer() {
        _viewerActiveImage.value = null
        _viewerOriginalAsset.value = null
        _isViewingOriginal.value = false
    }

    fun toggleViewingOriginal() {
        val current = _viewerActiveImage.value ?: return
        if (!current.hasOriginal) {
            showToast("Gambar asli tidak ditemukan")
            return
        }
        _isViewingOriginal.value = !_isViewingOriginal.value
    }

    fun setViewingOriginalState(viewing: Boolean) {
        val current = _viewerActiveImage.value ?: return
        if (viewing && !current.hasOriginal) {
            showToast("Gambar asli tidak ditemukan")
            return
        }
        _isViewingOriginal.value = viewing
    }

    fun navigateViewerNext(): Boolean {
        val current = _viewerActiveImage.value ?: return false
        val list = displayedImages.value
        val index = list.indexOfFirst { it.id == current.id }
        if (index in 0 until list.size - 1) {
            openViewer(list[index + 1])
            return true
        }
        return false
    }

    fun navigateViewerPrevious(): Boolean {
        val current = _viewerActiveImage.value ?: return false
        val list = displayedImages.value
        val index = list.indexOfFirst { it.id == current.id }
        if (index > 0) {
            openViewer(list[index - 1])
            return true
        }
        return false
    }

    fun onViewerActionFavorite() {
        val current = _viewerActiveImage.value ?: return
        if (current.isOriginal) {
            showToast("Gambar asli tidak bisa difavoritkan")
            return
        }
        val isFav = current.favorite
        toggleFavorite(current)
        // Advance to next or previous
        advanceAfterViewerAction(current)
    }

    fun onViewerActionTrash() {
        val current = _viewerActiveImage.value ?: return
        moveToTrash(current)
        advanceAfterViewerAction(current)
    }

    fun onViewerActionRestore() {
        val current = _viewerActiveImage.value ?: return
        restoreFromTrash(current)
        advanceAfterViewerAction(current)
    }

    fun onViewerActionDeletePermanent() {
        val current = _viewerActiveImage.value ?: return
        deletePermanently(current)
        advanceAfterViewerAction(current)
    }

    private fun advanceAfterViewerAction(removedItem: ImageItemEntity) {
        val list = displayedImages.value
        val index = list.indexOfFirst { it.id == removedItem.id }
        if (list.size <= 1) {
            closeViewer()
        } else if (index in 0 until list.size - 1) {
            openViewer(list[index + 1])
        } else if (index > 0) {
            openViewer(list[index - 1])
        } else {
            closeViewer()
        }
    }

    fun executeUndo() {
        val undo = _undoAction.value ?: return
        viewModelScope.launch {
            undo.action()
            _undoAction.value = null
            showToast("Aksi dibatalkan")
        }
    }

    fun dismissUndo() {
        _undoAction.value = null
    }

    fun showToast(msg: String) {
        _toastMessage.value = msg
    }

    fun clearToast() {
        _toastMessage.value = null
    }

    suspend fun getStorageOverview(): StorageOverview {
        val appUsage = com.example.util.FileStorageHelper.getAppStorageUsageBytes(getApplication())
        val availableDisk = com.example.util.FileStorageHelper.getAvailableInternalMemoryBytes(getApplication())
        val totalDisk = com.example.util.FileStorageHelper.getTotalInternalMemoryBytes(getApplication())
        val allImgs = database.imageItemDao().getAllImages()
        val allCats = database.categoryDao().getAllCategoriesSync()

        val catCounts = mutableMapOf<String, Map<String, Int>>()
        for (cat in allCats) {
            val catImgs = allImgs.filter { it.categoryId == cat.id }
            val galeri = catImgs.count { !it.trashed && !it.favorite && it.hasOriginal }
            val fav = catImgs.count { it.favorite && !it.trashed }
            val lepas = catImgs.count { !it.trashed && (!it.hasOriginal || it.isOriginal) }
            val trash = catImgs.count { it.trashed }
            catCounts[cat.name] = mapOf(
                "galeri" to galeri,
                "fav" to fav,
                "lepas" to lepas,
                "trash" to trash
            )
        }

        return StorageOverview(
            appUsageBytes = appUsage,
            availableDiskBytes = availableDisk,
            totalDiskBytes = totalDisk,
            totalImages = allImgs.size,
            categoryCounts = catCounts
        )
    }
}

package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.entity.ImageItemEntity
import com.example.ui.theme.AccentPink
import com.example.ui.theme.AccentPurple
import com.example.ui.theme.AccentTeal
import com.example.ui.theme.DarkSurfaceVariant
import com.example.util.VibrationHelper
import java.io.File

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ImageCard(
    item: ImageItemEntity,
    isSeen: Boolean,
    isSelected: Boolean,
    isSelectionMode: Boolean,
    onCardClick: () -> Unit,
    onCardLongClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val thumbFile = File(item.thumbnailPath).takeIf { it.exists() } ?: File(item.filePath)
    val cardAlpha = if (isSeen) 0.45f else 1.0f

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
        border = if (isSelected) BorderStroke(3.dp, AccentPurple) else null,
        modifier = modifier
            .aspectRatio(3f / 4f)
            .alpha(cardAlpha)
            .combinedClickable(
                onClick = onCardClick,
                onLongClick = {
                    VibrationHelper.vibrateLongSelect(context)
                    onCardLongClick()
                }
            )
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // Image using Coil lazy thumbnail
            AsyncImage(
                model = ImageRequest.Builder(context)
                    .data(thumbFile)
                    .crossfade(true)
                    .build(),
                contentDescription = item.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            // Top-Left Badge (P{N} / Hasil / Asli)
            val badgeText = when {
                item.isOriginal -> "Asli"
                item.promptNo > 0 -> "P${item.promptNo}"
                else -> "Hasil"
            }
            val badgeBg = when {
                item.isOriginal -> Color(0xFF2E3447)
                item.promptNo > 0 -> AccentPurple.copy(alpha = 0.9f)
                else -> AccentTeal.copy(alpha = 0.9f)
            }
            val badgeTextColor = if (item.isOriginal || item.promptNo > 0) Color.White else Color(0xFF03251D)

            Box(
                modifier = Modifier
                    .padding(8.dp)
                    .align(Alignment.TopStart)
                    .clip(RoundedCornerShape(6.dp))
                    .background(badgeBg)
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = badgeText,
                    color = badgeTextColor,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Top-Right Unseen Teal Dot
            if (!isSeen) {
                Box(
                    modifier = Modifier
                        .padding(8.dp)
                        .align(Alignment.TopEnd)
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(AccentTeal)
                )
            }

            // Selected Checkmark Badge (when selected)
            if (isSelected) {
                Box(
                    modifier = Modifier
                        .padding(6.dp)
                        .align(Alignment.TopEnd)
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(AccentPurple)
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Terpilih",
                        tint = Color.White,
                        modifier = Modifier.fillMaxSize().padding(2.dp)
                    )
                }
            }

            // Bottom Gradient & Name
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Transparent,
                                Color.Black.copy(alpha = 0.85f)
                            )
                        )
                    )
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
                Text(
                    text = item.name,
                    color = Color.White,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier
                        .fillMaxWidth(if (!item.isOriginal) 0.72f else 1f)
                        .align(Alignment.CenterStart)
                )

                // Favorite Heart Button (only for results)
                if (!item.isOriginal) {
                    IconButton(
                        onClick = {
                            VibrationHelper.vibrateShort(context)
                            onToggleFavorite()
                        },
                        modifier = Modifier
                            .size(28.dp)
                            .align(Alignment.CenterEnd)
                    ) {
                        Icon(
                            imageVector = if (item.favorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                            contentDescription = if (item.favorite) "Favorit" else "Bukan favorit",
                            tint = if (item.favorite) AccentPink else Color.White.copy(alpha = 0.8f),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

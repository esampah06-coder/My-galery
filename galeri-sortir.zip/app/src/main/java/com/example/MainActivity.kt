package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.example.ui.screen.MainGalleryScreen
import com.example.ui.theme.GaleriSortirTheme
import com.example.ui.viewmodel.GalleryViewModel

class MainActivity : ComponentActivity() {

    private val galleryViewModel: GalleryViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            GaleriSortirTheme {
                MainGalleryScreen(viewModel = galleryViewModel)
            }
        }
    }
}

package com.example.util

import java.util.Comparator

object NaturalOrderComparator : Comparator<String> {
    override fun compare(a: String?, b: String?): Int {
        if (a == null && b == null) return 0
        if (a == null) return -1
        if (b == null) return 1

        var ia = 0
        var ib = 0
        val nzA: Int
        val nzB: Int
        var ca: Char
        var cb: Char

        while (true) {
            var nza = 0
            var nzb = 0
            ca = charAt(a, ia)
            cb = charAt(b, ib)

            // Skip spaces/symbols if needed or compare directly
            while (ca.isWhitespace() || ca == ' ') {
                ia++
                ca = charAt(a, ia)
            }
            while (cb.isWhitespace() || cb == ' ') {
                ib++
                cb = charAt(b, ib)
            }

            // Process run of digits
            if (ca.isDigit() && cb.isDigit()) {
                if (ca == '0') {
                    while (charAt(a, ia) == '0') {
                        nza++
                        ia++
                    }
                    ca = charAt(a, ia)
                }
                if (cb == '0') {
                    while (charAt(b, ib) == '0') {
                        nzb++
                        ib++
                    }
                    cb = charAt(b, ib)
                }

                // Process non-zero digits
                var bias = 0
                while (ca.isDigit() && cb.isDigit()) {
                    if (bias == 0) {
                        if (ca < cb) bias = -1
                        else if (ca > cb) bias = 1
                    }
                    ia++
                    ib++
                    ca = charAt(a, ia)
                    cb = charAt(b, ib)
                }

                if (ca.isDigit()) {
                    return 1
                }
                if (cb.isDigit()) {
                    return -1
                }
                if (bias != 0) {
                    return bias
                }
                if (nza != nzb) {
                    return nza - nzb
                }
            }

            if (ca.code == 0 && cb.code == 0) {
                // The strings compare the same. Perhaps the caller
                // will want to call String.compareTo to break the tie.
                return a.compareTo(b, ignoreCase = true)
            }

            val caseA = ca.lowercaseChar()
            val caseB = cb.lowercaseChar()
            if (caseA < caseB) return -1
            if (caseA > caseB) return 1

            ia++
            ib++
        }
    }

    private fun charAt(s: String, i: Int): Char {
        return if (i >= s.length) 0.toChar() else s[i]
    }
}

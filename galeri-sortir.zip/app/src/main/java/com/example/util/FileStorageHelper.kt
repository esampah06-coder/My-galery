package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Environment
import android.os.StatFs
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import kotlin.math.max

object FileStorageHelper {

    fun getImagesDir(context: Context): File {
        val dir = File(context.filesDir, "images")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun getThumbnailsDir(context: Context): File {
        val dir = File(context.filesDir, "thumbnails")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun getAvailableInternalMemoryBytes(context: Context): Long {
        return try {
            val stat = StatFs(context.filesDir.path)
            stat.availableBlocksLong * stat.blockSizeLong
        } catch (e: Exception) {
            100L * 1024 * 1024 // fallback
        }
    }

    fun getTotalInternalMemoryBytes(context: Context): Long {
        return try {
            val stat = StatFs(context.filesDir.path)
            stat.blockCountLong * stat.blockSizeLong
        } catch (e: Exception) {
            1000L * 1024 * 1024
        }
    }

    fun getAppStorageUsageBytes(context: Context): Long {
        return getFolderSizeBytes(context.filesDir)
    }

    private fun getFolderSizeBytes(dir: File): Long {
        var size = 0L
        if (!dir.exists()) return 0L
        val files = dir.listFiles() ?: return 0L
        for (f in files) {
            size += if (f.isDirectory) getFolderSizeBytes(f) else f.length()
        }
        return size
    }

    /**
     * Creates a compressed JPEG thumbnail with maximum longest dimension of 360px and quality 80.
     */
    fun createThumbnail(sourceFile: File, outputFile: File): Boolean {
        return try {
            // First decode with inJustDecodeBounds to check dimensions
            val options = BitmapFactory.Options().apply {
                inJustDecodeBounds = true
            }
            BitmapFactory.decodeFile(sourceFile.absolutePath, options)

            val origWidth = options.outWidth
            val origHeight = options.outHeight
            if (origWidth <= 0 || origHeight <= 0) return false

            val maxDimension = 360
            val largestSide = max(origWidth, origHeight)
            var inSampleSize = 1
            if (largestSide > maxDimension) {
                while ((largestSide / inSampleSize) > maxDimension * 2) {
                    inSampleSize *= 2
                }
            }

            val decodeOptions = BitmapFactory.Options().apply {
                this.inSampleSize = inSampleSize
                inPreferredConfig = Bitmap.Config.RGB_565 // memory efficient
            }

            val roughBitmap = BitmapFactory.decodeFile(sourceFile.absolutePath, decodeOptions) ?: return false

            val currentLongest = max(roughBitmap.width, roughBitmap.height)
            val finalBitmap = if (currentLongest > maxDimension) {
                val scale = maxDimension.toFloat() / currentLongest.toFloat()
                val targetW = (roughBitmap.width * scale).toInt().coerceAtLeast(1)
                val targetH = (roughBitmap.height * scale).toInt().coerceAtLeast(1)
                val scaled = Bitmap.createScaledBitmap(roughBitmap, targetW, targetH, true)
                if (scaled != roughBitmap) {
                    roughBitmap.recycle()
                }
                scaled
            } else {
                roughBitmap
            }

            FileOutputStream(outputFile).use { out ->
                finalBitmap.compress(Bitmap.CompressFormat.JPEG, 80, out)
            }
            finalBitmap.recycle()
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun saveStreamToFile(inputStream: InputStream, targetFile: File): Long {
        var bytesWritten = 0L
        FileOutputStream(targetFile).use { output ->
            val buffer = ByteArray(8192)
            var read: Int
            while (inputStream.read(buffer).also { read = it } != -1) {
                output.write(buffer, 0, read)
                bytesWritten += read
            }
            output.flush()
        }
        return bytesWritten
    }
}
